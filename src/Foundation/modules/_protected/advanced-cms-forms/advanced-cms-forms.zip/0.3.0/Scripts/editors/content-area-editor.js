define([
    "dojo/_base/declare",
    "epi-forms/contentediting/editors/ContentAreaEditor"
], function (
    declare,
    ContentAreaEditor
) {
    return declare([ContentAreaEditor], { });
});
