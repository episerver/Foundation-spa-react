define([
    "dojo/_base/declare",
    "epi-forms/widget/overlay/ContentArea"
], function (
    declare,
    ContentArea
) {
    return declare([ContentArea], {});
});
