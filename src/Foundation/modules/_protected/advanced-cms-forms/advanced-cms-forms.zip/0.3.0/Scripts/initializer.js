define([
    "dojo/_base/declare",
    "epi/_Module"
], function (
    declare,
    _Module
) {
    return declare([_Module], {
    });
});
