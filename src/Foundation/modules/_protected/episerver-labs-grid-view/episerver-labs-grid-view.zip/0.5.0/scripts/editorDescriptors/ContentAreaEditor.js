﻿define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
    "dojo/promise/all",
    "dojo/Deferred",
    "dojo/dom-construct",

    "epi/shell/_ContextMixin",

    "epi-cms/contentediting/editors/ContentAreaEditor",

    "./withChildrenGridDialogMixin"
],
function (
    declare,
    lang,
    when,
    all,
    Deferred,
    domConstruct,

    _ContextMixin,

    ContentAreaEditor,

    withChildrenGridDialogMixin
) {
    return declare([ContentAreaEditor, withChildrenGridDialogMixin, _ContextMixin], {

        getTemplateString: function () {
            var deferred = new Deferred();
            var base = this.inherited(arguments);
            when(base).then(function (result) {

                deferred.resolve({
                    templateString: result.templateString + "<br/>{selectcontent}",
                    actions: lang.mixin(result.actions, { selectcontent: "Select content" })
                });
            });
            return deferred.promise;
        },

        executeAction: function (actionName) {
            if (actionName === "selectcontent") {
                this._showDialog();
            } else {
                this.inherited(arguments);
            }
        },

        _showDialog: function () {
            var currentValue = this.getDefaultRoot();

            var dialog = this._getChildrenGridDialog();
            this.isShowingChildDialog = true;

            this.childrenGridView.setContext({ id: currentValue }, this.gridSettings);
            dialog.show();
        },
        
        _onChildrenGridDialogExecute: function () {
            var values = this.childrenGridView.get("selectedContentReferences");
            if (!values || values.length === 0) {
                return;
            }

            var promises = [];
            values.forEach(function (value) {
                promises.push(this._childrenGridContentStore.get(value));
            }, this);

            when(all(promises), function (contents) {
                this.model.modify(function () {
                    contents.forEach(function (content) {
                        this.model.addChild(content);
                    }, this);
                }.bind(this));
                if (!this.tree) {
                    this._createTree();
                }
            }.bind(this));
        },

        focusChildrenGridDialog: function () {
            
        }
    });
});