﻿define([
    "dojo/_base/declare",
    "epi-cms/component/PageNavigationTree"
], function(
    declare,
    PageNavigationTree
) {
    return declare([PageNavigationTree], {
        // summary:
        //    Extended main navigation for pages.
        //
        // description:
        //    Extends epi-cms/component/PageNavigationTree with customizations for tree icons.

         getIconClass: function (/*dojo/data/Item*/item, /*Boolean*/opened) {
            if (item.properties && item.properties["childrenView_isContentContainer"]) {
                return "epi-iconObjectContainerContextual";
            }
            return this.inherited(arguments);
        }
    });
});