define([
    "dojo/_base/declare",
    "dojo/when",
    "dojo/string",
    "dojo/topic",

    "epi/dependency",

    "epi/shell/TypeDescriptorManager",
    "epi/shell/widget/dialog/Dialog",

    "epi-cms/ApplicationSettings",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/widget/_HasChildDialogMixin",

    "episerver-labs-grid-view/childrenGridDialogContent",

    "epi/i18n!epi/cms/nls/episerver.cms.widget.contentselector"
],
function (
    declare,
    when,
    stringUtil,
    topic,

    dependency,

    TypeDescriptorManager,
    Dialog,

    ApplicationSettings,
    ContentActionSupport,
    _HasChildDialogMixin,

    ChildrenGridDialogContent,

    localization
) {
    return declare([_HasChildDialogMixin], {
        _gridSelectionMode: "extended",

        postMixInProperties: function () {
            this.inherited(arguments);

            var registry = dependency.resolve("epi.storeregistry");
            this._childrenGridContentStore = registry.get("epi.cms.content.light");
        },

        getDefaultRoot: function () {
            //
            //  get default root for property
            //
            // protected
            //

            if (this.chontentChildrenRoot) {
                return this.chontentChildrenRoot;
            }
            return ApplicationSettings.startPage;
        },

        _getChildrenGridDialog: function () {
            if (this.childrenGridDialog && this.childrenGridDialog.domNode) {
                return this.childrenGridDialog;
            }

            var title = localization.title;
            if (this.allowedTypes && this.allowedTypes.length === 1) {
                var name = TypeDescriptorManager.getResourceValue(this.allowedTypes[0], "name");
                if (name) {
                    title = stringUtil.substitute(localization.format, [name]);
                }
            }

            this.childrenGridView = new ChildrenGridDialogContent({
                gridSelectionMode: this._gridSelectionMode
            });
            this.own(
                this.childrenGridView.filteredGrid.model.on("contentChangeRequest", function (item) {
                    this.childrenGridView.setContext({ id: item.contentLink }, this.gridSettings);
                }.bind(this))
            );

            this.childrenGridDialog = new Dialog({
                title: title,
                dialogClass: "epi-dialog-portrait children-grid-dialog",
                content: this.childrenGridView
            });

            this.childrenGridDialog.own(this.childrenGridView);

            this.own(this.childrenGridView.on("selectionChanged", this._setChildrenGridDialogButtonState.bind(this)));
            this.own(this.connect(this.childrenGridDialog, "onExecute", "_onChildrenGridDialogExecute"));
            this.own(this.connect(this.childrenGridDialog, "onHide", "_onChildrenGridDialogHide"));

            return this.childrenGridDialog;
        },

        _setChildrenGridDialogButtonState: function (selectedContentReferences) {
            if (!selectedContentReferences || selectedContentReferences.length === 0) {
                this.childrenGridDialog.definitionConsumer.setItemProperty(this.childrenGridDialog._okButtonName, "disabled", true);
                return;
            }

            when(this._childrenGridContentStore.executeMethod("List", null, selectedContentReferences)).then(function (contents) {
                var allValid = true;
                var availableSelection = [];
                contents.forEach(function (content) {
                    var isValid = this._checkAcceptance(content.typeIdentifier);
                    if (isValid) {
                        if (ContentActionSupport.hasAccess(content.accessMask, this.accessLevel || ContentActionSupport.accessLevel.Read)) {
                            availableSelection.push(content.contentLink);
                            return;
                        }
                    }
                    allValid = false;
                }, this);

                if (!allValid) {
                    this.childrenGridView.selectRows(availableSelection);
                }
                this.childrenGridDialog.definitionConsumer.setItemProperty(this.childrenGridDialog._okButtonName, "disabled", !allValid);
            }.bind(this));
        },

        _checkAcceptance: function (typeIdentifier) {
            // summary:
            //    Compares a type against arrays of allowed and restricted types
            //
            // typeIdentifier: String
            //    The type to check if it's accepted to use
            //
            // tags:
            //    protected

            var acceptedTypes = TypeDescriptorManager.getValidAcceptedTypes([typeIdentifier], this.allowedTypes, this.restrictedTypes);

            return !!acceptedTypes.length;
        },

        _onChildrenGridDialogHide: function () {
            this.isShowingChildDialog = false;
            this.focusChildrenGridDialog();
        }
    });
});
