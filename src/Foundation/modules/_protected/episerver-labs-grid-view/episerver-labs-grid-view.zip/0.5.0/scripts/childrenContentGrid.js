define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
    "dojo/query",
    "dojo/on",
    "dojo/aspect",

    "epi/dependency",

    "epi/shell/selection",

    "epi-cms/widget/_GridWidgetBase",
    "epi-cms/contentediting/viewmodel/LanguageSettingsModel",

    "./gridColumnRenderers"
],

    function (
        declare,
        lang,
        when,
        query,
        on,
        aspect,

        dependency,

        // epi-shell
        Selection,

        // epi-cms
        _GridWidgetBase,
        LanguageSettingsModel,

        gridColumnRenderers
    ) {

        return declare([_GridWidgetBase], {
            // summary: This component will list all children pages
            //

            roots: null,

            typeIdentifiers: null,

            queryName: null,

            queryParameters: null,

            dndTypes: ["epi.cms.contentreference"],

            _dndDisabled: true,

            contextChangeEvent: null,

            filtersModel: null,

            model: null,

            postMixInProperties: function () {
                this.storeKeyName = "childGrid.store";

                //TODO: own - memory leak
                var languageSettingsModel = new LanguageSettingsModel();
                var handle = languageSettingsModel.watch("availableLanguages", function () {
                    this.availableLanguages = languageSettingsModel.availableLanguages; //TODO: available languages from content
                    handle.unwatch();
                }.bind(this));

                this.inherited(arguments);

                this.selection = new Selection();
            },

            buildRendering: function () {
                this.inherited(arguments);

                var gridSettings = lang.mixin({
                    columns: {
                        name: {
                            label: "Content name",
                            renderCell: gridColumnRenderers.contentName.bind(this)
                        }
                    },
                    store: this.store,
                    dndDisabled: this._dndDisabled
                }, this.defaultGridMixin);

                this.grid = new this._gridClass(gridSettings, this.domNode);

                this.grid.set("showHeader", true);

                this.own(
                    aspect.around(this.grid, "insertRow", lang.hitch(this, this._aroundInsertRow))
                );
            },

            pauseFetchingData: function () {
                this.grid.set("store", null);
            },

            continueFetchingData: function () {
                this.grid.set("store", this.store);
            },

            configureGrid: function (columns) {
                //setting collumns execute query on store

                if (!columns || columns.length === 0) {
                    // set default columns
                    columns = [
                        {
                            name: "name",
                            displayName: "Content name",
                            rendererType: "contentName",
                            sortable: true,
                            sortColumn: "PageName"
                        },
                        {
                            name: "status",
                            displayName: "Status",
                            className: "column-size150",
                            rendererType: "status",
                            sortable: true,
                            sortColumn: "PageWorkStatus"
                        },
                        {
                            name: "contentTypeName",
                            displayName: "Type",
                            rendererType: "contentTypeName",
                            sortable: true,
                            sortColumn: "PageTypeName"
                        },
                        {
                            name: "pageCreatedBy",
                            displayName: "Created by",
                            rendererType: "createdBy"
                        },
                        {
                            name: "pageVisibleInMenu",
                            displayName: "Menu",
                            rendererType: "pageVisibleInMenu",
                            className: "column-size50 align-center"
                        },
                        {
                            name: "currentLanguageBranch",
                            displayName: "Languages",
                            rendererType: "currentLanguageBranch"
                        },
                        {
                            name: "inlineEdit",
                            displayName: " ",
                            rendererType: "inlineEdit",
                            className: "column-size50"
                        },
                        {
                            name: "previewUrl",
                            displayName: "",
                            rendererType: "previewUrl"
                        },
                        {
                            name: "action",
                            displayName: " ",
                            rendererType: "action",
                            sortable: false,
                            className: "column-size30"
                        }
                    ];
                }

                var colSetings = {};
                columns.forEach(function (col) {
                    colSetings[col.name] = {
                        label: col.displayName,
                        sortable: col.sortable
                    };

                    if (col.sortable && col.sortColumn) {
                        colSetings[col.name].field = col.sortColumn;
                    }

                    if (col.rendererType) {
                        if (!gridColumnRenderers[col.rendererType]) {
                            var renderFuction = this.model.parseFunctionRenderer(col.rendererType, this);
                            if (renderFuction) {
                                colSetings[col.name].renderCell = renderFuction.bind(this);
                            }
                        } else {
                            colSetings[col.name].renderCell = gridColumnRenderers[col.rendererType](col.propertyName, col.customRendererSettings, this);
                        }
                    } else {
                        colSetings[col.name].renderCell = gridColumnRenderers.property(col.propertyName).bind(this);
                    }

                    if (col.className) {
                        colSetings[col.name].className = col.className;
                    }
                }, this);
                this.grid.set("columns", colSetings);
            },

            _setContextMenuCommandProviderAttr: function (value) {
                this._contextMenuCommandProvider = value;
                this.grid.contextMenu.addProvider(this._contextMenuCommandProvider);
            },

            _setDndDisabledAttr: function (value) {
                this._dndDisabled = value;
                this.grid.set("dndDisabled", value);
            },

            onContextChanged: function (context) {
                // overriden from _GridWidgetBase
                // grid should not refresh automatically
                //this.fetchData();
            },

            onContentRequestNodeClicked: function (item) {
                this.model.emit("contentChangeRequest", item);
            },

            fetchData: function () {
                if (!this.filtersModel) {
                    alert("filters not assigned");
                    return;
                }

                when(this._getCurrentItem(), lang.hitch(this, function (currentItem) {
                    this.set("currentItem", currentItem);
                }));

                this.grid.set("queryOptions", { ignore: ["query"], sort: [{ attribute: "name", descending: false }] });
                var queryParameters = this.queryParameters || {};
                queryParameters.query = this.queryName;

                queryParameters.includeDescendants = this.filtersModel.includeDescendants;
                queryParameters.contentStatus = this.filtersModel.contentStatus;
                queryParameters.searchTerm = this.filtersModel.searchTerm;
                queryParameters.allLanguages = this.filtersModel.allLanguages;

                this.grid.set("query", queryParameters);
            },

            _onSelect: function (e) {
                this._contextMenuCommandProvider.updateCommandModel(e.rows[0].data);
            },

            getContentStore: function () {
                if (this._contentStore) {
                    return this._contentStore;
                }
                var registry = dependency.resolve("epi.storeregistry");
                this._contentStore = registry.get("epi.cms.content.light");
                return this._contentStore;
            },

            getContentDataStore: function () {
                if (this._contentDataStore) {
                    return this._contentDataStore;
                }
                var registry = dependency.resolve("epi.storeregistry");
                this._contentDataStore = registry.get("epi.cms.contentdata");
                return this._contentDataStore;
            }
        });
    });
