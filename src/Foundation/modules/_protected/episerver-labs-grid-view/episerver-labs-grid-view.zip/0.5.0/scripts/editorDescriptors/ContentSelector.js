﻿define([
    "dojo/_base/declare",
    "dojo/aspect",
    "dojo/when",
    "dojo/on",
    "dojo/dom-construct",

    "dijit/focus",
    "dijit/form/Button",

    "epi/shell/_ContextMixin",

    "epi-cms/widget/ContentSelector",

    "./withChildrenGridDialogMixin"
],
function (
    declare,
    aspect,
    when,
    on,
    domConstruct,

    focusManager,
    Button,

    _ContextMixin,

    ContentSelector,

    withChildrenGridDialogMixin
) {
    return declare([ContentSelector, withChildrenGridDialogMixin, _ContextMixin], {

        _gridSelectionMode: "single",

        buildRendering: function () {
            this.inherited(arguments);

            var node = domConstruct.place("<div></div>", this.inputContainer, "last");
            this.own(this.childGridDialogButton = new Button({
                title: "Content list",
                iconClass: "epi-iconList", //TODO: resources
                onClick: function () {
                    this.isShowingChildDialog = true;

                    if (this.value) {
                        var valuesToSelect;
                        if (this.value) {
                            valuesToSelect = this._convertValueToContentReference(this.value);
                            if (valuesToSelect) {
                                valuesToSelect = [valuesToSelect.createVersionUnspecificReference().toString()];
                            }
                        }

                        when(this._getContentData(this.value), function (content) {

                            // if the current content is any of allowedTypes then allow to select it
                            this.canSelectOwnerContent = this.canSelectOwnerContent &&
                                content &&
                                this._isContentAllowed(content.typeIdentifier);
                            var dialog = this._getChildrenGridDialog();
                            var ctx = { id: content.parentLink };
                            this.childrenGridView.setContext(ctx, this.gridSettings, valuesToSelect);
                            dialog.show();
                        }.bind(this));
                    } else {
                        var currentValue = this.getDefaultRoot();

                        when(this._getContentData(currentValue), function (content) {
                            // if the current content is any of allowedTypes then allow to select it
                            this.canSelectOwnerContent = this.canSelectOwnerContent &&
                                content &&
                                this._isContentAllowed(content.typeIdentifier);
                            var dialog = this._getChildrenGridDialog();
                            var ctx = { id: currentValue };
                            this.childrenGridView.setContext(ctx, this.gridSettings);
                            dialog.show();
                        }.bind(this));
                    }
                }.bind(this)
            }, node));
        },

        _onChildrenGridDialogExecute: function () {
            var value = this.childrenGridView.get("selectedContentReferences");
            if (!value || value.length === 0) {
                value = "-";
            } else {
                value = value[0];
            }
            this._setValueAndFireOnChange(value);
        },

        focusChildrenGridDialog: function () {
            this.childGridDialogButton.focus();
            if (!this.childGridDialogButton.disabled && this.childGridDialogButton.focusNode && this.childGridDialogButton.focusNode.focus) {
                try {
                    focusManager.focus(this.childGridDialogButton.focusNode);
                } catch (e) {
                    /*squelch errors from hidden nodes*/
                }
            }
        }
    });
});