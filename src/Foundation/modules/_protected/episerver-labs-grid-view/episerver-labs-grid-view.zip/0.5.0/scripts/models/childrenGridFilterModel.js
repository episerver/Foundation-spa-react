define([
    // dojo
    "dojo/_base/declare",

    // dijit
    "dojo/Stateful"
], function (
    declare,

    Stateful
) {
    return declare([Stateful], {

        includeDescendants: false,

        searchTerm: "",

        allLanguages: true,

        contentStatus: null,

        clear: function () {
            //this.set("includeDescendants", false); // includeDescendants filter is not reset
            this.set("searchTerm", "");
            //this.set("allLanguages", true); //all languages filter is not reset
        }
    });
});
