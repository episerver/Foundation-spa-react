define([
    "dojo/_base/declare",
    "dojo/aspect",
    "dojo/dom-geometry",

    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/CheckBox",

    "epi/dependency",

    "epi/shell/ClipboardManager",
    "epi/shell/widget/SearchBox",

    "epi-cms/component/ContentContextMenuCommandProvider",
    "epi-cms/contentediting/ContentViewModel",
    "epi-cms/widget/ContentForestStoreModel",
    "epi-cms/widget/ContentTreeModelConfirmation",

    "./models/childrenGridModel",

    "dojo/text!./templates/childrenFilteredGridTemplate.html",

    "./childrenGridFilter",
    "./childrenContentGrid"
],
    function (
        declare,
        aspect,
        domGeometry,

        _TemplatedMixin,
        _Widget,
        _WidgetsInTemplateMixin,
        CheckBox,

        dependency,

        ClipboardManager,
        SearchBox,

        ContextMenuCommandProvider,
        ContentViewModel,
        ContentForestStoreModel,
        ContentTreeModelConfirmation,

        ChildrenGridModel,

        template
    ) {
        return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {
            templateString: template,

            repositoryKey: "pages", //todo: hardcoded

            contextMenuCommandProvider: ContextMenuCommandProvider, //TODO: inline 113

            model: null,

            buildRendering: function () {
                this.inherited(arguments);

                this.contentQuery.model = this.model;
                this.contentQuery.set("contextMenuCommandProvider", this._contextMenuCommandProvider);

                this.filters.set("model", this.model.filters);

                this.own(
                    this.model.filters.watch(function () {
                        this.contentQuery.fetchData();
                    }.bind(this)),
                    aspect.after(this._contentForestStoreModel, "onPasteComplete", function () {
                        this.contentQuery.reset();
                    }.bind(this)),
                    this.contentQuery.on("dgrid-select, dgrid-deselect", this._gridSelectionChanged.bind(this))
                );
            },

            postMixInProperties: function () {
                this.inherited(arguments);

                this.model = new ChildrenGridModel();
                this.own(this.model);
                this._setupContextMenuCommandProvider();
            },

            _gridSelectionChanged: function () {
                var selection = this.contentQuery.grid.selection;
                if (!selection) {
                    this.model.set("selectedContentReferences", []);
                    return;
                }
                var contentReferences = [];
                for (var c in selection) {
                    if (selection.hasOwnProperty(c) && selection[c] === true) {
                        contentReferences.push(c);
                    }
                }
                this.model.set("selectedContentReferences", contentReferences);
            },

            getContextMenuCommandProvider: function () {
                return this._contextMenuCommandProvider;
            },

            changeDisplayedContext: function (contentLink, contentData, gridSettings) {//TODO: just contentData?
                gridSettings = gridSettings || {};

                if (gridSettings.gridCssClass) {
                    this.contentQuery.domNode.classList.add(gridSettings.gridCssClass);
                }

                var columns = gridSettings.columns;
                var allowShowDescendants = typeof gridSettings.allowShowDescendants === "undefined" ? true : !!gridSettings.allowShowDescendants;
                var contentStatusVisible = typeof gridSettings.contentStatusVisible === "undefined" ? false : !!gridSettings.contentStatusVisible;
                var searchTerm = !!gridSettings.searchTerm ? gridSettings.searchTerm : null;

                this.filters.set("showDescendantsVisible", allowShowDescendants);
                this.filters.set("contentStatusVisible", contentStatusVisible);

                this.contentQuery.pauseFetchingData();

                if (!allowShowDescendants && this.model.filters.includeDescendants) {
                    this.model.filters.set("includeDescendants", false);
                }

                this.contentQuery.set("queryParameters", { referenceId: contentLink });
                this.contentQuery.set("filtersModel", this.model.filters);
                this.contentQuery.set("queryName", "getchildren");
                this.model.filters.clear();
                if (searchTerm) {
                    this.filters.set("searchTerm", searchTerm);
                    this.model.filters.set("searchTerm", searchTerm);
                }

                this.contentQuery.configureGrid(columns);

                this.contentQuery.continueFetchingData();
            },

            selectItems: function (contentLinksToSelect) {
                if (!contentLinksToSelect) {
                    return;
                }

                this.contentQuery.grid.clearSelection();

                if (contentLinksToSelect.length === 0) {
                    return;
                }

                var obj = {};
                contentLinksToSelect.forEach(function (c) {
                    obj[c] = true;
                    var row = this.contentQuery.grid.row(c);
                    if (row) {
                        this.contentQuery.grid.select(row);
                    }
                }, this);
                this.contentQuery.grid.set("selection", obj);
                this._gridSelectionChanged();
            },

            createContentViewModel: function (contentData, ctx) {
                var viewModel = new ContentViewModel({
                    contentLink: contentData.contentLink,
                    contextTypeName: "epi.cms.contentdata"
                });
                viewModel.set("contentData", contentData);
                viewModel.set("languageContext", ctx.languageContext);

                return viewModel;
            },

            setGridSize: function (width, height) {
                var top = domGeometry.getMarginBox(this.filters.domNode).h;

                domGeometry.setMarginBox(this.contentQuery.domNode, {
                    w: width - 1,
                    h: height - top - 40
                });
            },

            _setupContextMenuCommandProvider: function () {
                // command provider used in Grid and in Main menu
                this.contentRepositoryDescriptors = this.contentRepositoryDescriptors ||
                    dependency.resolve("epi.cms.contentRepositoryDescriptors");
                var settings = this.contentRepositoryDescriptors.get(this.repositoryKey);


                this._clipboardManager = new ClipboardManager();
                this._contentForestStoreModel = new ContentForestStoreModel({
                    roots: settings.roots,
                    typeIdentifiers: settings.mainNavigationTypes
                        ? settings.mainNavigationTypes
                        : settings.containedTypes,
                    notAllowToDelete: settings.preventDeletionFor,
                    notAllowToCopy: settings.preventCopyingFor
                });

                this._contextMenuCommandProvider = new this.contextMenuCommandProvider({
                    treeModel: this._contentForestStoreModel,
                    clipboardManager: this._clipboardManager,
                    repositoryKey: this.repositoryKey
                });

                this._contentForestStoreModel = ContentTreeModelConfirmation(this._contentForestStoreModel);
            },

            _setSelectionModeAttr: function (value) {
                this.contentQuery.set("selectionMode", value);
            },

            _setDndDisabledAttr: function (value) {
                this.contentQuery.set("dndDisabled", value);
            }
        });
    });
