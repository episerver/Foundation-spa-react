﻿define([
    // dojo
    "dojo/_base/declare",
    "dojo/dom-geometry",
    "dojo/on",
    "dojo/topic",
    "dojo/when",
    "dojo/dom-construct",

    // dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

    "epi/dependency",
    "epi/shell/command/_WidgetCommandProviderMixin",
    "epi/shell/command/builder/ButtonBuilder",
    "epi/shell/command/DelegateCommand",

    // epi-cms
    "epi-cms/core/ContentReference",
    "epi-cms/_ContentContextMixin",
    "epi-cms/component/command/ViewTrash",

    "./childrenGridDialogContent",
    "./commands/showMainMenuCommand",

    "dojo/text!./templates/childrenGridComponent.html",
    
    "epi/i18n!epi/cms/nls/contentchildren.commands",

    "xstyle/css!./styles.css"
], function(
    declare,
    domGeometry,
    on,
    topic,
    when,
    domConstruct,

    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,

    dependency,
    _WidgetCommandProviderMixin,
    ButtonBuilder,
    DelegateCommand,

    ContentReference,
    _ContentContextMixin,
    ViewTrash,

    ChildrenGridDialogContent,
    ShowMainMenuCommand,

    template,

    resources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ContentContextMixin, _WidgetCommandProviderMixin], {
        //
        //  Navigation Grid View Component for pages 
        //
        //  Used for managing  flat structure of pages.
        //

        templateString: template,

        repositoryKey: "pages", //TODO: hardcoded

        postMixInProperties: function () {
            this.inherited(arguments);

            this.contentRepositoryDescriptors = this.contentRepositoryDescriptors || dependency.resolve("epi.cms.contentRepositoryDescriptors");
            var settings = this.contentRepositoryDescriptors.get(this.repositoryKey);
            this.typeIdentifiers = settings.mainNavigationTypes ? settings.mainNavigationTypes : settings.containedTypes;

            var registry = dependency.resolve("epi.storeregistry");
            this._contentStore = registry.get("epi.cms.contentdata");
            this._contentLightStore = registry.get("epi.cms.content.light");

            this._viewTrashCommand = new ViewTrash({ typeIdentifiers: this.typeIdentifiers, order: 100 });
            this.commands = [this._viewTrashCommand];
        },

        buildRendering: function () {
            this.inherited(arguments);

            this.childrenGridDialogContent.set("dndDisabled", false); //TODO: set through model
            this._showMainMenuCommand = new ShowMainMenuCommand();

            this.own(
                this.childrenGridDialogContent.filteredGrid.model.on("contentChangeRequest", function (item) {
                    var ctx = { id: item.contentLink };
                    this.childrenGridDialogContent.setContext(ctx, this.gridSettings);
                    this._updateMainMenu(item.contentLink, ctx);
                }.bind(this)),
                this._showMainMenuCommand
            );

            this._createMainMenuButton();
            this._createLocateButton();
        },

        startup: function () {
            if (this._started) {
                return;
            }

            this.inherited(arguments);

            when(this.getCurrentContext(), function (context) {
                this.childrenGridDialogContent.setContext(context, this.gridSettings);
                var contentLink = context.id;
                this._updateMainMenu(contentLink, context);
                this.childrenGridDialogContent.startup();
            }.bind(this));
        },

        layout: function () {
            var cb = this._contentBox, ocb = this._oldContentBox;

            if (!cb) {
                return;
            }

            if (ocb && cb.w === ocb.w && cb.h === ocb.h) {
                return;
            }

            this._oldContentBox = cb;
            var top = domGeometry.getMarginBox(this.childrenGridDialogContent.headerContainer).h;
            this.childrenGridDialogContent.filteredGrid.setGridSize(cb.w, cb.h - top);
        },

        contentContextChanged: function (ctx, callerData, request) {
            var contentLink = ctx.id;
            this._updateMainMenu(contentLink, ctx);
        },

        _updateMainMenu: function (contentLink, ctx) {
            var contentLinkWithoutVersion =  (new ContentReference(contentLink)).createVersionUnspecificReference().toString();
            when(this._contentLightStore.refresh(contentLinkWithoutVersion)).then(function (contentData) {
                if (!contentData) {
                    return;
                }
                var contentViewModel = this.childrenGridDialogContent.filteredGrid.createContentViewModel(contentData, ctx);
                this._showMainMenuCommand.set("model", contentViewModel);
            }.bind(this));
        },

        _createMainMenuButton: function () {
            var builder = new ButtonBuilder();

            var mainMenuNode = domConstruct.place("<span class='dijitInline'></span>", this.childrenGridDialogContent.headerContainer, "last");

            this._showMainMenuCommand.set("contextMenuCommandProvider",
                this.childrenGridDialogContent.filteredGrid.getContextMenuCommandProvider());
            builder.settings = this._showMainMenuCommand.settings;
            builder.create(this._showMainMenuCommand, mainMenuNode);
        },

        _createLocateButton: function () {
            this._locateCommand = new DelegateCommand({
                name: "locateContent",
                label: null,
                tooltip: resources.locatecontent,
                isAvailable: true,
                canExecute: true,

                settings: {
                    "class": "move-up epi-chromeless",
                    iconClass: "epi-iconPrimary",
                    showLabel: false
                },
                delegate: function () {
                    when(this.getCurrentContext(), function (context) {
                        this.childrenGridDialogContent.setContext({ id: context.parentLink }, this.gridSettings);
                    }.bind(this));
                }.bind(this)
            });

            var locateNode = domConstruct.place("<span class='dijitInline'></span>", this.childrenGridDialogContent.headerContainer, "last");
            
            var builder = new ButtonBuilder();
            builder.settings = this._locateCommand.settings;
            builder.create(this._locateCommand, locateNode);
        }
    });
});