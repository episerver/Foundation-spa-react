define([
    "dojo/_base/declare",
    "dojo/when",
    "dojo/topic",
    "epi/dependency",
    "epi/shell/command/_Command",
    "epi-cms/_ContentContextMixin"
],

function (
    declare,
    when,
    topic,
    dependency,
    _Command,
    _ContentContextMixin
) {

    return declare([_Command, _ContentContextMixin], {
        label: "Show grid", //TODO: EXTERNAL_GRID resources
        iconClass: "epi-iconList",

        _execute: function () {
            var uri = this.model[0].uri;

            topic.publish("/epi/shell/context/request", { uri: uri }, {
                sender: null,
                forceReload: true,
                forceContextChange: true,
                viewType: "episerver-labs-grid-view/childrenGridView",
                viewName: "searchContent"
            });
        },

        _onModelChange: function () {
            this.inherited(arguments);

            if (this.model === null || this.model.length !== 1) {
                this.set("canExecute", false);
                this.set("isAvailable", false);
                return;
            }

            var typeIdentifier = this.model[0].typeIdentifier;
            var isFolder = typeIdentifier === "episerver.core.contentfolder" || typeIdentifier === "episerver.core.contentassetfolder";
            this.set("isAvailable", isFolder);
            this.set("canExecute", isFolder);
        }
    });

});
