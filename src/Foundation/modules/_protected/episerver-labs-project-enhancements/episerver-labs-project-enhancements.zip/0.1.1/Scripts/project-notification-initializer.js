define([
    "dojo/when",
    "dijit/Tooltip",
    "epi/dependency",
    "epi/datetime",
    "epi/username",
    "epi-cms/project/ProjectNotification"
], function (
    when,
    Tooltip,
    dependency,
    epiDatetime,
    epiUsername,
    ProjectNotification
) {
    // Show tooltip over project link in the notification bar

    return function () {
        if (ProjectNotification.prototype._attachProjectNameClickEvent) {
            var originalProjectNameClickEvent = ProjectNotification.prototype._attachProjectNameClickEvent;

            var timeouts = {};

            ProjectNotification.prototype._attachProjectNameClickEvent = function (projectEl, project) {
                if (projectEl) {
                    var originalResult = originalProjectNameClickEvent.apply(this, arguments);

                    this.customProjectStore = this.customProjectStore || dependency.resolve("epi.storeregistry").get("episerver.labs.projectenhancements");

                    if (timeouts[project.id]) {
                        clearTimeout(timeouts[project.id]);
                    }

                    timeouts[project.id] = setTimeout(function () {
                        when(this.customProjectStore.get(project.id)).then(function (extendedProject) {

                            var tooltipMessage = epiDatetime.toUserFriendlyString(new Date(extendedProject.created)) +
                                ", " +
                                epiUsername.toUserFriendlyString(extendedProject.createdBy);

                            var t = new Tooltip({
                                connectId: [projectEl],
                                label: tooltipMessage,
                                position: ["below"]
                            });

                            this.own(t);

                            timeouts[project.id] = null;
                            delete timeouts[project.id];
                        }.bind(this));
                    }.bind(this), 1000);

                    return originalResult;
                }
            };

            ProjectNotification.prototype._attachProjectNameClickEvent.nom = "_attachProjectNameClickEvent";
        }
    };
});

