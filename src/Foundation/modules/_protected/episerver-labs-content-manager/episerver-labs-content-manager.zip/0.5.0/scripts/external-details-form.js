define([
    "dojo/_base/declare",
    "dojo/when",
    "dojo/Deferred",
    "dojo/dom-construct",
    "dojo/on",

    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

    "epi",
    "epi/dependency",
    "epi-cms/_ContentContextMixin",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/contentediting/ContentViewModel",

    "epi-cms/contentediting/inline-editing/BlockEditFormContainer",
    "epi-cms/contentediting/command/BlockInlinePublish",
    "episerver-labs-block-enhancements/create-new/translate-block-edit-form-container",
    "epi-cms/contentediting/inline-editing/CreateNewBlockEditFormContainer",

    "epi/shell/command/builder/ButtonBuilder",

    "epi-cms/contentediting/command/SendForReview",
    "epi-cms/contentediting/command/Withdraw",

    "epi-cms/content-approval/command/ReadyForReview",
    "epi-cms/content-approval/command/CancelReview",

    "episerver-labs-content-manager/tracker",

    "dojo/text!episerver-labs-content-manager/external-details-form.html",

    // referenced in the template
    "dijit/layout/BorderContainer",
    "dijit/layout/ContentPane",
    "dijit/form/ToggleButton",

    "xstyle/css!./styles.css"
],
    function (
        declare,
        when,
        Deferred,
        domConstruct,
        on,

        _LayoutWidget,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,

        epi,
        dependency,
        _ContentContextMixin,
        ContentActionSupport,
        ContentViewModel,

        FormContainer,
        InlinePublish,
        TranslateFormContainer,
        CreateNewBlockEditFormContainer,

        ButtonBuilder,
        SendForReview,
        Withdraw,

        ReadyForReview,
        CancelReview,

        tracker,

        template
    ) {

        // Patch BlockEditFormContainer to show content name
        var original_setMetadataAttr = FormContainer.prototype._setMetadataAttr;
        FormContainer.prototype._setMetadataAttr = function (metadata) {
            var settings = (metadata.customEditorSettings || {}).inlineBlock;
            if (settings) {
                settings.showNameProperty = true;
            }
            return original_setMetadataAttr.apply(this, arguments);
        };

        return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ContentContextMixin], {

            templateString: template,

            postCreate: function () {
                this.inherited(arguments);

                var registry = dependency.resolve("epi.storeregistry");
                this._approvalService = dependency.resolve("epi.cms.ApprovalService");
                this._contentStore = registry.get("epi.cms.content.light");
                this._contentDataStore = registry.get("epi.cms.contentdata");
                this._gridStore = registry.get("content-manager.store");
                this.inlinePublishCommand = new InlinePublish({
                    commandType: "inline-edit-form"
                });
                this.inlinePublishCommand.showMessage = function () {};
                // this._enhancedStore = registry.get("episerver.labs.blockenhancements");
            },

            // editing content
            editContent: function (contentLink, divToRenderIn, callback) {
                this.translate = false;

                var _this = this;
                // show approval status
                when(this._gridStore.executeMethod("GetApprovalComment", null, { contentLink: contentLink })).then(
                    function (comment) {
                        this.contentStatusMessage.classList.toggle("dijitHidden", !comment);
                        this.contentStatusMessage.innerHTML = comment;
                    }.bind(this));

                // show form
                var container = domConstruct.create("div");

                domConstruct.place(container, divToRenderIn);
                this.clearForm(); // destroy the current instance if for some reason React failed to do it
                this.formContainer = new FormContainer({
                    isInlineCreateEnabled: true,
                    layout: function () {}
                }, container, "last");

                this.formContainer.set("contentLink", contentLink).then(function (latestContentVersion) {
                    _this.inlinePublishCommand.set("model", this.formContainer._model);
                    when(_this.inlinePublishCommand._onModelChange()).then(function () {
                        if (this.formContainer._formCreated) {
                            if (latestContentVersion.status === 3) {
                                this.formContainer.set("readOnly", true);
                            }
                        } else {
                            var formCreatedHandle = on(this.formContainer, "FormCreated", function () {
                                formCreatedHandle.remove();
                                if (latestContentVersion.status === 3) {
                                    this.formContainer.set("readOnly", true);
                                }
                            }.bind(this));
                        }

                        var isFormValid = true;
                        var isDirty = false;
                        var missingLanguageBranch = latestContentVersion.missingLanguageBranch;
                        var isTranslationNeeded =
                            missingLanguageBranch && latestContentVersion.missingLanguageBranch.isTranslationNeeded;
                        var isPartOfActiveApproval = latestContentVersion.isPartOfActiveApproval;
                        var hasPublishAccessRights = ContentActionSupport.hasAccess(latestContentVersion.accessMask,
                            ContentActionSupport.accessLevel.Publish);
                        var initialIsPublished = latestContentVersion.status === 4;
                        var isPublishAvailable = !isTranslationNeeded &&
                            hasPublishAccessRights &&
                            (!isPartOfActiveApproval && _this.inlinePublishCommand.get("isAvailable") && _this.inlinePublishCommand.get("canExecute"));
                        var isPublished = initialIsPublished;

                        function fireCallback() {
                            callback(_this, {
                                isPublishAvailable: isPublishAvailable,
                                isPublished: isPublished,
                                isDirty: isDirty,
                                isFormValid: isFormValid
                            });
                        }

                        this.formContainer.own(on(this.formContainer, "isDirty", function () {
                            isDirty = this.formContainer.get("isDirty");
                            isPublished = !isDirty && initialIsPublished;
                            isPublishAvailable = !isTranslationNeeded &&
                                hasPublishAccessRights &&
                                (!isPartOfActiveApproval && (_this.inlinePublishCommand.get("isAvailable") && _this.inlinePublishCommand.get("canExecute") || isDirty));
                            fireCallback();
                        }.bind(this)));

                        this.formContainer.own(on(this.formContainer.form, "validStateChange", function (isValid) {
                            isFormValid = isValid;
                            fireCallback();
                        }.bind(this)));
                        fireCallback();
                    }.bind(this));
                }.bind(this));
            },

            translateContent: function (contentLink, language, divToRenderIn, callback) {
                // show translate form
                var container = domConstruct.create("div");

                domConstruct.place(container, divToRenderIn);

                this.clearForm(); // destroy the current instance if for some reason React failed to do it
                this.formContainer = new TranslateFormContainer({
                    isInlineCreateEnabled: this.isInlineCreateEnabled,
                    isTranslationNeeded: true,
                    layout: function () {}
                }, container, "last");

                when(this._contentStore.get(contentLink)).then(function (contentData) {
                    this.formContainer.reloadMetadata(contentData, contentData.contentTypeID);
                    this.formContainer.createContentViewModel.parent.missingLanguageBranch = {
                        preferredLanguage: language
                    }
                    this.formContainer.own(on(this.formContainer, "isDirty", function () {
                        var isDirty = this.formContainer.get("isDirty");
                        callback(this, {
                            isDirty: isDirty
                        });
                    }.bind(this)));
                    callback(this, {
                        isDirty: false
                    });
                }.bind(this));

                this.resize(); // contentLayoutWidget
                this.translate = true;
            },

            saveForm: function () {
                if (!this.formContainer.validate()) {
                    return new Deferred().reject();
                }

                tracker.trackEvent("contentManager_saveForm");

                //TODO: CreateFormContainer from block-enhancements should return a promise, fix it and bump the dependency version
                //TODO: that 'when' should not be needed after that change
                return when(this.formContainer.saveForm());
            },

            publish: function () {
                return this.inlinePublishCommand.tryToSaveAndExecute(this.formContainer);
            },

            createContent: function (contentTypeId, parentContentId, divToRenderIn, callback) {
                var _this = this;
                this.contentStatusMessage.classList.toggle("dijitHidden", true);

                var container = domConstruct.create("div");

                domConstruct.place(container, divToRenderIn);

                when(this._contentStore.get(parentContentId)).then(function (content) {
                    if (!content) {
                        return;
                    }

                    this.clearForm(); // destroy the current instance if for some reason React failed to do it
                    this.formContainer = new CreateNewBlockEditFormContainer({
                        autoPublish: true, //temporary true, because otherwise content will be automatically added to the repository
                        layout: function () {}
                    }, container, "last");

                    this.formContainer.createContentViewModel.createAsLocalAsset = false;

                    this.formContainer.reloadMetadata(content, contentTypeId).then(function () {
                        this.formContainer.createContentViewModel.autoPublish = false;
                    }.bind(this));
                    this.formContainer.own(on(this.formContainer, "formCreated", function () {
                        this.resize(); // contentLayoutWidget
                    }.bind(this)));

                    var isFormValid = true;
                    var isDirty = false;
                    function fireCallback() {
                        callback(_this, {
                            isDirty: isDirty,
                            isFormValid: isFormValid
                        });
                    }

                    this.formContainer.own(on(this.formContainer, "isDirty", function () {
                        isDirty = this.formContainer.get("isDirty");
                        fireCallback();
                    }.bind(this)));
                    this.formContainer.own(on(this.formContainer.form, "validStateChange", function (isValid) {
                        isFormValid = isValid;
                        fireCallback();
                    }));
                    fireCallback();
                    tracker.trackEvent("contentManager_createContent");
                }.bind(this));
            },

            markAsReady: function () {
                var contentViewModel = this.formContainer._model;
                if (contentViewModel) {
                    tracker.trackEvent("contentManager_markAsReady");

                    if (this._isTransitionAvailable(contentViewModel.contentData, "readyforreview")) {
                        var readyForReview = new ReadyForReview();
                        readyForReview.set("model", contentViewModel);
                        return readyForReview.execute();
                    }

                    if (this._isTransitionAvailable(contentViewModel.contentData, "readytopublish")) {
                        var sendForReview = new SendForReview();
                        sendForReview.set("model", contentViewModel);
                        return sendForReview.execute();
                    }
                }

                return new Deferred().resolve();
            },

            cancelReview: function (contentLink) {
                return when(this._contentDataStore.get(contentLink)).then(function (content) {
                    var viewModel = new ContentViewModel({
                        contentLink: contentLink,
                        contextTypeName: "epi.cms.contentdata"
                    });

                    if (this._isTransitionAvailable(content, "cancelreview")) {
                        var cancelReview = new CancelReview();
                        cancelReview.set("model", viewModel);
                        return this._approvalService.getApproval(contentLink).then(function (approval) {
                            cancelReview.set({
                                canExecute: !!approval,
                                approval: approval
                            });
                            return cancelReview.execute();
                        }.bind(this));
                    } else {
                        var withdrawCommand = new Withdraw();
                        withdrawCommand.set("model", viewModel);
                        return withdrawCommand.execute();
                    }
                }.bind(this));
            },

            _isTransitionAvailable: function (content, transition) {
                return content.transitions.some(function (x) {
                    return x.name === transition;
                });
            },

            clearForm: function () {
                if (this.formContainer) {
                    this.formContainer.destroyRecursive();
                }
            }
        });
    });
