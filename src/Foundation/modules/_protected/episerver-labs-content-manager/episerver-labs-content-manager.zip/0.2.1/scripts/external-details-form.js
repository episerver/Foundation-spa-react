define([
    "dojo/_base/declare",
    "dojo/when",
    "dojo/Deferred",
    "dojo/dom-construct",
    "dojo/on",
    "dojo/aspect",

    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

    "epi",
    "epi/dependency",
    "epi-cms/_ContentContextMixin",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/contentediting/ContentViewModel",

    "episerver-labs-block-enhancements/inline-editing/block-edit-form-container",
    "episerver-labs-block-enhancements/inline-editing/commands/inline-publish",
    "episerver-labs-block-enhancements/create-new/translate-block-edit-form-container",
    "episerver-labs-block-enhancements/create-new/create-new-block-edit-form-container",

    "epi/shell/command/builder/ButtonBuilder",

    "epi-cms/contentediting/command/SendForReview",
    "epi-cms/contentediting/command/Withdraw",

    "epi-cms/content-approval/command/ReadyForReview",
    "epi-cms/content-approval/command/CancelReview",

    "episerver-labs-content-manager/tracker",

    "dojo/text!episerver-labs-content-manager/external-details-form.html",

    // referenced in the template
    "dijit/layout/BorderContainer",
    "dijit/layout/ContentPane",
    "dijit/form/ToggleButton",

    "xstyle/css!./styles.css"
],
    function (
        declare,
        when,
        Deferred,
        domConstruct,
        on,
        aspect,

        _LayoutWidget,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,

        epi,
        dependency,
        _ContentContextMixin,
        ContentActionSupport,
        ContentViewModel,

        FormContainer,
        InlinePublish,
        TranslateFormContainer,
        CreateNewBlockEditFormContainer,

        ButtonBuilder,
        SendForReview,
        Withdraw,

        ReadyForReview,
        CancelReview,

        tracker,

        template
    ) {

        return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ContentContextMixin], {

            templateString: template,

            postCreate: function () {
                this.inherited(arguments);

                var registry = dependency.resolve("epi.storeregistry");
                this._approvalService = dependency.resolve("epi.cms.ApprovalService");
                this._contentStore = registry.get("epi.cms.content.light");
                this._contentDataStore = registry.get("epi.cms.contentdata");
                this._gridStore = registry.get("content-manager.store");
                this.inlinePublishCommand = new InlinePublish({
                    commandType: "inline-edit-form"
                });
                this.inlinePublishCommand.showMessage = function () {};
                // this._enhancedStore = registry.get("episerver.labs.blockenhancements");
            },

            // editing content
            editContent: function (contentLink, callback) {
                var _this = this;
                // show approval status
                when(this._gridStore.executeMethod("GetApprovalComment", null, { contentLink: contentLink })).then(
                    function (comment) {
                        this.contentStatusMessage.classList.toggle("dijitHidden", !comment);
                        this.contentStatusMessage.innerHTML = comment;
                    }.bind(this));

                // show form
                var container = domConstruct.create("div");

                this._clearForm();
                domConstruct.place(container, this.content);

                if (this.formContainer) {
                    this.formContainer.destroyRecursive();
                    this.formContainer = null;
                }
                if (this.onChangeHandle) {
                    this.onChangeHandle.remove();
                    this.onChangeHandle = null;
                }

                this.formContainer = new FormContainer({
                    isInlineCreateEnabled: true
                }, container, "last");
                this.own(this.formContainer);

                var formCreatedHandle = aspect.after(this.formContainer, "onFormCreated", function () {
                    formCreatedHandle.remove();
                    if (this.formContainer._model.contentData.status === 3) {
                        this.formContainer.set("readOnly", true);
                    }
                }.bind(this));

                this.formContainer.set("contentLink", contentLink).then(function (latestContentVersion) {
                    _this.inlinePublishCommand.set("model", this.formContainer._model);
                    when(_this.inlinePublishCommand._onModelChange()).then(function () {
                        var missingLanguageBranch = latestContentVersion.missingLanguageBranch;
                        var isTranslationNeeded =
                            missingLanguageBranch && latestContentVersion.missingLanguageBranch.isTranslationNeeded;
                        var isPartOfActiveApproval = latestContentVersion.isPartOfActiveApproval;
                        var hasPublishAccessRights = ContentActionSupport.hasAccess(latestContentVersion.accessMask,
                            ContentActionSupport.accessLevel.Publish);
                        var isPublishAvailable = !isTranslationNeeded &&
                            hasPublishAccessRights &&
                            (!isPartOfActiveApproval && _this.inlinePublishCommand.canPublish());

                        this.onChangeHandle = on(this.formContainer, "isDirty", function () {
                            var isDirty = this.formContainer.get("isDirty");
                            isPublishAvailable = !isTranslationNeeded &&
                                hasPublishAccessRights &&
                                (!isPartOfActiveApproval && (_this.inlinePublishCommand.canPublish() || isDirty));
                            callback(this, {
                                isPublishAvailable: isPublishAvailable,
                                isDirty: isDirty
                            });
                        }.bind(this));
                        this.own(this.onChangeHandle);

                        callback(this, {
                            isPublishAvailable: isPublishAvailable
                        });
                    }.bind(this));
                }.bind(this));
                //this.resize(); // contentLayoutWidget

                return this;
            },

            translateContent: function (contentLink, language, callback) {
                // show translate form
                var container = domConstruct.create("div");

                this._clearForm();
                domConstruct.place(container, this.content);
                this.formContainer = new TranslateFormContainer({
                    isInlineCreateEnabled: this.isInlineCreateEnabled,
                    isTranslationNeeded: true
                }, container, "last");

                when(this._contentStore.get(contentLink)).then(function (contentData) {
                    this.formContainer.reloadMetadata(contentData, contentData.contentTypeID);
                    this.formContainer.createContentViewModel.parent.missingLanguageBranch = {
                        preferredLanguage: language
                    }
                    this.own(on(this.formContainer, "isDirty", function () {
                        var isDirty = this.formContainer.get("isDirty");
                        callback(this, {
                            isDirty: isDirty
                        });
                    }.bind(this)));
                    this.own(this.formContainer);
                    callback(this, {
                        isDirty: false
                    });
                }.bind(this));

                this.resize(); // contentLayoutWidget
                this.translate = true;
                return this;
            },

            saveForm: function () {
                if (!this.formContainer.validate()) {
                    return new Deferred().reject();
                }

                tracker.trackEvent("contentManager_saveForm");

                //TODO: CreateFormContainer from block-enhancements should return a promise, fix it and bump the dependency version
                //TODO: that 'when' should not be needed after that change
                return when(this.formContainer.saveForm());
            },

            publish: function () {
                return this.inlinePublishCommand.tryToSaveAndPublish(this.formContainer);
            },

            createContent: function (contentTypeId, parentContentId, callback) {
                this.contentStatusMessage.classList.toggle("dijitHidden", true);

                var container = domConstruct.create("div");

                this._clearForm();
                domConstruct.place(container, this.content);

                when(this._contentStore.get(parentContentId)).then(function (content) {
                    if (!content) {
                        return;
                    }

                    this.formContainer = new CreateNewBlockEditFormContainer({
                        autoPublish: true //temporary true, because otherwise content will be automatically added to the repository
                    }, container, "last");

                    this.formContainer.createContentViewModel.createAsLocalAsset = false;

                    this.formContainer.reloadMetadata(content, contentTypeId).then(function () {
                        this.formContainer.createContentViewModel.autoPublish = false;
                    }.bind(this));
                    this.own(on(this.formContainer, "formCreated", function () {
                        this.resize(); // contentLayoutWidget
                    }.bind(this)));
                    this.own(on(this.formContainer, "isDirty", function () {
                        var isDirty = this.formContainer.get("isDirty");
                        callback(this, {
                            isDirty: isDirty
                        });
                    }.bind(this)));
                    this.own(this.formContainer);
                    callback(this, {
                        isDirty: false
                    });
                    tracker.trackEvent("contentManager_createContent");
                }.bind(this));

                return this;
            },

            markAsReady: function () {
                var contentViewModel = this.formContainer._model;

                tracker.trackEvent("contentManager_markAsReady");

                if (this._isTransitionAvailable(contentViewModel.contentData, "readyforreview")) {
                    var readyForReview = new ReadyForReview();
                    readyForReview.set("model", contentViewModel);
                    return readyForReview.execute();
                } else {
                    var sendForReview = new SendForReview();
                    sendForReview.set("model", contentViewModel);
                    return sendForReview.execute();
                }
            },

            cancelReview: function (contentLink) {
                return when(this._contentDataStore.get(contentLink)).then(function (content) {
                    var viewModel = new ContentViewModel({
                        contentLink: contentLink,
                        contextTypeName: "epi.cms.contentdata"
                    });

                    if (this._isTransitionAvailable(content, "cancelreview")) {
                        var cancelReview = new CancelReview();
                        cancelReview.set("model", viewModel);
                        return this._approvalService.getApproval(contentLink).then(function (approval) {
                            cancelReview.set({
                                canExecute: !!approval,
                                approval: approval
                            });
                            return cancelReview.execute();
                        }.bind(this));
                    } else {
                        var withdrawCommand = new Withdraw();
                        withdrawCommand.set("model", viewModel);
                        return withdrawCommand.execute();
                    }
                }.bind(this));
            },

            _isTransitionAvailable: function (content, transition) {
                return content.transitions.some(function (x) {
                    return x.name === transition;
                });
            },

            _clearForm: function () {
                if (this.formContainer) {
                    this.formContainer.destroyRecursive();
                }
                if (this.content.hasChildNodes()) {
                    this.formContainer.destroy();
                    while (this.content.firstChild) {
                        this.content.removeChild(this.content.firstChild);
                    }
                }
            }
        });
    });
