//Episerver library
import Start from '@episerver/spa-core';

//Application
import config from 'app/Config';
import 'app/styles.scss';

Start(config);