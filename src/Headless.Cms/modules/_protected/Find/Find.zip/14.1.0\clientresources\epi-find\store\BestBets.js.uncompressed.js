﻿define("epi-find/store/BestBets", [
    "dojo/_base/config",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    "./ResourceStore",
    "dojo/_base/json",
    "epi-saas-base/RetryableXhrWrapper"
],
    function (config,
        declare,
        lang,
        Deferred,
        ResourceStore,
        json,
        RetryableXhrWrapper
    ) {

        return declare([ResourceStore], {
            // summary:
            //		This is a store for RelateQueries and Autocomplete.
            //		It implements dojo/store/api/Store.

            priorityProperty: "priority",
            maxPriority: 2147483647,

            constructor: function (options) {
                this.idProperty = "id";
                this.listProperty = "hits";
                this.itemProperty = "item";
                this.xhrHandler = new RetryableXhrWrapper(options ? options.handlerOptions : null);
                declare.safeMixin(this, options);
            },

            query: function (query, options) {
                // summary:
                //      Query method adapted to the nature of related queries endpoint.
                // description:
                //      Utilises the epi/shell/store/JsonRest "id-property to endpoint path" rewrite functionality
                //      to add "/list" to the endpoint target url on query requests.
                // tags:
                //      public
                query = lang.clone(query || {});
                query[this.idProperty] = options && options.apiName ? options.apiName : "list";
                return this.inherited(arguments, [query, options]);
            },

            get: function (id, options) {
                // summary:
                //      Retrieves an object by its identity. This will trigger a GET request to the server using
                //      the url `this.target + id`.
                // id: Number
                //      The identity to use to lookup the object.
                // options: Object?
                //      The optional options for the request header.
                // returns:
                //      The object in the store that matches the given id.
                // tags:
                //      public

                var headers = options || {};
                headers.Accept = "application/javascript, application/json";
                var url = config.find.siteServiceApiBaseUrl + "bestbets/get?id=";
                var hasId = typeof id != "undefined";

                var params = {
                    url: hasId ? url + id : url,
                    handleAs: "json",
                    headers: headers,
                    preventCache: this.preventCache
                };

                var result = this.xhrHandler.xhrGet(this._mixinDefaultParams(params));
                self = this;

                return result.then(function (data) {
                    return self._getItem(data);
                });
            },

            put: function (object, options) {

                options = options || {};

                var paramHeaders = {
                    "Content-Type": "application/json",
                    "If-Match": options.overwrite === true ? "*" : null,
                    "If-None-Match": options.overwrite === false ? "*" : null,
                    Accept: "application/javascript, application/json"
                };

                var url = config.find.siteServiceApiBaseUrl + "bestbets/post";
                var params = {
                    url: url,
                    postData: json.toJson(object),
                    handleAs: "json",
                    headers: paramHeaders
                };

                var result = this.xhrHandler.xhr("POST", this._mixinDefaultParams(params));
                var self = this;
                var deferred = new Deferred()
                return result.then(function (data) {
                    if (data && typeof data === "object") {
                        var dataItem = self._getItem(data), id = self.getIdentity(dataItem || {});
                        if (self.returnUpdatedItemFromPut) { // in case if an endpoint does modify the object
                            return self.get(id);
                        }
                        if (dataItem && id) {
                            object[self.idProperty] = id;
                        }
                        return object;
                    }
                    else {
                        deferred.resolve(data);
                    }
                });
            },

            remove: function (id, options) {
                var headers = {};
                headers.Accept = "application/javascript, application/json";
                headers["Content-Type"] = "application/json";

                options = options || {};

                var result = this.xhrHandler.xhr("DELETE", this._mixinDefaultParams({
                    url: config.find.siteServiceApiBaseUrl + "bestbets/delete?id=" + id,
                    headers: headers,
                    postData: json.toJson(options),
                    handleAs: "json"
                }));

                var self = this, deferred = new Deferred();
                result.then(function (data) {
                    if (data && typeof data === "object") {
                        // a workaround for observable, remove should return plain ID instead of object
                        deferred.resolve(self.getIdentity(data));
                    }
                    else {
                        deferred.resolve(data);
                    }
                }, function (error) {
                    deferred.reject(error);
                });

                return deferred;
            },

            _mixinDefaultParams: function (params) {
                // summary:
                //      Mix the params and the defaultRequestParams into a new object.
                // params: Object
                //      The params to mix with defaultRequestParams.
                // returns: Object
                //      The new combined params.
                // tags:
                //      private

                return lang.mixin({}, this.defaultRequestParams, params);
            }

        });

    });