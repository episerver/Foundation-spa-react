//>>built
define("epi-find/nls/fr/ConfigModel",{"configErrorMessage":"Erreur de lecture de configuration."});