﻿define("epi-find/_ControllerBase", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/query",
    "dojo/on",

    "dijit/layout/ContentPane",
    "dojo/dom-class",

    "epi-saas-base/_PropagatingDestroyableMixin",
    "./ApplicationState",
    "./ResponsiveMode"
],

function (declare,
    lang,
    array,
    query,
    on,
    ContentPane,
    domClass,
    _PropagatingDestroyableMixin,
    ApplicationState,
    ResponsiveMode
    ) {

    return declare([_PropagatingDestroyableMixin], {
        // summary:
        //          Controller for views.

        applicationContainer: null,

        rootNode: null,
        rootWidget: null,
        currentResponsiveMode: null,

        widgetsInAnimation: null,
        _started: false,

        constructor: function(application, rootNode) {
            // summary:
            //          Initializes the controller instance
            this.widgetsInAnimation = ApplicationState.widgetsInAnimation;
            this.application = application;
            this.applicationContainer = rootNode;
            this.globalNavigation = query(".epi-navigationContainer")[0];
        },

        isStarted: function() {
            return this._started;
        },

        startup: function() {
            if (this.isStarted()) {
                return;
            }
            this._createRootWidget();
            this.own(
                on(ResponsiveMode, "modeChanged", lang.hitch(this, function(mode) {
                    this.onModeChanged(mode);
                    this.currentResponsiveMode = mode;
                }))
            );
            this.currentResponsiveMode = ResponsiveMode.currentMode.name;
            this._started = true;
        },

        refresh: function() {
            //  summary:
            //      Called when model data has been invalidated and needs to be refreshed
            //      Default behaviour is to try to refresh the rootWidget

            var children = this.rootWidget.getChildren();
            for(var i in children) {
                var widget = children[i];
                if (widget.refresh) {
                    widget.refresh();
                }
            }
        },

        destroy: function () {
            if (!this.isStarted()) {
                return;
            }
            this.inherited(arguments);
            this._started = false;
        },

        onModeChanged: function(mode) {
        },

        _createRootWidget: function () {

            if(!this.rootWidget) {
                this.rootWidget = new ContentPane();
                domClass.add(this.rootWidget.domNode, "epi-pane-wrapper");
                this.own(this.rootWidget);
            }

        },

        _setupView: function (childWidgets, /* bool */destroy) {

            // This whole method needs refactoring (and rethinking). Right now, the _setupView needs to move already existing
            // views out of the way.

            var appNode = this.applicationContainer;
            if (array.indexOf(appNode.children, this.rootWidget.domNode) === -1) {
                while(appNode.firstChild) {
                    appNode.removeChild(appNode.firstChild);    // Removing lazy space hoggers
                }
                this.rootWidget.placeAt(appNode);
                this.rootWidget.startup();
            }

            if (!lang.isArray(childWidgets)) {
                childWidgets = [childWidgets];
            }
            // remove views that are not in the required childWidgets
            array.forEach(this.rootWidget.getChildren(), lang.hitch(this, function (child) {
                if (array.indexOf(childWidgets, child) === -1 &&// if not in the specified array
                    !this._isWidgetAnimating(child)) { // and not in the currently animated widgets
                    this.rootWidget.removeChild(child);
                    if (destroy) {
                        child.destroyRecursive();
                    }
                }
            }));
            array.forEach(childWidgets, lang.hitch(this, function (child) {
                if (!this._isWidgetAdded(child)) {
                    this.rootWidget.addChild(child);
                    child.startup();
                    if (child.resize) {
                       child.resize();
                    }
                }
            }));
            this.onModeChanged(this.currentResponsiveMode);
        },

        _isWidgetAdded: function (widget) {
            return (array.indexOf(this.rootWidget.getChildren(), widget) !== -1);
        },

        _isWidgetAnimating: function (widget) {
            return array.indexOf(this.widgetsInAnimation, widget) >= 0;
        },

        _removeWidgetsInAnimation: function (destroy) {
            array.forEach(this.widgetsInAnimation, lang.hitch(this, function (child) {
                if (this.rootWidget.getIndexOfChild(child)!==-1)
                {
                    this.rootWidget.removeChild(child);
                    if (destroy) {
                        child.destroyRecursive();
                    }
                }
            }));
            this.widgetsInAnimation.splice(0);
        }
    });
});
