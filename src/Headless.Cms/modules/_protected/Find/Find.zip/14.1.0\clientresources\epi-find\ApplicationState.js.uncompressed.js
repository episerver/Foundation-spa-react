﻿define("epi-find/ApplicationState", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/config",
    "dojo/Stateful",
    "dojo/when"
], function (declare,
             lang,
             config,
             Stateful,
             when) {
    var ApplicationState = declare([Stateful], {
            // current: dojo/Stateful
            //      Current state bag
            current: null,

            // _stateHistory: Array
            //      State history
            _stateHistory: null,

            // widgetsInAnimation: Array
            //      Array of widgets currently animating
            widgetsInAnimation: null,
            
            username: null,

            context: null,

            site: null,

            language: null,

            reset: function() {
                // summary:
                //      Reset current state
               if (!this.current) {
                   return;
               }
               for (var prop in this.current) {
                   if (this.current.hasOwnProperty(prop)) {
                       delete this.current[prop];
                   }
               }
            },

            push: function() {
                // summary:
                //      Push current state to the state history
                if (!this.current) {
                    return;
                }
                var currentState = this.current;
                this._stateHistory.push(currentState);
                this.current = new Stateful();
            },

            pop: function() {
                // summary:
                //      Pop the last state from the history
                var currentState = this._stateHistory.pop();
                if (!currentState) {
                    this.reset();
                }
                else {
                    this.current = currentState;
                }

                return this.current;
            },
            
            _contextGetter: function() {
                if (!this.context) {
                    var contextStore = config.dependencies["epi-find.ContextStore"];
                    this.context = contextStore.query({}).then(lang.hitch(this, function (value) {
                        this.set("context", value);
                        return value;
                    }));
                }
                return this.context;
            },
            
            _contextSetter: function(value) {
                this.set("username", value.Username);
            },

            isThisMe: function (username) {
                return username && username.toLowerCase() === this.get("username").toLowerCase();
            },

            constructor: function () {
                this.widgetsInAnimation = [];
                this.current = new Stateful();
                this.set("username", config.find && config.find.init ? config.find.init.username : "");
                // TODO: Consider read user name from contextStore
                this._stateHistory = [];
            }
        }
    );
    var appState = new ApplicationState();
    return appState;
});
