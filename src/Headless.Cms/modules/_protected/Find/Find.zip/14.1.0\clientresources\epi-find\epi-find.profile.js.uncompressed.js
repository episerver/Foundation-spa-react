/*
Package configuration for Find client side resources.
*/
// Get the dojo toolkit dir from command line
function constructPath(rootId, relPath) {
    return combinePaths(getCommandLineArg(rootId), relPath);
}

function combinePaths(first, second) {
    return first.replace(/\/*$/, "") + "/" + second;
}

function getCommandLineArg(name) {
    var args = dojo.config.commandLineArgs;

    var argName = "--" + name;

    for (var p in args) {
        if (args[p] == argName) {
            return args[parseInt(p) + 1][0];
        }
    }

    throw new Error("Missing command line parameter '" + argName + "'");
}

function getDefaultResourceTags(mixins) {
    var tags = {
        test: function (filename, mid) {
            return /\/test\//.test(mid) || /\/demos\//.test(mid) || /\/doc\//.test(mid);
        },
        amd: function (filename, mid) {
            return /\.js$/.test(filename);
        }
    };
    for (var i in mixins) {
        tags[i] = mixins[i];
    }
    return tags;
}

var dojoxModules = new Array(
    "dojox/main",
    "dojox/layout",
    "dojox/gauges",
    "dojox/form",
    "dojox/gesture",
    "dojox/embed",
    "dojox/lang",
    "dojox/gfx",
    "dojox/charting",
    "dojox/data",
    "dojox/sql",
    "dojox/storage",
    "dojox/flash",
    "dojox/rpc",
    "dojox/atom",
    "dojox/json",
    "dojox/fx",
    "dojox/i18n",
    "dojox/color",
    "dojox/math",
    "dojox/mdnd",
    "dojox/form",
    "dojox/grid",
    "dojox/string",
    "dojox/dtl",
    "dojox/html",
    "dojox/xml",
    "dojox/date",
    "dojox/widget",
    "dojox/validate",
    "dojox/encoding",
    "dojox/socket",
    "dojox/mvc",
    "dojox/uuid",
    "dojox/gfx/svg",
    "dojox/gfx/path");

var dojoxModulesExclude = ["dojox/data/s3", "dojox/storage", "dojox/rpc/OfflineRest"];

var profile = {
    basePath: "./",
    cssOptimize: false,
    internStrings: true,
    layerOptimize: "shrinksafe",
    mini: true,
    copyTests: false,
    optimize: "shrinksafe",
    stripConsole: "warn",
    selectorEngine: "acme",
    transforms: { writeOptimized: [constructPath("sharedRootPath", "DtkBuild/transforms/writeOptimized.js"), "write"] },
    destBasePath: "../epi-find/",
    packages: [
    {
       name: "dojo",
       location: "../dojo",
       resourceTags: {
           amd: function (filename, mid) {
               return /\.js$/.test(filename);
           }
       },
    },
    {
       name: "dijit",
       location: "../dijit",
       resourceTags: {
           amd: function (filename, mid) {
               return /\.js$/.test(filename);
           }
       }
    },
    {
       name: "dojox",
       location: "../dojox",
       resourceTags: {
           amd: function (filename, mid) {
               return /\.js$/.test(filename);
           },
            ignore: function(filename, mid) {
                if (/\/test\//.test(mid) || /\/demos\//.test(mid) || /\/doc\//.test(mid) || /Tester/.test(mid)) {
                    return true;
                }

                for (var i = 0; i < dojoxModulesExclude.length; i++) {
                    if (mid.indexOf(dojoxModulesExclude[i]) == 0) {
                        return true;
                    }
                }

                for (var i = 0; i < dojoxModules.length; i++) {
                    if (mid.indexOf(dojoxModules[i]) == 0) {
                            return false;
                        }
                    }

                    return true;
                }
           }
        },
        {
           name: "dgrid",
           location: "../dgrid",
           resourceTags: {
               amd: function (filename, mid) {
                   return /\.js$/.test(filename);
               }
           }
        },
        {
           name: "put-selector",
           location: "../put-selector",
           resourceTags: {
               amd: function (filename, mid) {
                   return /\.js$/.test(filename);
               }
           }
        },
        {
           name: "xstyle",
           location: "../xstyle",
           resourceTags: {
               amd: function (filename, mid) {
                   return /\.js$/.test(filename);
               }
           }
        },
        {
           name: "epi",
           location: "../epi",
           resourceTags: getDefaultResourceTags()
        },
        {
           name: "epi-cms",
           location: "../epi-cms",
           resourceTags: getDefaultResourceTags()
        },
        {
           name: "epi-saas-base",
           location: "../epi-saas-base",
           resourceTags: getDefaultResourceTags()
        },
        {
           name: "epi-find",
           main: "main",
           location: "../epi-find",
           resourceTags: getDefaultResourceTags()
        }
    ],
    layers: {
        "epi-find/run": {
          exclude: ["epi/i18n"],
          include: [
            "dojox/gfx/path",
            "dojox/gfx/svg",
            "xstyle/core/load-css",
            "dijit/TooltipDialog",
            "dojo/fx/Toggler",
            "dojo/dnd/AutoSource",
            "dojo/dnd/Target",
            "dijit/layout/StackController"
          ]
        }
    }
};