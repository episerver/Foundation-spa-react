require({cache:{
'epi-languagemanager/LanguageManagerModule':function(){
﻿define("epi-languagemanager/LanguageManagerModule", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    // epi
    "epi/_Module",
    "epi/routes",
    "epi/dependency",
    "epi/shell/request/mutators",
    // epi-cms
    "epi-cms/project/viewmodels/_ProjectViewModel",
    "epi-cms/project/ProjectItemQueryEngine",

    // language manager
    "epi-languagemanager/ModuleSettings",
    "epi-languagemanager/component/command/DownloadTranslationPackage",
    "epi-languagemanager/component/command/UploadTranslationPackages",
    "epi-languagemanager/component/viewmodel/UploadTranslationPackagesViewModel",
    "epi-languagemanager/request/LanguageManagerContentLanguage",
    "epi-languagemanager/request/LanguageManagerProjectMode"    
],
function (
// dojo
    declare,
    lang,

    // epi
    _Module,
    routes,
    dependency,
    mutators,

    // epi-cms
    _ProjectViewModel,
    projectItemQueryEngine,

    // language manager
    ModuleSettings,
    DownloadTranslationPackage,
    UploadTranslationPackages,

    UploadTranslationPackagesViewModel,
    languageManagerContentLanguage,
    languageManagerProjectMode
) {

    return declare([_Module], {

        // _settings: [private] Object
        //      Information which sent by LanguageManager module (in module.config file). We can read helpPath, moduleDependencies, routes, ... from here
        _settings: null,

        constructor: function (settings) {
            this._settings = settings;
        },

        initialize: function () {
            // summary:
            //      Initialize module
            //
            // description:
            //      Dependencies registered by this module are: 'LanguageManage application'

            this.inherited(arguments);

            mutators.add(languageManagerProjectMode);
            mutators.add(languageManagerContentLanguage);

            declare.safeMixin(ModuleSettings, this._settings);

            // Initialize stores
            var registry = this.resolveDependency("epi.storeregistry"),
                route = this._getRestPath("language-manager");

            this._hashWrapper = dependency.resolve("epi.shell.HashWrapper");

            registry.add("epi-languagemanager.settings", this._settings);
            registry.create("epi-languagemanager.language-manager", route, { idProperty: "id" });
            // We need to create projectItemStore ourself to inject X-EPiContentLanguage as header param later
            registry.create("epi-languagemanager.project.item", this._getCMSRestPath("project-item"), { queryEngine: projectItemQueryEngine });
            registry.create("epi-languagemanager.project", this._getCMSRestPath("project"));

            this._injectCommandsToProjectView();

            // Register route for "epi.cms.languagemanager.compareediting" context
            var contextService = this.resolveDependency("epi.shell.ContextService");
            contextService.registerRoute("epi.cms.languagemanager.compareediting", lang.hitch(this, this._redirectContext));
        },

        _redirectContext: function (/*Object*/context, /*Object*/callerData) {
            // summary:
            //      Redirect context
            // tags:
            //      private

            this._hashWrapper.onContextChange(context, callerData);
        },

        _getCMSRestPath: function (name) {
            return routes.getRestPath({ moduleArea: "cms", storeName: name });
        },

        _getRestPath: function (name) {
            // summary:
            //      Get the rest path to a specified store.
            // prameters:
            //      name: The name of the store to get.
            // tags:
            //      private

            return routes.getRestPath({ moduleArea: "EPiServer.Labs.LanguageManager", storeName: name });
        },

        _injectCommandsToProjectView: function () {
            // summary:
            //      HACK: inject menu items [Download Translation Package] and [Upload Translation Package] into Project view
            // tags:
            //      private

            var exportingUrl = this._settings.exportingUrl;

            var orgMethod = _ProjectViewModel.prototype.postscript;

            lang.mixin(_ProjectViewModel.prototype, {
                postscript: function () {

                    orgMethod.call(this);

                    var commands = this.get("commands");
                    commands.push(
                        new DownloadTranslationPackage({
                            category: "publishmenu",
                            model: this,
                            sortOrder: 400,
                            exportingUrl: exportingUrl
                        }),
                        new UploadTranslationPackages({
                            category: "publishmenu",
                            model: new UploadTranslationPackagesViewModel(),
                            sortOrder: 500
                        })
                    );
                }
            });
        }
    });

});

},
'epi-cms/project/ProjectItemQueryEngine':function(){
define("epi-cms/project/ProjectItemQueryEngine", [
    "epi-cms/core/ContentReference",
    "epi/shell/store/queryUtils"
], function (
    ContentReference,
    queryUtils
) {
    return function (query, options) {
        // summary:
        //      A QueryEngine configured to work with project items.
        //
        // query: Object
        //
        // options: dojo/store/api/Store.QueryOptions?
        //      An object that contains optional information such as sort, start, and count
        //
        // tags:
        //      internal xproduct
        //
        // returns: Function
        //		A QueryEngine matching the queries sent to the ProjectItemStore

        options = options || {};

        options.comparers = {
            contentLinks: function (queryValue, instance) {
                return queryValue.some(function (link) {
                    return ContentReference.compareIgnoreVersion(link, instance.contentLink);
                });
            }
        };

        return queryUtils.createEngine(query, options);
    };
});

},
'epi/shell/store/queryUtils':function(){
define("epi/shell/store/queryUtils", [], function () {

    function validSortOptions(sortOptions) {
        return sortOptions instanceof Array && sortOptions.length > 0;
    }

    var module =  {
        // summary:
        //      A QueryEngine configured to work with project items
        // tags:
        //      internal

        createFilter: function (query, options) {
            // summary:
            //      A factory usable for when creating filters for store queryEngines.
            //
            // query: Object
            //
            // options: dojo/store/api/Store.QueryOptions?
            //		An object that contains optional information such as sort, start, and count.
            //      It also supports having an array of ignore key values for query parts that
            //      should not be used in the filter and a compare dictionary for custom
            //      filtering logic.
            //
            //          {
            //              ignore: ["query", "prop2"],
            //              comparers: {
            //                  "prop3": function (queryPart, instance) { return true; }
            //              }
            //          }
            //
            // returns: Function
            //		A filter function

            var filter;

            options = options || {};

            // create our matching query function
            switch (typeof query) {

                case "object" :
                case "undefined" :
                    filter = function (item) {

                        return !query || Object.keys(query).every(function (key) {

                            var ignoreKeys = options.ignore,
                                comparer = options.comparers && options.comparers[key],
                                queryValue = query[key];

                            // Check if the query value should be ignored by the filter
                            if (ignoreKeys && ignoreKeys.indexOf(key) !== -1) {
                                return true;
                            }

                            // If there is a special comparer function registered for the query key then use that
                            if (comparer) {
                                return comparer(queryValue, item);
                            }

                            // Default to equality comparison of the query value and what's in in the items property
                            return queryValue === item[key];
                        });
                    };

                    break;
                default:
                    throw new Error("Can not query with a " + typeof query);
            }

            return filter;
        },

        createSorter: function (sortOptions) {
            // summary:
            //      A factory usable when creating sorters for store queryEngines.
            //
            // sortOptions: Object[]
            //          [
            //              { attribute: "name", descending: false },
            //              { attribute: "startDate", descending: true }
            //          ]
            //
            // returns: Function
            //		A sort function

            if (!validSortOptions(sortOptions)) {
                throw new Error("Argument must be an array containing sortOptions");
            }

            return function (a, b) {

                var aValue, bValue;

                for (var sort, i = 0; (sort = sortOptions[i]); i++) {
                    aValue = a[sort.attribute];
                    bValue = b[sort.attribute];

                    if (typeof aValue === "string" && typeof bValue === "string") {
                        aValue = aValue.toLowerCase();
                        bValue = bValue.toLowerCase();
                    }

                    if (aValue !== bValue) {
                        return sort.descending === (aValue > bValue) ? -1 : 1;
                    }
                }

                return 0;
            };
        },

        createExecuter: function (filter, sorter, start, count) {
            // summary:
            //      A factory usable for when creating the execute function of a queryEngines.
            //
            // filter: Function?
            //      A function capable of matching objects against a query
            //
            // sorter: Function?
            //      A function capable of sorting a collection
            //
            // start: Number?
            //      If used with pagination the starting point of the result collection
            //
            // count: Number?
            //      If used with pagination the number of items to return from the result collection
            //
            // returns: Function
            //		An execute function

            var begin = start || 0,
                end = count ? begin + count : Infinity;

            return function (results) {

                var total;

                // Make sure to create a new array
                results = filter ? results.filter(filter) : results.slice(0);

                sorter && results.sort(sorter);

                if (start || count) {
                    total = results.length;
                    results = results.slice(begin, end);
                    results.total = total;
                }

                return results;
            };
        },

        createEngine: function (query, options) {
            // summary:
            //      A factory for creating store queryEngines.
            //
            // query: Object
            //
            // options: dojo/store/api/Store.QueryOptions?
            //		An object that contains optional information such as sort, start, and count.
            //      It also supports having an array of ignore key values for query parts that
            //      should not be used in the filter and a compare dictionary for custom
            //      filtering logic.
            //
            //          {
            //              ignore: ["query", "prop2"],
            //              comparers: {
            //                  "prop3": function (queryPart, instance) { return true; }
            //              }
            //          }
            //
            // returns: Function
            //		A queryEngine function

            var filter,
                sorter,
                engine;

            options = options || {};

            filter = module.createFilter(query, options);
            sorter = validSortOptions(options.sort) ? module.createSorter(options.sort) : null;
            engine = module.createExecuter(filter, sorter, options.start, options.count);
            engine.matches = filter;

            return engine;
        }
    };

    return module;
});

},
'epi-languagemanager/ModuleSettings':function(){
﻿define("epi-languagemanager/ModuleSettings", [],
    function () {

        // module:
        //      epi-languagemanager/ModuleSettings
        // summary:
        //      Module settings for EPiServer LanguageManager.
        //      Stores shared settings, constants for entire module.
        // tags:
        //      public

        return {
        };

    });

},
'epi-languagemanager/component/command/DownloadTranslationPackage':function(){
﻿define([
// dojo
    "dojo/_base/declare",
    // epi
    "epi/shell/Downloader",

    // ep cms
    "epi-cms/project/command/_ProjectCommand",

    // language manager
    "epi-languagemanager/ModuleSettings",
    // resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// dojo
    declare,
    // epi
    Downloader,
    // epi cms
    _ProjectCommand,

    // language manager
    ModuleSettings,
    // resources
    res
) {

    return declare([_ProjectCommand], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.downloadtranslationpackage,

        // category: [readonly] String
        //      A category which provides a hint about how the command could be displayed.
        category: "publishmenu",

        // iconClass: [public] String
        //      The icon class of the command to be used in visual elements.
        iconClass: "epi-iconPackage",

        postscript: function () {
            this.inherited(arguments);
        },

        // propertiesToWatch: [public] Array
        //      A list of properties to watch for changes.
        propertiesToWatch: ["selectedProject"],

        _onPropertyChanged: function () {
            // summary:
            //      Sets canExecute, isAvailable based on the state of the model.
            // tags:
            //      protected

            if (!this.model.selectedProject) {
                return;
            }

            var hasProjectItems = this.model && this._hasProjectItem(this.model.selectedProject),
                isProjectPublished = this.model.selectedProject && this.model.selectedProject.status === "published";

            // set canExecute and isAvailable depend on project item count and status
            this.set("canExecute", !isProjectPublished && hasProjectItems);
            this.set("isAvailable", !isProjectPublished);
        },

        _hasProjectItem: function (project) {
            // summary:
            //      Check if the project contains any project items.
            // tags:
            //      protected

            // itemStatusCount is null outside Project Overview
            // as an effect from CMS - 7977
            if (!project.itemStatusCount) {
                return false;
            }

            return Object.keys(project.itemStatusCount).some(function (key) {
                if (project.itemStatusCount[key] > 0) {
                    return true;
                }
            });
        },

        _execute: function () {
            // summary:
            //      Gets selected project and pass its identification to server in order to get its translation package.
            // tags:
            //      protected

            var selectedProject = this.model && this.model.get("selectedProject");
            if (!selectedProject || !selectedProject.id) {
                return;
            }

            if (!this.exportingUrl) {
                this.exportingUrl = ModuleSettings.exportingUrl;
            }

            // Builds request translation package url that used to send to server
            var exportingUrl = this.exportingUrl + "?projectId=" + selectedProject.id;

            Downloader.download(exportingUrl, selectedProject.name);
        }
    });
});

},
'epi-languagemanager/component/command/UploadTranslationPackages':function(){
﻿define([
// dojo
    "dojo/_base/declare",

    // language manager
    "epi-languagemanager/component/command/CommandBase",
    // resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
    // dojo
    declare,

    // language manager
    CommandBase,
    // resources
    res
) {

    return declare([CommandBase], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.uploadtranslationpackages,

        category: "context",

        // fileCollection: [public] Array
        //      An array of files to upload.
        //      When null, only show upload form to select files for uploading; otherwise, upload files in list.
        fileCollection: null,

        // iconClass: [public] String
        //      The icon class of the command to be used in visual elements.
        iconClass: "epi-iconUpload",

        constructor: function () {
            // summary:
            //      Sets initialize values for this command.
            // tags:
            //      public, extensions

            this.inherited(arguments);

            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _execute: function () {
            // summary:
            //      Executes this command. Call upload method from model.
            // tags:
            //      protected, extensions

            if (!this.model || typeof this.model.uploadTranslationPackages !== "function") {
                return;
            }

            this.model.uploadTranslationPackages(this.fileCollection);

            // Clear fileCollection after uploading, to avoid of displaying last uploaded item on upload dialog.
            this.fileCollection = null;
        }
    });
});

},
'epi-languagemanager/component/command/CommandBase':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",

    // Epi Framework
    "epi/shell/command/_Command",

    // Language mangager
    "epi-languagemanager/component/_ExtensionContextMixin"

], function (
// Dojo base
    declare,

    // Epi Framework
    _Command,

    // Language mangager
    _ExtensionContextMixin

) {


    return declare([_Command, _ExtensionContextMixin], {

        isPage: function (context) {
            // summary:
            //		Check the input context is Page or not.
            // tags:
            //		protected

            return context && context.capabilities && context.capabilities.isPage;
        }
    });
});

},
'epi-languagemanager/component/_ExtensionContextMixin':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",

    // EPi CMS
    "epi-cms/ApplicationSettings",
    "epi-cms/core/ContentReference"

], function (
// Dojo base
    declare,

    // Epi CMS
    ApplicationSettings,
    ContentReference

) {


    return declare(null, {

        isWastebasket: function (contentData) {
            // summary:
            //		Check the current context is Wasterbasket page or not.
            // contentData: [Object]
            //      The content data model
            // tags:
            //		protected

            return contentData && new ContentReference(contentData.contentLink).id === ApplicationSettings.wastebasketPage;
        },

        isRoot: function (contentData) {
            // summary:
            //		Check the current context is Root page or not.
            // contentData: [Object]
            //      The content data model
            // tags:
            //		protected

            return contentData && new ContentReference(contentData.contentLink).id === ApplicationSettings.rootPage;
        },

        isSupportedType: function (contentData) {
            // summary:
            //		Check the contentData's type is supported or not.
            // contentData: [Object]
            //      The content data model
            // tags:
            //		protected

            return this.model.settings.restrictedTypes.indexOf(contentData.typeIdentifier) === -1;
        }
    });
});

},
'epi-languagemanager/component/viewmodel/UploadTranslationPackagesViewModel':function(){
﻿define([
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Stateful",

    // epi
    "epi/dependency",
    "epi/routes",
    "epi/shell/widget/dialog/Dialog",
    "epi-cms/widget/MultipleFileUpload",
    "epi-cms/widget/viewmodel/MultipleFileUploadViewModel",

    // resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// dojo
    declare,
    lang,
    Stateful,
    // epi
    dependency,
    routes,
    Dialog,
    MultipleFileUpload,
    MultipleFileUploadViewModel,

    // resources
    res
) {

    return declare([Stateful], {
        // resources
        res: res,

        postscript: function () {
            // summary:
            //      Initialize for upload
            // tags:
            //      public, extensions

            this.inherited(arguments);
        },

        uploadTranslationPackages: function (/*Array*/fileCollection) {
            // summary:
            //      Uploads translation package(s) to an indicated folder on server
            // fileCollection: [Array]
            //      List files to upload.
            //      When null, only show upload form to select files for uploading.
            //      Otherwise, upload files in list.
            // tags:
            //      public

            // Only create diaglog if it is not available, otherwise, re-use it.
            var uploader = new MultipleFileUpload({
                model: new MultipleFileUploadViewModel()
            });

            // Set the action path for upload form
            uploader.uploaderInput.uploadUrl = routes.getActionPath({
                moduleArea: "EPiServer.Labs.LanguageManager",
                controller: "TranslationPackageUpload",
                action: "Upload"
            });

            uploader.on("beforeUploaderChange", lang.hitch(this, function () {
                this._uploading = true;
            }));

            // Close multiple files upload dialog when stop uploading
            uploader.on("close", lang.hitch(this, function (uploading) {
                this._dialog && (uploading ? this._dialog.hide() : this._dialog.destroy());
            }));

            uploader.on("uploadComplete", lang.hitch(this, function (/*Array*/uploadFiles) {
                if (this._dialog && !this._dialog.open) {
                    this._dialog.destroy();
                }

                this._uploading = false;
            }));

            this._dialog = new Dialog({
                title: this.res.uploadtranslationpackages,
                dialogClass: "epi-dialog-upload",
                content: uploader,
                autofocus: true,
                defaultActionsVisible: false,
                closeIconVisible: false
            });

            // Only show close button for multiple files upload dialog
            this._dialog.definitionConsumer.add({
                name: "close",
                label: epi.resources.action.close, /* eslint-disable-line */
                action: function () {
                    uploader.close();
                }
            });

            this._dialog.resize({ w: 700 });
            this._dialog.show();

            uploader.upload(fileCollection);
        }
    });
});

},
'epi-languagemanager/request/LanguageManagerContentLanguage':function(){
﻿define([
    "dojo/Deferred"
], function (Deferred) {

    return {
        beforeSend: function (params) {
            // summary:
            //      Request mutator for adding the currently selected content language to a xhr request
            //      By the default, the [project-item] store always use current language (ContentLanguage.PreferredCulture),
            //      This module will chain the request and change the header key "x-EPiContentLanguage" with our custom language id.
            // params: Object
            //      The request parameters
            // tags: internal

            var options = params.options;
            if (options.postData) {
                var data;
                try {
                    data = JSON.parse(options.postData);
                } catch (e) { /*quiet*/ }

                if (data && data.modifyHeader === true && data.LanguageID) {
                    options.headers["X-EPiContentLanguage"] = data.LanguageID;
                }
            }

            var result = new Deferred();
            result.resolve(params);

            return result.promise;
        }
    };

});

},
'epi-languagemanager/request/LanguageManagerProjectMode':function(){
﻿define([
    "dojo/Deferred"
], function (Deferred) {

    return {
        beforeSend: function (params) {
            // summary:
            //      Request mutator for adding the currently selected project to a xhr request
            //      By the default, the Cms UI always sends the header key "x-EPiCurrentProject" with value is the current active project.
            //      This header value will take over the custom projectId which we want to add item to.
            //      This module will chain the request and change the header key "x-EPiCurrentProject" with our custom project-Id.
            // params: Object
            //      The request parameters
            // tags: internal

            var options = params.options;
            if (options.postData) {
                var data;
                try {
                    data = JSON.parse(options.postData);
                } catch (e) { /*quiet*/ }

                if (data && data.modifyHeader === true && data.id) {
                    options.headers["X-EPiCurrentProject"] = data.id;
                }
            }

            var result = new Deferred();
            result.resolve(params);

            return result.promise;
        }
    };

});

},
'epi-languagemanager/component/LanguageManager':function(){
﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/when",
    "dojo/topic",
    "dojo/json",
    "dojo/dom-construct",
    "dojo/dom-style",
    "dojo/dom-class",
    "dojo/dom-geometry",
    "dojo/dom-attr",
    "dojo/html",
    "dojo/store/Memory",
    "dojo/store/Observable",
    "dojo/on",
    "dojo/promise/all",
    "dojo/query",

    // Dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetBase",
    "dijit/_Container",
    "dijit/layout/_LayoutWidget",
    "dgrid/OnDemandGrid",
    "dgrid/Selection",

    // Dojox
    "dojox/widget/Standby",

    // EPi Framework
    "epi/dependency",
    "epi/Url",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/command/_WidgetCommandProviderMixin",
    "epi/shell/dgrid/util/misc",
    "epi/shell/widget/_FocusableMixin",
    "epi/shell/widget/dialog/Dialog",
    "epi/shell/widget/dialog/Alert",
    "epi/datetime",
    "epi/shell/command/withConfirmation",
    "epi/shell/widget/ContextMenu",
    "epi/shell/TypeDescriptorManager",

    // CMS
    "epi-cms/_ContentContextMixin",
    "epi-cms/core/ContentReference",
    "epi-cms/component/command/DeleteLanguageBranch",

    // Language Manager
    "epi-languagemanager/component/viewmodel/LanguageManagerViewModel",
    "epi-languagemanager/component/viewmodel/LanguageManagerViewModelWrapper",
    "epi-languagemanager/component/_ExtensionContextMixin",

    // Resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo
    declare,
    lang,
    aspect,
    when,
    topic,
    json,
    domConstruct,
    domStyle,
    domClass,
    domGeometry,
    domAttr,
    html,
    Memory,
    Observable,
    on,
    all,
    query,

    // Dijit
    _TemplatedMixin,
    _WidgetBase,
    _Container,
    _LayoutWidget,
    OnDemandGrid,
    Selection,

    // Dojox
    Standby,

    // EPi Framework
    dependency,
    Url,

    _ModelBindingMixin,
    _WidgetCommandProviderMixin,
    GridMiscUtil,
    _FocusableMixin,
    Dialog,
    Alert,
    epiDate,
    withConfirmation,
    ContextMenu,
    TypeDescriptorManager,

    // CMS
    _ContentContextMixin,
    ContentReference,
    DeleteLanguageBranch,

    // Language Manager
    LanguageManagerViewModel,
    LanguageManagerViewModelWrapper,
    _ExtensionContextMixin,

    // Resources
    res
) {

    return declare([_Container, _LayoutWidget, _TemplatedMixin, _ModelBindingMixin, _WidgetCommandProviderMixin, _FocusableMixin, _ContentContextMixin, _ExtensionContextMixin], {

        modulePath: null,
        isTranslatingSystemAvailable: null, // Determines whether current TranslatingService available

        model: null,
        context: null,
        contentData: null,
        store: null,

        grid: null,
        standby: null,

        commandProvider: null,
        commandProviderInitialized: null,

        _messageClassName: "epi-languageManagerMessage",

        // _hashWrapper: epi.shell.HashWrapper
        //    The hash wrapper instance.
        _hashWrapper: null,

        _inactiveCssClass: "inactive",
        _currentLanguageCssClass: "currentLanguage",
        _disabledCssClass: "disabled",
        _preferLanguageCssClass: "preferLanguage",
        _mouseOverCssClass: "epi-dgrid-mouseover",

        modelBindingMap: {
            context: ["context"],
            contentData: ["contentData"],
            store: ["store"],
            actionExecuted: ["actionExecuted"],
            actionExecuting: ["actionExecuting"]
        },

        templateString: '<div class="epi-languagemanager"></div>',

        postscript: function () {
            // summary:
            //      Initialize view model, setting up the grid and register events as well.
            // tags:
            //      protected

            this.inherited(arguments);

            this._hashWrapper = dependency.resolve("epi.shell.HashWrapper");

            var customGridClass = declare([OnDemandGrid, Selection]);
            this.grid = new customGridClass({
                columns: {
                    name: {
                        renderCell: lang.hitch(this, this._setupLanguageCollumn)
                    },
                    contentStatus: {
                        renderCell: lang.hitch(this, this._setupContentStatusCollumn)
                    },
                    existence: {
                        renderCell: lang.hitch(this, this._setupExistenceCollumn)
                    },
                    contextmenu: {
                        renderCell: function (item, value, node, options) {
                            var format = "<div class='epi-languageManagerEditAction' title='{0}'>\
                                            <span class='dijitInline dijitIcon epi-iconContextMenu epi-floatRight' title ='{1}'>&nbsp;</span>\
                                          <div>";
                            // TODO: make localization for tooltip
                            node.innerHTML = lang.replace(format, ["Context Menu", "Context Menu"]);
                        }
                    }
                },
                selectionMode: "single",
                showHeader: false
            }, this.domNode);

            when(this.getCurrentContext(), lang.hitch(this, function (ctx) {
                // set the query associate with current context
                this.grid.set("query", { contentLink: ctx.id });
                // init model for the widget
                this.set("model", this.model || new LanguageManagerViewModel({ modulePath: this.modulePath }));
                this.model = this._wrapModel(this.model);
            }));

            this._setupEvents();
            this._createContextMenu();

            // Save current states of the tools and navigation panes each time changed.
            // This data will be used to restore states of each pane after close compare mode of language manager addon.
            // We should listen and save each time one of pane changed.
            topic.subscribe("/epi/layout/pinnable/navigation/toggle", this._savePinnablePanesState);
            topic.subscribe("/epi/layout/pinnable/tools/toggle", this._savePinnablePanesState);
        },

        startup: function () {

            this.inherited(arguments);

            this.standby = new Standby({ target: "applicationContainer" });
            document.body.appendChild(this.standby.domNode);
            this.standby.startup();
        },

        _wrapModel: function (model) {
            // summary:
            //      Wraps the model with a confirmation
            // tags:
            //      protected
            return LanguageManagerViewModelWrapper(this.model);
        },

        _langIDFromUrl: new Url(window.location.href).query.language,

        _aroundInsertRow: function (/*Object*/original) {
            // summary:
            //      Called 'around' the insertRow method to fix the grids less than perfect selection.
            // tags:
            //      private

            return lang.hitch(this, function (object, parent, beforeNode, i, options) {

                // Call original method
                var row = original.apply(this.grid, arguments),
                    languageContext = this.context.languageContext;

                if (object.languageID === this._langIDFromUrl) {
                    this.grid.clearSelection();
                    this.grid.select(object);
                    this.model.onItemSelected(object);
                }

                if (!object.isActive) {
                    domClass.add(row, this._inactiveCssClass);  // add the inactive class to the whole row
                }
                if (languageContext && object.languageID === languageContext.preferredLanguage) {
                    domClass.add(row, this._preferLanguageCssClass);
                }

                row.title =
                    object.isActive && (languageContext && object.languageID !== languageContext.preferredLanguage)
                    && this.model.contentData.capabilities.languageSettings
                        ? res.clicktoswitchlanguage : !object.isActive ? res.editingforlanguageisdisabled : "";

                return row;
            });
        },

        _setContextAttr: function (context) {
            if (context) {
                this._set("context", context);
                if (!this._langIDFromUrl) {
                    this._langIDFromUrl = context.language;
                }
            }

        },

        _setContentDataAttr: function (contentData) {
            if (contentData) {
                // initiliaze command provider only it has not been initiliazed
                if (!this.commandProviderInitialized) {
                    // Re-initiliaze command provider
                    this.commandProviderInitialized = true;

                    this.commandProvider = this.model;
                    this._consumer = this.getConsumer();

                    this._consumer.addProvider(this.commandProvider);
                    this.contextMenu.addProvider(this.commandProvider);
                    this.contextMenu.startup();

                    var self = this;

                    this.own(
                        this.commandProvider,
                        aspect.around(this._consumer.toolbar, "_getCurrentPosition", function (originalMethod) {
                            return function (currentCategory) {
                                if (currentCategory === "default") {
                                    return 0;
                                }
                                // Need to wait because "_getCurrentPosition" method sometime has exception on IE
                                setTimeout(function () {
                                    return originalMethod.apply(self._consumer.toolbar, [currentCategory]);
                                }, 0);
                            };
                        })
                    );
                }

                this.grid.set("query", { contentLink: contentData.contentLink });

            }

            // also based on context.languageContext (context available only when contentData available), e.g: Root & Trash
            // and dataType, e.g: "episerver.commerce.catalog.contenttypes.rootcontent" to show/hide message
            if (contentData && contentData.existingLanguageBranches && contentData.existingLanguageBranches.length > 0
                && this.context.languageContext
                && this.isSupportedType(contentData)) {
                this._hideMessage();
            } else {
                this._showMessage(res.contentnotsupport);
            }
        },

        _setActionExecutingAttr: function (value) {
            if (!value) {
                return;
            }
            this.standby.show();
        },

        _setActionExecutedAttr: function (result) {
            if (!result) {
                return;
            }
            this.grid.refresh();
            this.standby.hide();
        },

        _setStoreAttr: function (/*Object*/store) {
            // summary:
            //      Set the store associatated with the grid.
            // parameters:
            //      store: Rest store object.
            // tags:
            //      private

            this._set("store", store);
            this.grid.set("store", store);
        },

        _setupLanguageCollumn: function (item, value, node, options) {
            // summary:
            //      Setup for the Language collumn of dgrid.
            // param:
            //  item: LanguageInfo item of LanguageManager Rest Store
            //  node: grid cell element

            var canActivateOrDeactivate = (item.canActivate && this.model.contentData.capabilities.languageSettings);

            var systemIconString = lang.replace("<span class='systemIcon' {backgroundIconStyle}></span>",
                {
                    backgroundIconStyle: item.systemIconPath != null ? "style='background-image:url(" + item.systemIconPath + ")'" : ""
                });

            var languageName = lang.replace("<span class='languageName rowTextElement'>{languageName}{suffix}</span>",
                {
                    languageName: value,
                    suffix: item.isMaster ? " (" + res.master + ")" : ""
                });

            node.innerHTML = systemIconString + languageName;

            if (item.isCurrent) {
                domClass.add(node, this._currentLanguageCssClass);
            }

            if (!item.isActive) {
                domClass.add(node, this._inactiveCssClass);
            }

            if (!canActivateOrDeactivate) {
                domClass.add(node, this._disabledCssClass);
            }
        },

        _setupContentStatusCollumn: function (item, value, node, options) {
            // summary:
            // param:
            //  item: LanguageInfo item of LanguageManager Rest Store
            //  node: grid cell element

            var contentStatus = item.isCreated ? (item.isPublished ? res.published : res.draft) : res.notcreatedyet;
            var contentHtml = lang.replace("<span class='rowTextElement' >{0}</span>", [contentStatus]);
            node.innerHTML = contentHtml;
        },

        _setupExistenceCollumn: function (item, value, node, options) {
            // summary:
            // param:
            //  item: LanguageInfo item of LanguageManager Rest Store
            //  node: grid cell element

            var contentHtml = "";

            if (item.isActive && item.canCreate && !item.isCreated) {
                contentHtml = lang.replace("<a class='lmLanguageBranchAction createLanguageBranch rowTextElement epi-visibleLink' >{0}</a>", [res.create]);
            } else if (item.isCreated) {
                contentHtml = lang.replace("<span class='lmDateTime rowTextElement' >{0}</span>", [epiDate.toUserFriendlyString(item.publishedDateTime ? item.publishedDateTime : item.savedDateTime)]);
            }

            node.innerHTML = contentHtml;
        },

        _onCreateLanguageBranch: function (e) {
            // summary:
            //    Create a language branch.
            // tags:
            //    private

            e.stopImmediatePropagation();

            this.model.set("target", e);

            // TODO: Select row that was clicked
            this.model.onItemSelected(this.grid.row(e).data);
            var command = this.model.getCommand("create");
            command.execute();
        },

        _onSwitchLanguage: function (evt) {
            // summary:
            //    Handle event for switching between languages.
            // tags:
            //    private

            var cell = this.grid.cell(evt);
            var row = this.grid.row(evt);
            // Do not redirect to the language branch if it is not active,
            // or it is prefer language
            if (domClass.contains(row.element, this._inactiveCssClass)
                || domClass.contains(cell.element, this._preferLanguageCssClass)) {
                return;
            }
            var hash = this._hashWrapper.getHash(),
                currentUrl = new Url(window.location.href),
                currentUrlPath = currentUrl.scheme + "://" + currentUrl.authority + currentUrl.path;
            // TECHNOTE: consider to use topic.publish changerequest.
            window.location.replace(currentUrlPath + row.data.linkFragment);

            // force to refresh page if url is the same language, but different hash (of view setting)
            if (hash && hash.viewsetting) {
                if (new Url(window.location.href).query.language === row.data.languageID) {
                    window.location.reload();
                }
            }
        },

        _createContextMenu: function () {
            // summary:
            //      Creates the context menu for the grid.
            // tags:
            //      private

            this.contextMenu = new ContextMenu({ category: "contextMenu" });
            this.own(this.contextMenu);
        },

        _setupEvents: function () {
            // summary:
            //      Initialization of events on the grid.
            // tags:
            //      protected

            var self = this;

            this.own(
                this.grid.on(".createLanguageBranch:click", lang.hitch(this, "_onCreateLanguageBranch")),
                this.grid.on(".epi-iconContextMenu:click", lang.hitch(this, "_onContextMenuClick")),

                //When mouse is over a row, show the context menu node
                this.grid.on(".dgrid-row:mouseover", function (event) {
                    domClass.add(this, self._mouseOverCssClass);
                }),
                //When mouse is out of an unselected row, hide the context menu node
                this.grid.on(".dgrid-row:mouseout", function (event) {
                    domClass.remove(this, self._mouseOverCssClass);
                }),

                /* click on row (except buttons, contextmenu) will switch */
                this.grid.on(".dgrid-row:click", lang.hitch(this, "_onSwitchLanguage")),

                //When mouse is out of an unselected row, hide the context menu node
                this.grid.on("dgrid-select", lang.hitch(this, function (event) {
                    this.model.onItemSelected(event.rows[0].data);
                })),

                // update the grid when user close language setting dialog, or manage website language dialog
                topic.subscribe("/epi/cms/contentdata/updated", function () {
                    self.grid.refresh();
                }),

                // Overide base method from grid to set selected item
                aspect.around(this.grid, "insertRow", lang.hitch(this, this._aroundInsertRow))
            );
        },

        _onContextMenuClick: function (e) {
            // summary:
            //    Handle event click of context menu node.
            //
            // tags:
            //    private

            e.stopImmediatePropagation();

            var availableCommands = this.model.getAvailableCommands("contextMenu");
            if (availableCommands && availableCommands instanceof Array && availableCommands.length > 0) {
                this.contextMenu.scheduleOpen(this, null, {
                    x: e.pageX,
                    y: e.pageY
                });
            }
        },


        _keepMenuItemUncheck: function (original) {
            // summary:
            //      Replace _setCheckedAttr method to keep menu item always uncheck.
            // tags:
            //      private

            return lang.hitch(this, function (value) {
                // do nothing
            });
        },

        _showMessage: function (/*String*/message) {
            // summary:
            //      Create a message to display inside the gadget
            // tags:
            //      private

            var messageContainer = query("." + this._messageClassName);
            if (messageContainer.length === 0) {
                messageContainer = domConstruct.create("span", { "class": this._messageClassName }, this.grid.domNode, "before");
            }

            messageContainer.innerHTML = message;

            domStyle.set(this.grid.domNode, "display", "none");
        },

        _hideMessage: function () {
            // summary:
            //      Destroy the message
            // tags:
            //      private

            var messageContainer = query("." + this._messageClassName);
            if (messageContainer.length > 0) {
                domConstruct.destroy(messageContainer[0]);
            }
            domStyle.set(this.grid.domNode, "display", "");
        },

        _savePinnablePanesState: function () {
            // summary:
            //      Saves current state of the pinnable panes
            // tags:
            //      private

            var profile = dependency.resolve("epi.shell.Profile");

            all({
                toolsSettings: profile.get("tools"),
                navigationSettings: profile.get("navigation")
            }).then(function (results) {
                var toolsPinned = results && results.toolsSettings && results.toolsSettings.pinned,
                    navigationPinned = results && results.navigationSettings && results.navigationSettings.pinned;

                profile.set("addons-language-manager-settings", {
                    toolsPinned: toolsPinned,
                    navigationPinned: navigationPinned
                });
            });
        }
    });
});

},
'epi-languagemanager/component/viewmodel/LanguageManagerViewModel':function(){
﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/_base/Deferred",
    "dojo/promise/all",
    "dojo/when",
    "dojo/Stateful",
    "dojo/topic",
    "dojox/html/entities",

    //EPi
    "epi/epi",
    "epi/dependency",
    "epi/shell/command/withConfirmation",
    "epi/shell/command/_CommandProviderMixin",
    "epi/shell/TypeDescriptorManager",
    "epi/Url",
    "epi/shell/widget/dialog/Alert",

    //CMS
    "epi-cms/_ContentContextMixin",
    "epi-cms/core/ContentReference",

    // Language Manager commands
    "epi-languagemanager/component/command/CompareWithMasterLanguage",
    "epi-languagemanager/component/command/DeleteLanguageBranch",
    "epi-languagemanager/component/command/ManageWebsiteLanguages",
    "epi-languagemanager/component/command/OpenLanguageSettings",
    "epi-languagemanager/component/command/Settings",
    "epi-languagemanager/component/command/ToggleEditingLanguageBranch",
    "epi-languagemanager/component/command/CreateLanguageBranch",
    "epi-languagemanager/component/command/ReplaceLanguageBranch",
    "epi-languagemanager/component/command/AddToTranslationProject",

    // Resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],

function (
// Dojo
    declare,
    lang,
    array,
    Deferred,
    all,
    when,
    Stateful,
    topic,
    entities,

    // EPi
    epi,
    dependency,
    withConfirmation,
    _CommandProviderMixin,
    TypeDescriptorManager,
    Url,
    Alert,

    //CMS
    _ContentContextMixin,
    ContentReference,

    // Language Manager commands
    CompareWithMasterLanguageCommand,
    DeleteLanguageBranchCommand,
    ManageWebsiteLanguagesCommand,
    OpenLanguageSettingsCommand,
    SettingsCommand,
    ToggleEditingLanguageBranchCommand,
    CreateLanguageBranchCommand,
    ReplaceLanguageBranch,
    AddToTranslationProject,

    // Resources
    res

) {

    // summary:
    //      View model object for the LanguageManager widget.
    return declare([Stateful, _CommandProviderMixin, _ContentContextMixin], {

        // store: [protected] Object
        //      Rest store for manipulate model data.
        store: null,

        // projectItemStore: [readonly] Store
        //      A REST store for interacting with projects item.
        projectItemStore: null,

        // projectService: [readonly] ProjectService
        //      A service for interacting with projects
        projectService: null,

        // contentVersionStore: [readonly] Store
        //      A REST store for interacting with content versions.
        contentVersionStore: null,

        res: null,

        _commandRegistry: null,

        _hashWrapper: null,

        _commandsReady: null,

        _currentItemDataReady: null,

        _hasProject: null,

        currentItemData: null,

        target: null,

        // deleteLanguageBranchSettings: Object
        //      Settings for DeleteLanguageBranch command
        _deleteLanguageBranchSettings: null,

        postscript: function () {
            // summary:
            //      Initialize store and data displayed for page.
            // tags:
            //      protected

            this.inherited(arguments);

            this.res = this.res || res;
            this._hashWrapper = dependency.resolve("epi.shell.HashWrapper");
            this._commandsReady = new Deferred();
            this._currentItemDataReady = new Deferred();

            //resolve _viewSettingsManager
            this._viewSettingsManager = dependency.resolve("epi.viewsettingsmanager");

            var registry = dependency.resolve("epi.storeregistry");
            this.set("store", this.store || registry.get("epi-languagemanager.language-manager"));
            this.set("settings", this.settings || registry.get("epi-languagemanager.settings"));
            this.contentVersionStore = this.contentVersionStore || registry.get("epi.cms.contentversion");
            this.projectStore =  this.projectStore || dependency.resolve("epi.storeregistry").get("epi.cms.project");
            this.projectService = this.projectService || dependency.resolve("epi.cms.ProjectService");
            this.projectItemStore = this.projectItemStore || registry.get("epi-languagemanager.project.item");
            this.own(
                this.projectService.on("project-removed", lang.hitch(this, this._onProjectChanged)),
                this.projectService.on("project-updated", lang.hitch(this, this._onProjectChanged)),
                this.projectService.on("project-item-removed", lang.hitch(this, this._onProjectItemChanged)),
                this.projectService.on("project-item-updated", lang.hitch(this, this._onProjectItemChanged))
            );

            all({
                currentContext: this.getCurrentContext(),
                isInAdminRole: this.store.executeMethod("IsCurrentUserInAdminRole", null, null),
                isTranslatingSystemAvailable: this.store.executeMethod("IsTranslatingServiceAvailable", null, null),
                hasAnyLanguageAvailable: this.store.executeMethod("HasAnyLanguageAvailable", null, null)
            }).then(lang.hitch(this, function (result) {
                var currentContext = result.currentContext,
                    isInAdminRole = result.isInAdminRole,
                    isTranslatingSystemAvailable = result.isTranslatingSystemAvailable,
                    hasAnyLanguageAvailable = result.hasAnyLanguageAvailable;

                this.set("context", currentContext);
                this.set("isInAdminRole", isInAdminRole);
                this.set("isTranslatingSystemAvailable", isTranslatingSystemAvailable);
                this.set("hasAnyLanguageAvailable", hasAnyLanguageAvailable);
                this._refreshCurrentContent(currentContext);
                this._commandsReady.resolve();
            }));
        },

        contextChanged: function (context, callerData) {
            // summary:
            //      Context change event.
            // tags:
            //      event
            this.inherited(arguments);
            this.set("context", context);
            this._refreshCurrentContent(context);
        },

        contextUpdated: function (context) {
            this.inherited(arguments);
            this._refreshCurrentContent(context);
        },

        hasAnyProject: function () {
            // summary:
            //      Check if there is any project.
            // tags:
            //      public

            if (!this._hasProject) {
                this._hasProject = new Deferred();
                var store = dependency.resolve("epi.storeregistry").get("epi-languagemanager.project");
                when(store.query({ preventCache: true }), lang.hitch(this, function (projects) {
                    this._hasProject.resolve(projects.length > 0);
                }));
            }

            return this._hasProject;
        },

        _onProjectChanged: function () {
            // summary:
            //      Listen to update project when there is a change.
            // tags:
            //      private

            // assign null to mark as need to resolve later
            this._hasProject = null;
        },

        _onProjectItemChanged: function () {
            // summary:
            //      Clear cache of projectItemStore when there is any changes.
            // tags:
            //      private

            this.projectItemStore.evict();
        },

        _refreshCurrentContent: function (context) {
            // summary:
            //      Gets current content data and setup commands.
            // tags:
            //      private

            if (!this._isContentContext(context)) {
                this.set("contentData", null);
                this.set("commands", null);
                return;
            }
            this.getCurrentContent().then(lang.hitch(this, function (contentData) {
                this._setupMasterLanguage(contentData);
                this.set("contentData", contentData);
                this._setupCommands();
                this.updateCommandModel(this);
            }));
        },

        getCommand: function (commandName) {
            // summary:
            //      Gets a command by command name
            // tags:
            //      protected

            return this._commandRegistry && this._commandRegistry[commandName] ? this._commandRegistry[commandName].command : null;
        },

        getAvailableCommands: function (category) {
            // summary:
            //      Gets available commands by category
            // tags:
            //      public

            var commands = this.get("commands");
            return commands.filter(function (cmd) {
                return cmd.category === category && cmd.get("isAvailable") === true;
            }, this);
        },

        onItemSelected: function (itemData) {
            // summary:
            //      Call when user choose a row on the grid.
            // tags:
            //      public

            this.set("currentItemData", itemData);
            this.updateCommandModel(this);

            // Update text contents of the confirmation dialog for DeleteLanguageBranch command
            var content = this.contentData;
            if (itemData && content) {
                var heading = lang.replace(res.deletelanguagebranch, itemData),
                    description = TypeDescriptorManager.getResourceValue(content.typeIdentifier, "deletelanguagebranchdescription");

                lang.mixin(this._deleteLanguageBranchSettings, {
                    confirmActionText: heading,
                    description: lang.replace(description, [entities.encode(content.name), itemData.name]),
                    title: heading
                });
            }

            if (this._currentItemDataReady) {
                this._currentItemDataReady.resolve();
                this._currentItemDataReady = null;
            }
        },

        autoTranslate: function (sourcelanguage) {
            // summary:
            //      Replace content by translating from a source language branch.
            // tags:
            //      pubic

            this._executeAction("TranslateAndCopyDataLanguageBranch", { sourcelanguage: sourcelanguage }, this._autotranslationCompleteHandler);

        },

        duplicateContent: function (sourceLanguage) {
            // summary:
            //      Copy and replace content from a source language branch.
            // tags:
            //      pubic

            this._executeAction("CopyDataLanguageBranch", { sourceLanguage: sourceLanguage }, this._fireContextRequest);
        },

        deleteLanguageBranch: function () {
            // summary:
            //      Delete a language branch.
            // tags:
            //      pubic

            var onComplete = function (result) {

                if (!result) {
                    var dialog = new Alert({
                        heading: res.deletefailedalert.heading,
                        description: res.deletefailedalert.message
                    });
                    dialog.show();
                    //if delete language branch fails, show alert dialog and turn off standby widget without page refresh
                    this.set("actionExecuted", {});
                    return false;
                }

                var contentReference = new ContentReference(this.contentData.contentLink);
                topic.publish("/epi/shell/context/request",
                    { uri: "epi.cms.contentdata:///" + contentReference.createVersionUnspecificReference().toString() },
                    { sender: this, forceContextChange: true });

                topic.publish("/epi/cms/contentdata/updated", {
                    contentLink: contentReference.createVersionUnspecificReference().toString(),
                    recursive: true
                });

                return true;
            };
            this._executeAction("DeleteLanguageBranch", null, onComplete);
        },

        toggleLanguageBranchActivation: function () {
            // summary:
            //      Activate/Deactivate a language branch.
            // tags:
            //      pubic

            var onComplete = function () {
                var contentReference = new ContentReference(this.contentData.contentLink);
                var id = contentReference.createVersionUnspecificReference().toString();
                topic.publish("/epi/shell/context/request",
                    { uri: "epi.cms.contentdata:///" + id },
                    { sender: this, forceContextChange: true }
                );

                // update context, this section is similar to the CloseButton of LanguageSetting legacy dialog
                // publish this event, so when we use LanguageManager's context menu to enable, disable a language,
                // SiteGadget can be changed to refresh the available LanguageList
                topic.publish("/epi/cms/contentdata/updated", {
                    contentLink: id,
                    recursive: true
                });

                return true;
            };

            this._executeAction("ToggleLanguageBranchActivation",
                {
                    twoLetterISOLanguageName: this.currentItemData.twoLetterISOLanguageName
                }, onComplete);
        },

        isContentExistingInProject: function (/*Int*/projectId, /*Object*/contentReference, /*String*/languageId) {
            // summary:
            //      Verifies the existing of the given content reference in the selected project.
            // projectId: [Int]
            //      Selected project identification.
            // contentReference: [Object]
            //      Content reference that want to add to the selected project.
            // languageId: [String]
            //      Language code of the given content reference.
            // returns: [Boolean]
            //      Flag indicates that the given content reference is existing in the selected project or not.
            // tags:
            //      public

            var deferred = new Deferred();

            // Do nothing if the given project id or content link is not valid
            if (projectId <= 0 || !contentReference) {
                deferred.resolve(true);

                return deferred;
            }

            // We need to send ProviderName and set the workdId = 0 to return all the project items that associated with the content.
            var contentRef = new ContentReference(contentReference);
            contentRef.workId = 0;

            when(this.projectService.getProjectItemsForContent(contentRef), function (projectItems) {
                if (projectItems instanceof Array && projectItems.length > 0) {
                    var i = 0,
                        totalItems = projectItems.length,
                        projectItem = null;
                    for (; i < totalItems; i++) {
                        projectItem = projectItems[i];
                        if (projectItem && projectItem.projectId === projectId && projectItem.contentLanguage === languageId) {
                            deferred.resolve(true);

                            return;
                        }
                    }
                }

                deferred.resolve(false);
            });

            return deferred;
        },

        addProjectItems: function (projectId, contentReferences, languageId) {
            // summary:
            //      Adds the given content references as items of the project.
            //
            // projectId: Number
            //      The target project for adding items to.
            // contentReferences: ContentReference[]
            //      An array of references to content items to add to the project.
            // languageID: String
            //      Language ID to add to the project
            // tags:
            //      public

            // Ensure the content reference we received are valid.
            contentReferences = contentReferences.filter(function (reference) {
                if (ContentReference.isContentReference(reference)) {
                    return true;
                }
                // eslint-disable-next-line no-console
                console.warn("epi-cms/project/ProjectService: the given value '" + reference + "' is not a valid content reference.");
            });

            return this.projectItemStore.executeMethod("addItems", projectId, { id: projectId, contentLinks: contentReferences, languageId: languageId, modifyHeader: true });
        },

        canAddContent: function (projectId, contentLinks) {
            // summary:
            //      Verifies that the given content links can be added to the project
            //
            // projectId: Number
            //      The project id to check
            // contentLinks: Array
            //      The content links to add
            // returns: Promise
            //      A promise with the result from the server
            // tags:
            //      internal

            return this.projectService.canAddContent(projectId, contentLinks, this.currentItemData.languageID);
        },

        getContentsToProject: function (/*Object*/targetProject, /*bool*/ addDescendents, /*bool*/ addRelateContents) {
            // summary:
            //      Gets all children of the given content reference
            // targetProject: [Object]
            //      The current target project
            // tags:
            //      public

            var params = {
                contentLink: this.contentData.contentLink,
                languageId: this.currentItemData.languageID,
                includeDescendents: addDescendents,
                includeRelatedContents: addRelateContents
            };

            return this.store.executeMethod("GetContentsToProject", null, params);
        },

        _executeAction: function (actionName, params, onComplete) {
            // summary:
            //      Execute an action.
            // tags:
            //      private

            this.set("actionExecuting", true);

            var defaultParams = {
                contentLink: this.contentData.contentLink,
                languageID: this.currentItemData.languageID
            };
            when(this.store.executeMethod(actionName, null, lang.mixin(defaultParams, params)),
                lang.hitch(this, function (result) {
                    var needSetActionExecutedAttr = false;
                    
                    if (onComplete) {
                        needSetActionExecutedAttr = onComplete.call(this, result.isSuccess);
                    }
                     //In the case onComplete method return false, we dont need to set the attribute actionExecuted,
                     //because the page will be refreshed. See bug: https://jira.ep.se/browse/LM-190
                        needSetActionExecutedAttr && this.set("actionExecuted", result);
                }));
        },

        _fireContextRequest: function () {
            // summary:
            //      public event to force context change.
            // tags:
            //      private

            // Set flag to force Iframe reload data
            this._forceIframeReload = true;

            var currentItemLanguage = this.currentItemData.languageID;
            var currentContentLanguage = new Url(window.location.href).query.language,
                shouldReload = currentContentLanguage !== currentItemLanguage;
            if (!shouldReload) {
                // reload context
                var id = new ContentReference(this.contentData.contentLink).createVersionUnspecificReference().toString();
                topic.publish("/epi/shell/context/request",
                    { uri: "epi.cms.contentdata:///" + id },
                    { sender: this, forceContextChange: true
                    });
                return true;
            }
            // reload context with new language branch
            var currentUrl = new Url(window.location.href),
                currentUrlPath = currentUrl.scheme + "://" + currentUrl.authority + currentUrl.path,
                reloadUrl = currentUrlPath + this.currentItemData.linkFragment;
            window.location.assign(reloadUrl);

            return false;
        },

        _setupMasterLanguage: function (contentData) {
            // summary:
            //      Set masterLanguage property when context change.
            // tags:
            //      private

            if (contentData && contentData.existingLanguageBranches && contentData.existingLanguageBranches.length > 0) {
                var masterLanguage = contentData.existingLanguageBranches.filter(function (languageBranch) {
                    return languageBranch.isMasterLanguage === true;
                }, this);

                // TODO: Need to get the correct master language.
                // Workaround to get the master language.
                if (masterLanguage.length === 0) {
                    masterLanguage = contentData.existingLanguageBranches;
                }

                this.set("masterLanguage", masterLanguage[0].name);
            }
        },

        _setupCommands: function () {
            // summary:
            //      Setup commands for the widget.
            // tags:
            //      private

            this._deleteLanguageBranchSettings = {
                cancelActionText: epi.resources.action.cancel,
                setFocusOnConfirmButton: false
            };

            var commands = {
                /* Commands for context menu */
                createContextMenu: {
                    command: new CreateLanguageBranchCommand({ category: "contextMenu", model: this }),
                    order: 10
                },
                compareContextMenu: {
                    command: new CompareWithMasterLanguageCommand({ category: "contextMenu", iconClass: null }),
                    order: 20
                },
                replaceContextMenu: {
                    command: new ReplaceLanguageBranch({ category: "contextMenu", model: this }),
                    order: 30
                },
                addToTranslationProjectContextMenu: {
                    command: new AddToTranslationProject({ category: "contextMenu", model: this }),
                    order: 40
                },
                toggleContextMenu: {
                    command: new ToggleEditingLanguageBranchCommand({ category: "contextMenu" }),
                    order: 40
                },
                deleteContextMenu: {
                    command: withConfirmation(new DeleteLanguageBranchCommand({ category: "contextMenu" }), null, this._deleteLanguageBranchSettings),
                    order: 50
                },

                /* Commands for toolbar default position */
                compare: {
                    command: new CompareWithMasterLanguageCommand({ model: this })
                },

                /* Commands for toolbar context position */
                open: {
                    command: new OpenLanguageSettingsCommand(),
                    order: 10
                },
                create: {
                    command: new CreateLanguageBranchCommand({ model: this }),
                    order: 20
                },
                replace: {
                    command: new ReplaceLanguageBranch({ model: this }),
                    order: 30
                },
                addToTranslationProject: {
                    command: new AddToTranslationProject({ model: this }),
                    order: 40
                },
                toggle: {
                    command: new ToggleEditingLanguageBranchCommand(),
                    order: 40
                },
                "delete": {
                    command: withConfirmation(new DeleteLanguageBranchCommand(), null, this._deleteLanguageBranchSettings),
                    order: 50
                },

                /* Commands for toolbar settings position */
                manage: {
                    command: new ManageWebsiteLanguagesCommand()
                },

                setting: {
                    command: new SettingsCommand()
                },

                sort: function () {
                    var commands = [];
                    for (var key in this) {
                        if (key !== "toArray" && key !== "sort" && this.hasOwnProperty(key)) {
                            var index = this[key].order;
                            if (!index) {
                                index = 100;
                            }
                            commands.push([index, this[key].command]);
                        }
                    }

                    commands.sort(function (a, b) {
                        return a[0] - b[0];
                    });

                    return commands;
                },
                toArray: function () {
                    var sortedCommand = this.sort();
                    var commands = [];
                    array.forEach(sortedCommand, function (key) {
                        commands.push(key[1]);
                    });

                    return commands;
                }
            };

            this._commandRegistry = lang.mixin(this._commandRegistry, commands);

            this.set("commands", this._commandRegistry.toArray());
        },

        _autotranslationCompleteHandler: function (result) {
            // summary:
            //      Handle auto translation complete action if translation content saving fails, refer https://jira.ep.se/browse/LM-317
            // tags:
            //      private

            //if auto translation fails, show alert dialog and turn off standby widget without page refresh
            if (!result) {
                  var dialog = new Alert({
                            heading: res.autotranslationalert.heading,
                            description: res.autotranslationalert.message
                        });
                dialog.show();
                this.set("actionExecuted", {});
                return false;
            }
            //return to keep things going
            return this._fireContextRequest();
        
        }
    });
});

},
'epi-languagemanager/component/command/CompareWithMasterLanguage':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",
    "dojo/promise/all",
    "dojo/when",

    // Epi Framework
    "epi/dependency",
    "epi/Url",
    "epi-cms/core/ContentReference",

    // Language mangager
    "epi-languagemanager/component/command/CommandBase",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo base
    declare,
    lang,
    topic,
    all,
    when,

    // Epi Framework
    dependency,
    Url,
    ContentReference,

    // Language manager
    CommandBase,

    // Resource
    res
) {

    return declare([CommandBase], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: "Compare with {language} (Master)",

        iconClass: "epi-iconCompare",

        constructor: function (params) {
            this.inherited(arguments);

            if (params && params.model) {
                this.set("label", lang.replace(res.comparewithmasterlanguage, { name: params.model.masterLanguage }));
            }

            this.profile = dependency.resolve("epi.shell.Profile");
            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            var item = this.model.currentItemData;

            if (!item) {
                this.set("canExecute", false);
                return;
            }

            // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted or is an unsupported type
            var disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData)
                    || this.model.contentData.isDeleted || !this.isSupportedType(this.model.contentData);

            this.set("label", lang.replace(res.comparewithmasterlanguage, { name: this.model.masterLanguage }));

            this.set("isAvailable", !this.category || item.isCreated && item.canEdit && !item.isMaster && item.isActive);
            this.set("canExecute", item.canEdit && item.isCreated && !item.isMaster && item.isActive && !disabled);
        },

        execute: function (/*Mouse event*/evt, /*Boolean?*/isForced) {
            if (!this.model.currentItemData || !this.model.currentItemData.languageID) {
                return;
            }

            // currentItemData.canEdit = false means that the current user has not Edit access right on the language,
            // and he cannot access compare editing
            if (!this.model.currentItemData.canEdit) {
                // set actionExecuted to remove standby widget
                this.model.set("actionExecuted", {});
                return;
            }

            // Make it fullscreen, unpin left and right panel
            topic.publish("/epi/layout/pinnable/navigation/toggle", false);
            topic.publish("/epi/layout/pinnable/tools/toggle", false);

            // Save current pinnable state for restoring later
            var self = this;
            all({
                toolsSettings: self.profile.get("tools"),
                navigationSettings: self.profile.get("navigation")
            }).then(function (results) {
                var toolsPinned = results && results.toolsSettings && results.toolsSettings.pinned,
                    navigationPinned = results && results.navigationSettings && results.navigationSettings.pinned;

                self.profile.set("addons-language-manager-settings", {
                    toolsPinned: toolsPinned,
                    navigationPinned: navigationPinned
                });
            });

            // Switch to compare view
            var currentContentLanguage = new Url(window.location.href).query.language,
                currentItemLanguage = this.model.currentItemData.languageID,
                shouldReload = currentContentLanguage !== currentItemLanguage;

            // This is for getting the content id without WorkId (e.g. 6 instead of 6_1234).
            // The resolver on server will automatically get the latest version
            var contentReference = new ContentReference(this.model.context.id);
            var contentReferenceWithoutVersion = contentReference.createVersionUnspecificReference();

            if (shouldReload) {
                // If the comparing language is different from the current content language,
                // then we need to switch the content language to the comparing language before making comparison

                var currentUrl = new Url(window.location.href),
                    currentUrlPath = currentUrl.scheme + "://" + currentUrl.authority + currentUrl.path,
                    reloadUrl = currentUrlPath + "?language=" + currentItemLanguage + "#context=epi.cms.languagemanager.compareediting:///" + contentReferenceWithoutVersion;

                when(self.profile.setContentLanguage(currentItemLanguage, currentUrl.authority)).then(function () {
                    window.location.replace(reloadUrl);
                });
            } else {
                topic.publish("/epi/shell/context/request", { uri: "epi.cms.languagemanager.compareediting:///" + contentReferenceWithoutVersion }, { languageManagerAction: "compare", trigger: "internal" });
            }
        }
    });
});

},
'epi-languagemanager/component/command/DeleteLanguageBranch':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",

    // EPi CMS
    "epi-cms/ApplicationSettings",

    // Language Manager
    "epi-languagemanager/component/command/CommandBase",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo base
    declare,
    lang,

    // EPi CMS
    ApplicationSettings,

    // Language Manager
    CommandBase,

    // Resource
    res
) {

    return declare([CommandBase], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.deletelanguagebranch,

        // category: [readonly] String
        //      A category which provides a hint about how the command could be displayed.
        category: "context",

        postscript: function () {
            this.inherited(arguments);

            this.set("canExecute", false);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            var item = this.model.currentItemData;

            if (!item) {
                this.set("canExecute", false);
                this.set("isAvailable", false);
                return;
            }

            var isActive = item.isActive && this.model.context.capabilities.deleteLanguageBranch, // check deleteLanguageBranch capability.
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData) || this.model.contentData.isDeleted;

            this.set("canExecute",
                item.canDelete
                && item.isCreated
                && !item.isMaster
                && isActive
                && !disabled
                && !ApplicationSettings.disableVersionDeletion
            );

            this.set("isAvailable", item.canDelete && item.isCreated && !item.isMaster && isActive && !ApplicationSettings.disableVersionDeletion);

            this.set("label", lang.replace(res.deletelanguagebranch, item));
        },

        _execute: function () {
            // summary:
            //      Delete a language branch.
            // tags:
            //      protected

            return this.model.deleteLanguageBranch();
        }

    });
});

},
'epi-languagemanager/component/command/ManageWebsiteLanguages':function(){
﻿define([
    "dojo/_base/declare",
    "epi-languagemanager/component/command/CommandBase",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"

], function (
    declare,
    CommandBase,
    res) {

    return declare([CommandBase], {

        // label: [public] String
        //		The action text of the command to be used in visual elements.
        label: res.managewebsitelanguages,

        // category: [readonly] String
        //		A category which provides a hint about how the command could be displayed.
        category: "setting",

        postscript: function () {
            this.inherited(arguments);
        },

        getDialogParams: function () {
            // summary:
            //		Override to provide title for the dialog.

            return { dialogTitle: res.managewebsitelanguages };
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            this.set("canExecute", this.model.isInAdminRole);
        },

        _execute: function () {
            // summary:
            //		Navigate to Manage Website Setting Page
            // tags:
            //		protected

            window.location = this.model.settings.urlToManageWebsiteLanguage;
        }
    });
});
},
'epi-languagemanager/component/command/OpenLanguageSettings':function(){
﻿define([
    "dojo/_base/declare",
    "epi-cms/contentediting/command/LanguageSettings",

    // Language mangager
    "epi-languagemanager/component/_ExtensionContextMixin",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],

function (
    declare,
    _LanguageSettings,

    // Language mangager
    _ExtensionContextMixin,

    res) {

    // TODO: listen close dialog event to refresh the gadget.

    return declare([_LanguageSettings, _ExtensionContextMixin], {

        // label: [public] String
        //		The action text of the command to be used in visual elements.
        label: res.languagesettings,
        title: res.languagesettings,

        // category: [readonly] String
        //		A category which provides a hint about how the command could be displayed.
        category: "context",
        postscript: function () {
            this.inherited(arguments);
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            var item = this.model.currentItemData;
            if (!item || !this.model.hasAnyLanguageAvailable) {
                this.set("canExecute", false);

                return;
            }

            var languageSettings = this.model.contentData.capabilities.languageSettings,
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData) || this.model.contentData.isDeleted;

            this.set("canExecute",
                item.canActivate
                && languageSettings
                && !disabled
            );
        }
    });
});

},
'epi-cms/contentediting/command/LanguageSettings':function(){
define("epi-cms/contentediting/command/LanguageSettings", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",
    "dojo/when",
    "epi/dependency",
    "epi-cms/contentediting/ContentActionSupport",
    "epi/shell/command/_Command",
    "epi/shell/DialogService",
    "epi-cms/ApplicationSettings",

    //Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.contentdetails.command.languagesettings",
    "epi/i18n!epi/shell/nls/edit.languagesettings",
    "epi/i18n!epi/shell/nls/button",
    "epi/i18n!epi/nls/episerver.shared",
    "xstyle/css!epi-cms/contentediting/AdminWidgets.css"
], function (
    declare,
    lang,
    topic,
    when,
    dependency,
    ContentActionSupport,
    _Command,
    dialogService,
    ApplicationSettings,
    commandResources,
    uiResources,
    buttonResources,
    sharedResources) {

    function LanguageSettingsViewModel(store, contentLink) {

        return {
            getLanguageSettings: function () {
                return store.get(contentLink);
            },
            saveInheritSettings: function (inheritSettings) {
                return store.executeMethod("UpdateInheritSettings", contentLink, {
                    inheritSettings: inheritSettings,
                    //TODO: remove this, it's already in contentLink parameter
                    id: contentLink
                });
            },
            saveAvailableLanguages: function (availableLanguages) {
                return store.executeMethod("UpdateAvailableLanguages", contentLink, {
                    availableLanguages: availableLanguages,
                    id: contentLink,
                    inheritSettingsAvailable: false,
                    inheritSettings: false,
                    languages: null,
                    replacementLanguages: null,
                    fallbackLanguages: null
                });
            },
            saveFallbackLanguages: function (fallbackLanguages) {
                return store.executeMethod("UpdateFallbackLanguages", contentLink, {
                    fallbackLanguages: fallbackLanguages,
                    id: contentLink
                });
            },
            saveReplacementLanguages: function (replacementLanguages) {
                return store.executeMethod("UpdateReplacementLanguages", contentLink, {
                    replacementLanguages: replacementLanguages,
                    id: contentLink
                });
            }
        };
    }

    return declare([_Command], {
        // summary:
        //      Toggles permanent in use notification on/off.
        //
        // tags:
        //      internal
        name: "LanguageSettings",
        label: commandResources.label,
        tooltip: commandResources.tooltip,
        store: null,

        constructor: function () {
            this.store = dependency.resolve("epi.storeregistry").get("epi.cms.languagesettings");
            this.contentStore = dependency.resolve("epi.storeregistry").get("epi.cms.content.light");
        },

        _execute: function () {
            // summary:
            //		Toggles the value of the given property on the model.
            // tags:
            //		protected

            require(["epi-cms/contentediting/AdminWidgets"], function (AdminWidgets) {
                when(this.contentStore.get(this.model.contentData.parentLink)).then(function (parentContent) {
                    var resources = Object.assign({}, uiResources,
                        {
                            heading: lang.replace(uiResources.heading, [this.model.contentData.name]),
                            inheritsettings: parentContent ? lang.replace(uiResources.inheritsettings, [parentContent.name]) : uiResources.inheritsettings,
                            change: buttonResources.change,
                            save: buttonResources.save,
                            ok: buttonResources.ok,
                            cancel: buttonResources.cancel
                        });
                    var contentLink = this.model.contentData.contentLink;
                    var model = LanguageSettingsViewModel(this.store, contentLink);

                    model.getLanguageSettings().then(function (settings) {
                        var content = new AdminWidgets.LanguageSettings({
                            model: model,
                            resources: resources,
                            defaultSettings: settings,
                            helpLink: ApplicationSettings.userGuideUrl + "#languagesettings"
                        });
                        dialogService.dialog({
                            dialogClass: "epi-dialog-portrait epi-dialog-portrait__autosize epi-dialog--wide",
                            defaultActionsVisible: false,
                            confirmActionText: sharedResources.action.save,
                            content: content,
                            title: commandResources.label,
                            onCancel: function () {
                                topic.publish("/epi/cms/contentdata/updated", {
                                    contentLink: contentLink,
                                    recursive: true
                                });
                            }
                        });
                    });
                }.bind(this));
            }.bind(this));
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            var contentData = this.model.contentData;
            var hasAdminAccess =
                ContentActionSupport.hasAccess(contentData.accessMask, ContentActionSupport.accessLevel.Administer);

            this.set("canExecute", contentData.capabilities.languageSettings && hasAdminAccess);
        }
    });
});

},
'epi-languagemanager/component/command/Settings':function(){
﻿define([
    // Dojo base
    "dojo/_base/declare",

    // Language manager
    "epi-languagemanager/component/command/CommandBase",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"

], function (
    // Dojo base
    declare,

    // Language manager
    CommandBase,

    // Resource
    res

) {


    return declare([CommandBase], {

        // label: [public] String
        //		The action text of the command to be used in visual elements.
        label: res.settings,

        // category: [readonly] String
        //		A category which provides a hint about how the command could be displayed.
        category: "setting",

        postscript: function () {
            this.inherited(arguments);

            this.set("canExecute", false);
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            this.set("canExecute", this.model.isInAdminRole);
        },

        _execute: function () {
            // summary:
            //		Navigate to Settings Panel
            // tags:
            //		protected

            window.location = this.model.settings.urlToSettingsPage;
        }
    });
});

},
'epi-languagemanager/component/command/ToggleEditingLanguageBranch':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",

    // Language manager
    "epi-languagemanager/component/command/CommandBase",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"

], function (
// Dojo base
    declare,
    lang,

    // Language manager
    CommandBase,

    // Resource
    res

) {
    return declare([CommandBase], {

        // label: [public] String
        //		The action text of the command to be used in visual elements.
        label: "",

        // category: [readonly] String
        //		A category which provides a hint about how the command could be displayed.
        category: "context",

        postscript: function () {
            this.inherited(arguments);

            this.set("canExecute", false);
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            var item = this.model.currentItemData;
            if (!item) {
                this.set("canExecute", false);
                this.set("isAvailable", false);

                return;
            }

            var languageSettings = this.model.contentData.capabilities.languageSettings,
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData) || this.model.contentData.isDeleted;

            this.set("canExecute",
                item.canActivate
                && item.canEdit
                && !disabled
                && languageSettings);
            this.set("isAvailable", item.canActivate && item.canEdit && languageSettings);

            var resourceKey = item.isActive ? "disableediting" : "enableediting";
            this.set("label", lang.replace(res[resourceKey], item));
        },

        _execute: function () {
            // summary:
            // tags:
            //		protected

            this.model.toggleLanguageBranchActivation();
        }
    });
});

},
'epi-languagemanager/component/command/CreateLanguageBranch':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",

    // Dijit
    "dijit/popup",
    "dijit/focus",
    "dijit/registry",

    // Language manager
    "epi-languagemanager/component/command/_CommandWithOptions",
    "epi-languagemanager/widget/command/DuplicateContent",
    "epi-languagemanager/widget/command/StartBlank",
    "epi-languagemanager/widget/command/AutoTranslate",

    // Resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo base
    declare,
    lang,
    aspect,

    // Dijit
    popupManager,
    focusUtil,
    registry,

    // Language manager
    _CommandWithOptions,
    DuplicateContent,
    StartBlank,
    AutoTranslate,

    // Resources
    res
) {

    return declare([_CommandWithOptions], {

        label: res.create,

        // For create link
        _internalPopup: null,

        _setupPopup: function (/*Object*/popup) {

            this.inherited(arguments);
            // Set new header label
            popup.set("headingText", lang.replace(res.createpagein, this.model.currentItemData));
        },

        _setupInternalPopup: function (/*Boolean*/commandAvailable) {
            // summary:
            //      Create an independent popup that used to display everywhere
            // tags:
            //      private

            // Close current open popup if command is not available
            if (!commandAvailable) {
                if (this._internalPopup) {
                    var focusNode = focusUtil.get("curNode");
                    popupManager.close(this._internalPopup);
                    this._setEditorFocus(focusNode);
                }

                return;
            }

            if (!this._internalPopup) {
                this._internalPopup = new this.popupClass();
                this._setupEvent(this._internalPopup);
            }
            this._setupPopup(this._internalPopup);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            this.inherited(arguments);

            var item = this.model.currentItemData;

            if (!item) {
                this.set("canExecute", false);
                this.set("isAvailable", false);
                return;
            }

            var commandAvailable = item.isActive && item.canCreate && !item.isCreated,
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData) || this.model.contentData.isDeleted;

            this.set("isAvailable", commandAvailable);
            this.set("canExecute", commandAvailable && !disabled);

            this._setupInternalPopup(commandAvailable && !disabled);
        },

        execute: function (evt) {
            this._execute(evt);
        },

        getSubCommands: function (model) {
            // summary:
            //      Setup sub menu items when user click to create language branch.
            // tags:
            //      public

            var isTranslatingSystemAvailable = model.isTranslatingSystemAvailable;

            var autoTranslate = new AutoTranslate({ model: model }),
                duplicateContent = new DuplicateContent({ model: model }),
                startWithBlank = new StartBlank({ model: model }),
                createLanguageBranchCommands = [
                    {
                        label: autoTranslate.label,
                        value: autoTranslate,
                        disabled: isTranslatingSystemAvailable === false ? "disabled" : false
                    },
                    {
                        label: duplicateContent.label,
                        value: duplicateContent,
                        disabled: false
                    },
                    {
                        label: startWithBlank.label,
                        value: startWithBlank,
                        disabled: false
                    }
                ];

            return createLanguageBranchCommands;
        },

        _execute: function (evt) {
            // summary:
            //      Executes this command assuming canExecute has been checked. Subclasses should override this method.
            // tags:
            //      protected

            var self = this,
                target = this.model.get("target"),
                mouseEvent = evt || target;

            if (!mouseEvent) {
                return;
            }

            var popup = this._internalPopup,
                prevFocusNode = focusUtil.get("prevNode"),
                curFocusNode = focusUtil.get("curNode"),
                focusNode = popup.domNode,
                savedFocusNode = prevFocusNode ? prevFocusNode : curFocusNode;

            var popupBlurHanlder = aspect.after(popup, "onBlur", function () {
                popupBlurHanlder.remove();

                self.model.set("target", null);
                popupManager.close(popup);
                self._setEditorFocus(savedFocusNode);
            });

            focusUtil.focus(focusNode);

            popupManager.open({
                around: mouseEvent.target,
                popup: popup,
                onCancel: function () {
                    popupManager.close(popup);
                }
            });
        },

        _setEditorFocus: function (nodeToFocus) {
            // summary:
            //      Set focus for given dom node and enclosing editor.
            // tags:
            //      private

            if (!nodeToFocus) {
                return;

            }
            nodeToFocus.focus();

            // call _onFocus to make TinyMCE editor active and auto save work
            var parentWidget = registry.getEnclosingWidget(nodeToFocus);
            if (parentWidget && parentWidget._onFocus) {
                parentWidget._onFocus();
            }
        }
    });
});

},
'epi-languagemanager/component/command/_CommandWithOptions':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",

    // Dijit
    "dijit/popup",
    "dijit/Destroyable",

    // Language manager
    "epi-languagemanager/component/command/CommandBase",
    "epi-languagemanager/widget/CommandSelector"
],
function (
// Dojo base
    declare,
    lang,
    aspect,

    // Dijit
    popupManager,
    Destroyable,

    // Language manager
    CommandBase,
    CommandSelector
) {

    return declare([CommandBase, Destroyable], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: "",

        category: "context",

        // For contextMenu
        popup: null,
        popupClass: CommandSelector,

        constructor: function (params) {
            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _popupSetter: function (/*Object*/popup) {
            // summary:
            //      Customize set method to setting up on the popup
            // tags:
            //      public override

            this.popup = popup;
            this._setupPopup(this.popup);
            this._setupEvent(this.popup);
        },

        _setupPopup: function (/*Object*/popup) {
            // summary:
            //      Initialize popup sub items and do something else.
            // tags:
            //      private

            // Create sub items
            this._setupSubItems(this.model, popup);
        },

        _setupEvent: function (/*Object*/popup) {
            // summary:
            //      Bind event's listeners on the popup
            // tags:
            //      private

            this.own(
                aspect.after(popup, "onItemSelected", lang.hitch(this, function (command) {
                    var parentMenu = popup.parentMenu;
                    if (parentMenu) {
                        parentMenu._cleanUp();
                        popupManager.close(parentMenu);
                    } else {
                        popupManager.close(popup);
                    }

                    this.onItemSelected(command);
                }), true)
            );
        },

        _onModelChange: function () {
            // summary:
            //      Updates the command and sub commands when the model has been updated.
            // tags:
            //      protected

            if (this.popup) {
                this._setupPopup(this.popup);
            }
        },

        _setupSubItems: function (model, popup) {
            // summary:
            //      Setup sub menu items when user click to the command.
            // tags:
            //      protected

            var subCommands = this.getSubCommands(model);

            popup.set("items", subCommands);
        },

        getSubCommands: function (model) {
            // summary:
            //      Get sub menu items
            // tags:
            //      public
        },

        onItemSelected: function (command) {
            // summary:
            //      Callback when a subcommand is selected
            // tags:
            //      public

            command.execute(true);
        }
    });
});

},
'epi-languagemanager/widget/CommandSelector':function(){
﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/dom-style",

    // Dojox
    "dojox/html/entities",

    // Dijit
    "dijit/registry",
    "dijit/MenuItem",
    "dijit/_TemplatedMixin",

    // EPi CMS
    "epi-cms/widget/SelectorMenuBase",

    // Resouces
    "dojo/text!./templates/CommandSelector.html"

], function (
// Dojo
    declare,
    array,
    lang,
    domStyle,

    // Dojox
    htmlEntities,

    // Dijit
    registry,
    MenuItem,
    _TemplatedMixin,

    // EPi CMS
    SelectorMenuBase,

    // Resouces
    template
) {
    // module:
    //      "epi-languagemanager/widget/CommandSelector"
    // summary:
    //      Used for selecting command options

    return declare([SelectorMenuBase, _TemplatedMixin], {

        // templateString: [protected] String
        //      Html template for the slector
        templateString: template,

        itemClass: MenuItem,

        _setHeaderDisplayAttr: function (visible) {
            domStyle.set(this.headerNode, "display", visible ? "" : "none");
        },

        _setHeadingTextAttr: function (text) {
            this._set("headingText", text);
            this.header.innerHTML = text;
        },

        _setItemsAttr: function (items) {
            this._set("items", items);
            this._setup();
        },

        _setup: function () {

            if (!this.items) {
                return;
            }

            //Destroy the old menu items
            this._removeMenuItems();

            array.forEach(this.items, function (itemData) {

                var menuItem = new this.itemClass({
                    label: htmlEntities.encode(itemData.label),
                    value: itemData.value,
                    _setSelected: this._setSelected,
                    onClick: lang.hitch(this, function (evt) {
                        var target = evt.srcElement || evt.target;
                        if (registry.getEnclosingWidget(target) instanceof this.itemClass) {
                            this.onItemSelected(menuItem.value);
                        }
                    })
                });

                if (itemData.disabled === "disabled") {
                    menuItem.set("disabled", "disabled");
                }

                this.addChild(menuItem);
            }, this);
        },

        onItemSelected: function (item) {
            // summary:
            //   Raised when a item is selected, it will fire the view setting change.
            //
            // tags:
            //    event
        },

        _removeMenuItems: function () {
            var items = this.getChildren();
            items.forEach(function (item) {
                this.removeChild(item);
                item.destroy();
            }, this);
        },

        _setSelected: function (selected) {
            // fix js error when blur menu item. Need to improve later.
        }
    });
});

},
'url:epi-languagemanager/widget/templates/CommandSelector.html':"﻿<div class=\"epi-menu--inverted\">\n    <div class=\"epi-dijitTooltipContainer\">\n        <div data-dojo-attach-point=\"headerNode\" class=\"epi-invertedTooltip\">\n            <div class=\"epi-tooltipDialogTop\">\n                <span data-dojo-attach-point=\"header\"></span>\n                <div class=\"dijitTooltipConnector\"></div>\n            </div>\n        </div>\n        <div class=\"epi-tooltipDialogContent--max-height\">\n            <table class=\"dijitReset dijitMenu epi-tooltipDialogMenu epi-menuInverted epi-mediumMenuItem\" style=\"width: 100%\" cellspacing=\"0\">\n                <tbody data-dojo-attach-point=\"containerNode\"></tbody>\n            </table>\n        </div>\n    </div>\n</div>",
'epi-languagemanager/widget/command/DuplicateContent':function(){
﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/dom-style",

    // Dojox
    "dojox/html/entities",

    // EPi Framework
    "epi/shell/command/_Command",
    "epi/shell/widget/dialog/Dialog",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"

], function (
// Dojo
    declare,
    lang,
    array,
    domStyle,

    // Dojox
    entities,

    // EPi Framework
    _Command,
    Dialog,

    // Resource
    res
) {

    // module:
    //      "epi-languagemanager/widget/command/DuplicateContent"
    // summary:
    //      Used for selecting create language branch options for a page

    return declare([_Command], {

        label: "Duplicate {language} content",

        constructor: function (params) {
            if (params && params.model) {
                var existingLanguageBranches = array.filter(params.model.contentData.existingLanguageBranches, function (item) {
                    return params.model.currentItemData && item.languageId !== params.model.currentItemData.languageID;
                }, this);

                this.label = (existingLanguageBranches && existingLanguageBranches.length > 1) ? res.copyfrom :
                    lang.replace(res.copyfrommaster, { name: params.model.masterLanguage });
            }

            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _onModelChange: function () {
            var existingLanguageBranches = array.filter(this.model.contentData.existingLanguageBranches, function (item) {
                return this.model.currentItemData && item.languageId !== this.model.currentItemData.languageID;
            }, this);

            this.label = (existingLanguageBranches && existingLanguageBranches.length > 1) ? res.copyfrom :
                lang.replace(res.copyfrommaster, { name: this.model.masterLanguage });
        },

        execute: function (isCreatingNew) {
            this._execute(isCreatingNew);
        },

        _execute: function (isCreatingNew) {
            // summary:
            //		Executes this command assuming canExecute has been checked. Subclasses should override this method.
            // tags:
            //		protected

            // creating a new language branch with duplicate content from master
            if (isCreatingNew === true) {
                this.model.duplicateContent();

                return;
            }

            // return if there are no existing language branches, thus there is not the master language branch
            var existingLanguageBranches = this.model.contentData.existingLanguageBranches;
            if (existingLanguageBranches.length === 0) {
                return;
            }

            // replace existing language branch with duplicate content from master
            var masterLanguageName = existingLanguageBranches.filter(function (languageBranch) {
                return languageBranch.isMasterLanguage;
            });

            // Workaround to get the master language.
            if (masterLanguageName.length === 0) {
                masterLanguageName = existingLanguageBranches;
            }

            var dialog = new Dialog({
                destroyOnHide: true,
                dialogClass: "epi-dialog-confirm",
                title: res.replacecontent,
                description: lang.replace(res.duplicatecontentconfirmation,
                    {
                        pageName: entities.encode(this.model.contentData.name),
                        toLanguage: this.model.currentItemData.name,
                        fromLanguage: masterLanguageName[0].name
                    }),
                confirmActionText: res.replacecontent
            });
            domStyle.set(dialog.domNode, { width: "450px" });

            dialog.connect(dialog, "onExecute", lang.hitch(this, function () {
                this.model.duplicateContent();
            }));

            dialog.show();
        }
    });
});

},
'epi-languagemanager/widget/command/StartBlank':function(){
﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/topic",
    // EPi Framework
    "epi-cms/command/TranslateContent",
    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo
    declare,
    topic,
    // EPi Framework
    TranslateContent,
    // Resource
    res
) {

    // module:
    //      "epi-languagemanager/widget/command/StartBlank"
    // summary:
    //      Used for selecting create language branch options for a page

    return declare([TranslateContent], {

        label: res.createlanguagebranch,

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected, extensions

            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _getNormalizedModel: function () {
            // summary:
            //      Gets a normalized model in order to handle the different possible inputs.
            // tags:
            //      protected, extensions

            var model = this.inherited(arguments);

            if (model && !model.language) {
                model.language = {
                    preferredLanguage: this.model.currentItemData.languageID
                };
            }

            return model;
        },

        _execute: function () {
            // summary:
            //      Publishes a change view request to change to the create language branch view.
            // tags:
            //      protected
            var model = this._getNormalizedModel();

            if (typeof this.executeDelegate === "function") {
                this.executeDelegate(this.model);
            } else {
                var data = {
                    contentData: model.content,
                    languageBranch: model.language.preferredLanguage
                };

                topic.publish("/epi/shell/action/changeview", "epi-languagemanager/contentediting/editors/CreateLanguageBranch", null, data);
            }
        }

    });
});

},
'epi-languagemanager/widget/command/AutoTranslate':function(){
﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/dom-style",

    // Dojox
    "dojox/html/entities",

    // EPi Framework
    "epi/shell/command/_Command",
    "epi/shell/widget/dialog/Dialog",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"

], function (
// Dojo
    declare,
    lang,
    array,
    domStyle,

    // Dojox
    entities,

    // EPi Framework
    _Command,
    Dialog,

    // Resource
    res

) {

    // module:
    //      "epi-languagemanager/widget/command/AutoTranslate"
    // summary:
    //      Used for selecting create language branch options for a page

    return declare([_Command], {

        label: "Auto-translate from {language}",

        constructor: function (params) {
            if (params && params.model) {
                var existingLanguageBranches = array.filter(params.model.contentData.existingLanguageBranches, function (item) {
                    return params.model.currentItemData && item.languageId !== params.model.currentItemData.languageID;
                }, this);

                this.label = (existingLanguageBranches && existingLanguageBranches.length > 1) ? res.translateandcopyfrom :
                    lang.replace(res.translateandcopyfrommaster, { name: params.model.masterLanguage });
            }
            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _onModelChange: function () {
            var existingLanguageBranches = array.filter(this.model.contentData.existingLanguageBranches, function (item) {
                return this.model.currentItemData && item.languageId !== this.model.currentItemData.languageID;
            }, this);

            this.label = (existingLanguageBranches && existingLanguageBranches.length > 1) ? res.translateandcopyfrom :
                lang.replace(res.translateandcopyfrommaster, { name: this.model.masterLanguage });
        },

        execute: function (isCreatingNew) {
            this._execute(isCreatingNew);
        },

        _execute: function (isCreatingNew) {
            // summary:
            //		Executes this command assuming canExecute has been checked. Subclasses should override this method.
            // tags:
            //		protected

            // creating a new language branch with auto translate from master
            if (isCreatingNew === true) {
                this.model.autoTranslate();
                return;
            }

            // return if there are no existing language branches, thus there is not the master language branch
            var existingLanguageBranches = this.model.contentData.existingLanguageBranches;
            if (existingLanguageBranches.length === 0) {
                return;
            }

            // replace existing language branch with auto translate from master
            var masterLanguageName = existingLanguageBranches.filter(function (languageBranch) {
                return languageBranch.isMasterLanguage;
            });

            // Workaround to get the master language.
            if (masterLanguageName.length === 0) {
                masterLanguageName = existingLanguageBranches;
            }

            var dialog = new Dialog({
                destroyOnHide: true,
                dialogClass: "epi-dialog-confirm",
                title: res.replacecontent,
                description: lang.replace(res.autotranslateconfirmation,
                    {
                        pageName: entities.encode(this.model.contentData.name),
                        toLanguage: this.model.currentItemData.name,
                        fromLanguage: masterLanguageName[0].name
                    }),
                confirmActionText: res.replacecontent
            });
            domStyle.set(dialog.domNode, { width: "450px" });

            dialog.connect(dialog, "onExecute", lang.hitch(this, function () {
                this.model.autoTranslate();
            }));

            dialog.show();
        }
    });
});

},
'epi-languagemanager/component/command/ReplaceLanguageBranch':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",

    // Epi CMS
    "epi-cms/contentediting/ContentActionSupport",

    // Language manager
    "epi-languagemanager/component/command/_CommandWithOptions",
    "epi-languagemanager/widget/command/DuplicateContent",
    "epi-languagemanager/widget/command/AutoTranslate",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo base
    declare,

    // Epi CMS
    ContentActionSupport,

    // Language manager
    _CommandWithOptions,
    DuplicateContent,
    AutoTranslate,

    // Resource
    res
) {

    return declare([_CommandWithOptions], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.replacecontent,

        _setupPopup: function (/*Object*/popup) {

            this.inherited(arguments);
            popup.set("headerDisplay", false);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            this.inherited(arguments);

            var item = this.model.currentItemData;

            if (!item) {
                this.set("canExecute", false);
                return;
            }

            var isReadonlyVersion = item.versionStatus === ContentActionSupport.versionStatus.CheckedIn
                                    || item.versionStatus === ContentActionSupport.versionStatus.DelayedPublish,
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted or is an unsupported type
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData)
                || this.model.contentData.isDeleted || !this.isSupportedType(this.model.contentData);

            this.set("isAvailable", item.isCreated && item.canEdit && !item.isMaster && item.isActive && !isReadonlyVersion && !disabled);
            this.set("canExecute", item.isCreated && item.canEdit && !item.isMaster && item.isActive && !isReadonlyVersion && !disabled);
        },

        getSubCommands: function (model) {
            // summary:
            //      Setup sub menu items when user click to create language branch.
            // tags:
            //      private

            var isTranslatingSystemAvailable = model.isTranslatingSystemAvailable;

            var autoTranslate = new AutoTranslate({ model: model }),
                duplicateContent = new DuplicateContent({ model: model }),
                languageBranchCommands = [
                    {
                        label: autoTranslate.label,
                        value: autoTranslate,
                        disabled: isTranslatingSystemAvailable === false ? "disabled" : false
                    },
                    {
                        label: duplicateContent.label,
                        value: duplicateContent
                    }
                ];

            return languageBranchCommands;
        }
    });
});

},
'epi-languagemanager/component/command/AddToTranslationProject':function(){
﻿define([
// dojo
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/when",
    // epi
    "epi/shell/widget/dialog/Dialog",
    "epi-cms/core/ContentReference",
    "epi-cms/project/CreateNewDraftConfirmationDialog",
    "epi/dependency",
    // add-ons
    "epi-languagemanager/component/command/CommandBase",
    "epi-languagemanager/widget/AddToTranslationOptions",
    // resource
    "epi/i18n!epi/cms/nls/languagemanager"
],

function (
// dojo
    declare,
    Deferred,
    when,
    // epi
    Dialog,
    ContentReference,
    CreateNewDraftConfirmationDialog,
    dependency,
    // add-ons
    CommandBase,
    AddToTranslationOptions,
    // resource
    res
) {

    return declare([CommandBase], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.gadget.addtotranslationproject,

        category: "context",

        // projectStore: [readonly] Store
        //      A REST store for interacting with projects.
        projectStore: null,

        constructor: function (params) {
            this.inherited(arguments);
            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            var item = this.model.currentItemData;
            if (!item) {
                this.set("canExecute", false);
                this.set("isAvailable", false);
                return;
            }

            var commandAvailable = item.canActivate && item.canEdit && item.isActive;

            when(this.model.hasAnyProject()).then(function (hasProject) {
                this.set("canExecute", commandAvailable && item.isCreated && hasProject);
                this.set("isAvailable", commandAvailable);
            }.bind(this));
        },

        _execute: function () {
            // summary:
            //      Send to translation project.
            // tags:
            //      protected

            var addToTranslationOptions = new AddToTranslationOptions(),
                projectSelector = addToTranslationOptions.projectSelector,
                projectStore = this.projectStore || dependency.resolve("epi.storeregistry").get("epi.cms.project");

            projectSelector.set("store", projectStore);

            this._sendToProjectDialog = new Dialog({
                destroyOnHide: true,
                dialogClass: "epi-dialog-confirm",
                title: res.addtoproject.heading,
                description: res.addtoproject.description,
                content: addToTranslationOptions
            });

            projectSelector.watch("value", this._projectSelectorValueChanged.bind(this));

            this._sendToProjectDialog.on("execute", this._onDialogExecute.bind(this));

            this._sendToProjectDialog.show();

            this._setOkButtonEnabled(false);
        },

        _onDialogExecute: function () {
            // summary:
            //      Performs send to translation process when dialog's "execute" even fired
            // tags:
            //      private

            if (!this._sendToProjectDialog || !this._sendToProjectDialog.content) {
                return;
            }

            var def = new Deferred(),
                currentItemData = this.model.currentItemData;
            if (!this.model.currentItemData.isCreated) {
                when(this.model.duplicateContent()).then(function () {
                    def.resolve();
                }.bind(this));
            } else {
                def.resolve();
            }

            when(def).then(function () {
                var dialogContent = this._sendToProjectDialog.content,
                    projectSelector = dialogContent.projectSelector;
                if (projectSelector) {
                    var selectedProject = dialogContent.projectSelector.get("value");
                    if (selectedProject && selectedProject.id) {
                        var targetProject = selectedProject.id,
                            model = this.model;

                        //Callback method to execute when the canAddContent promise gets resolved
                        var addContent = function (result) {
                            if (result.existingProjectItems.length !== 0) {
                                var dialog = new CreateNewDraftConfirmationDialog({
                                    projectItems: result.existingProjectItems,
                                    contentReferences: result.contentReferences,
                                    onAction: function (dialogResult) {
                                        if (dialogResult) {
                                            model.addProjectItems(targetProject, result.contentReferencesToAdd, currentItemData.languageID);
                                        }
                                    }
                                });

                                dialog.show();

                            } else if (result.contentReferencesToAdd.length > 0) {
                                model.addProjectItems(targetProject, result.contentReferencesToAdd, currentItemData.languageID);
                            }
                        };

                        // 1. Get all content need to translate
                        //      - Checked all children option: Get all descendents of the content
                        //      - Checked related blocks option: Get reference to related blocks of the content (Content Area, Main Area, ...)
                        // 2. Validate the contents can be add/not.
                        //      - Display dialog to show list content has existed in other project
                        return when(model.getContentsToProject(targetProject,
                            dialogContent.addAllChildrenOption && dialogContent.addAllChildrenOption.checked,
                            dialogContent.addRelatedBlocksOption && dialogContent.addRelatedBlocksOption.checked)
                        ).then(function (contentReferences) {

                            var ids = contentReferences.map(function (item) {
                                var reference = ContentReference(item);
                                // TECH NOTE: we DONT know the version of current content when user add content to project from LM context menu,
                                // so that we send content ID and LanguageId, the ProjectStore will add the draff version of that language.
                                reference.workId = 0;

                                return reference.toString();
                            });

                            model.canAddContent(targetProject, ids).then(addContent);
                        });
                    }
                }
            }.bind(this));
        },

        _projectSelectorValueChanged: function (/*String*/propertyName, /*Object*/oldValue, /*Object*/newValue) {
            // summary:
            //      Watchs any change of the Project Selector widget.
            //      If a project selected from list, the "OK" button will be active.
            // propertyName: [String]
            //      The property that watching
            // oldValue: [Object]
            //      The previous selection data
            // newValue: [Object]
            //      The new selection data
            // tags:
            //      private

            if (!newValue) {
                return;
            }
            this._setOkButtonEnabled(true);

            var projectId = newValue.id,
                contentReference = this.model.contentData.contentLink,
                languageId = this.model.currentItemData.languageID;
            when(this.model.isContentExistingInProject(projectId, contentReference, languageId)).then(function (/*Boolean*/existing) {
                this._toggleNotification(existing);
            }.bind(this));
        },

        _toggleNotification: function (/*Boolean*/visible) {
            // summary:
            //      Toggle display of the notification bar.
            // visible: [Boolean]
            //      Flag indicate that the notification bar should display or not.
            // tags:
            //      private

            var dialogContent = this._sendToProjectDialog.content;
            if (dialogContent) {
                if (visible) {
                    (typeof dialogContent.showNotification === "function") && dialogContent.showNotification(res.addtoproject.notification.existingcontent);
                } else {
                    (typeof dialogContent.hideNotification === "function") && dialogContent.hideNotification();
                }
            }
        },

        _setOkButtonEnabled: function (enabled) {
            this._sendToProjectDialog.definitionConsumer.setItemProperty(this._sendToProjectDialog._okButtonName, "disabled", !enabled);
        }
    });

});

},
'epi-languagemanager/widget/AddToTranslationOptions':function(){
﻿define([
// dojo
    "dojo/_base/declare",
    "dojo/dom-style",
    "dojo/html",
    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    // epi
    "epi/dependency",
    "epi/shell/widget/dialog/_DialogContentMixin",
    "epi-cms/project/ProjectSelector",
    // template
    "dojo/text!./templates/AddToTranslationOptions.html",
    // resources
    "epi/i18n!epi/cms/nls/languagemanager.addtoproject"
],
function (
// dojo
    declare,
    domStyle,
    html,
    // dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    // epi
    dependency,
    _DialogContentMixin,
    ProjectSelector, // used in template
    // template
    template,
    // resources
    resources
) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _DialogContentMixin], {

        templateString: template,

        res: resources,

        // projectStore: [readonly] Store
        //      A REST store for interacting with projects.
        projectStore: null,

        postscript: function () {

            this.inherited(arguments);

            this.projectStore = this.projectStore || dependency.resolve("epi.storeregistry").get("epi.cms.project");
        },

        startup: function () {

            this.inherited(arguments);

            var projectSelector = this.projectSelector;

            projectSelector.set("store", this.projectStore);
        },

        showNotification: function (/*String*/message) {
            // summary:
            //      Show notification
            // message: [String]
            //      Notification message to show
            // tags:
            //      public

            html.set(this.notificationMessage, message);

            domStyle.set(this.notificationBar, { display: "block" });
        },

        hideNotification: function () {
            // summary:
            //      Hide notification
            // tags:
            //      public

            domStyle.set(this.notificationBar, { display: "none" });
        }

    });

});

},
'url:epi-languagemanager/widget/templates/AddToTranslationOptions.html':"﻿<section class=\"epi-languageManager-optionsSelector\">\n    <div class=\"epi-languageManager__notificationBar\" data-dojo-attach-point=\"notificationBar\">\n        <span class=\"media-list__object dijitInline dijitReset dijitIcon epi-icon--large epi-icon--colored epi-iconWarning epi-floatLeft\"></span>\n        <label class=\"epi-languageManager__notificationMessage\" data-dojo-attach-point=\"notificationMessage\"></label>\n    </div>\n    <ul class=\"option-list\">\n        <li class=\"option-list-item\">\n            <label data-dojo-attach-point=\"projectSelectorLabel\">${res.options.addtoproject}</label>\n            <span data-dojo-type=\"epi-cms/project/ProjectSelector\" data-dojo-attach-point=\"projectSelector\"></span>\n        </li>\n        <li class=\"option-list-item\">\n            <input data-dojo-attach-point=\"addAllChildrenOption\" id=\"option-addAllChildren\" type=\"checkbox\" />\n            <label for=\"option-addAllChildren\">${res.options.addallchildren}</label>\n        </li>\n        <li class=\"option-list-item\">\n            <input data-dojo-attach-point=\"addRelatedBlocksOption\" id=\"option-addRelatedBlocks\" type=\"checkbox\" />\n            <label for=\"option-addRelatedBlocks\">${res.options.addrelatedblocks}</label>\n        </li>\n    </ul>\n</section>",
'epi-languagemanager/component/viewmodel/LanguageManagerViewModelWrapper':function(){
﻿define([
    // dojo
    "dojo/_base/lang",
    "dojo/_base/array",

    "dojo/aspect",
    "dojo/Deferred",
    "dojo/when",

    "epi/dependency",
    "epi/shell/widget/dialog/Dialog",

    "epi-languagemanager/widget/SourceLanguageOptions",
    // resource
    "epi/i18n!epi/cms/nls/languagemanager"
],
function (
    // dojo
    lang,
    array,

    aspect,
    Deferred,
    when,

    dependency,
    Dialog,

    SourceLanguageOptions,
    // resource
    res
) {

    return function (model) {

        var showSourceLanguageSelectorDialog = function (title, confirmationMessage) {
            var deferred = new Deferred();
            var registry = dependency.resolve("epi.storeregistry"),
                lmStore = registry.get("epi-languagemanager.language-manager");

            when(lmStore.query({ contentLink: model.contentData.contentLink }), function (branches) {
                var existingLanguageBranches = array.filter(branches, function (item) {
                    return item.isCreated && model.currentItemData && item.languageID !== model.currentItemData.languageID;
                });

                if (!existingLanguageBranches || existingLanguageBranches.length === 1) {
                    deferred.resolve(null);
                } else {
                    when(confirmationMessage, function (message) {
                        var sourceLanguageOptions = new SourceLanguageOptions({ languageBranches: existingLanguageBranches });
                        var dialog = new Dialog({
                            destroyOnHide: true,
                            dialogClass: "epi-dialog-confirm",
                            title: title,
                            description: message,
                            content: sourceLanguageOptions
                        });

                        dialog.on("execute", lang.hitch(this, function () {
                            deferred.resolve(dialog.content.selectedLanguage.languageID);
                        }));

                        dialog.on("cancel", lang.hitch(this, function () {
                            deferred.cancel();
                        }));

                        dialog.show();
                    });
                }
            });

            return deferred;
        };

        var autoTranslate = function (originalMethod) {
            var confirmation = showSourceLanguageSelectorDialog(res.translatecontent.heading, res.translatecontent.description);

            return when(confirmation, function (selectedLanguage) {
                // Call pasteItem of the model
                return originalMethod.apply(model, [selectedLanguage]);
            }, function () {
                return false;
            });
        };

        var duplicateContent = function (originalMethod) {
            var confirmation = showSourceLanguageSelectorDialog(res.dulicatecontent.heading, res.dulicatecontent.description);

            return when(confirmation, function (selectedLanguage) {
                // Call pasteItem of the model
                return originalMethod.apply(model, [selectedLanguage]);
            }, function () {
                return false;
            });
        };

        aspect.around(model, "autoTranslate", function (originalMethod) {
            return function () {
                return autoTranslate(originalMethod, arguments);
            };
        });

        aspect.around(model, "duplicateContent", function (originalMethod) {
            return function () {
                return duplicateContent(originalMethod, arguments);
            };
        });

        return model;
    };
});

},
'epi-languagemanager/widget/SourceLanguageOptions':function(){
﻿define([
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/dom-construct",
    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    // epi
    "epi/shell/widget/dialog/_DialogContentMixin",
    //epi-languagemanager
    "./LanguageOption",
    // template
    "dojo/text!./templates/SourceLanguageOptions.html",
    // resources
    "epi/i18n!epi/cms/nls/languagemanager.addtoproject"
],
function (
// dojo
    declare,
    lang,
    array,
    domConstruct,
    // dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    // epi
    _DialogContentMixin,
    //epi-languagemanager
    LanguageOption,
    // template
    template
) {
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _DialogContentMixin], {
        templateString: template,

        postCreate: function () {
            this.inherited(arguments);

            this.renderListOptions();
        },

        renderListOptions: function () {
            if (!this.languageBranches || !this.languageBranches.length) {
                return;
            }

            array.forEach(this.languageBranches, function (item) {
                var itemSetting = null;
                this.own(
                    itemSetting = new LanguageOption({ item: item }),
                    this.connect(itemSetting, "onChange", lang.hitch(this, function (item, selected) {
                        if (selected) {
                            this.selectedLanguage = item;
                            this.onChange(this.selectedLanguage);
                        }
                    }))
                );
                domConstruct.place(itemSetting.domNode, this.languagesNode, "last");
            }, this);
        },

        onChange: function () {

        }
    });
});

},
'epi-languagemanager/widget/LanguageOption':function(){
﻿define([
// dojo
    "dojo/_base/declare",
    "dojo/dom-class",
    "dojo/dom-construct",
    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/RadioButton",
    // template
    "dojo/text!./templates/LanguageOption.html",
    // Resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// dojo
    declare,
    domClass,
    domConstruct,
    // dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    RadioButton, // used in template
    // template
    template,
    // Resources
    res
) {
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        templateString: template,

        buildRendering: function () {
            this.inherited(arguments);
            var span = null;
            if (this.item && this.item.isMaster) {
                domClass.add(this.optionWrapper, "master");
                span = domConstruct.toDom("<span> (" + res.master + ")</span>");
                domConstruct.place(span, this.optionLabel, "last");
            }

            if (this.item && this.item.systemIconPath) {
                span = domConstruct.toDom("<span class='systemIcon' style='background-image:url(" + this.item.systemIconPath + ")'" + " ></span>");
                domConstruct.place(span, this.optionLabel, "first");
            }
        },

        postCreate: function () {
            this.inherited(arguments);
            if (this.item && this.item.isMaster) {
                this.optionButton.set("value", true);
            }
        },

        _onChanged: function (selected) {
            this.onChange(this.item, selected);
        },

        onChange: function () {

        }
    });
});

},
'url:epi-languagemanager/widget/templates/LanguageOption.html':"﻿<li class=\"option-list-item\" data-dojo-attach-point=\"optionWrapper\">\n    <input data-dojo-attach-point=\"optionButton\" id=\"rdb-${item.languageID}\" data-dojo-props=\"name: 'languageOption'\" data-dojo-type=\"dijit/form/RadioButton\" data-dojo-attach-event=\"onChange: _onChanged\" />\n    <label data-dojo-attach-point=\"optionLabel\" for=\"rdb-${item.languageID}\">${item.name}</label>\n</li>",
'url:epi-languagemanager/widget/templates/SourceLanguageOptions.html':"﻿<section class=\"epi-languageManager-optionsSelector\">\n    <ul data-dojo-attach-point=\"languagesNode\" class=\"option-list\">       \n    </ul>\n</section>"}});
﻿/* This is for collecting all needed modules for bundling/minifying */
