define("epi-forms/contentediting/editors/WebhookActorEditor", [// dojo
"dojo/_base/declare", // epi-addons
"epi-forms/contentediting/editors/CollectionEditor", // resources
"epi/i18n!epi/cms/nls/episerver.forms.editview"], function ( // dojo
declare, // epi-addons
CollectionEditor, // resources
resources) {
  // module:
  //      epi-forms/contentediting/editors/WebhookActorEditor
  // summary:
  //      Editor for Webhook.
  // tags:
  //      public
  return declare([CollectionEditor], {
    _getDialogTitleText: function _getDialogTitleText(existingItem) {
      // summary:
      //      Get dialog title for create/edit Webhoook.
      // tags:
      //      Override
      return existingItem ? resources.editwebhook : resources.addwebhook;
    },
    _setDialogConfirmActionStatus: function _setDialogConfirmActionStatus() {
      // summary:
      //     Set confirm action status when showing dialog
      // tags:
      //      Override
      this._dialog.onActionPropertyChanged({
        name: this._dialog._okButtonName
      }, "disabled", false);
    }
  });
});