define("epi-forms/widget/ChoiceItemWithClearableSelection", [// dojo
"dojo/_base/declare", // epi-addons
"epi-forms/widget/ChoiceItemWithSelection"], function ( // dojo
declare, // epi-addons
ChoiceItemWithSelection) {
  // module:
  //      epi-forms/widget/ChoiceItemWithClearableSelection
  // tags:
  //      public
  return declare([ChoiceItemWithSelection], {
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    _updateSelectorValue: function _updateSelectorValue(
    /*String*/
    value) {
      // summary:
      //      Uncheck the selector if value is empty.
      // tags:
      //      override
      this.inherited(arguments);

      if (!value) {
        this._selector.set("checked", false);
      }
    }
  });
});