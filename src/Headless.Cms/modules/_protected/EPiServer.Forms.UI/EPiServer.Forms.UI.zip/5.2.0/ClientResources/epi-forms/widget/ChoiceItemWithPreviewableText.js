define("epi-forms/widget/ChoiceItemWithPreviewableText", [// dojo
"dojo/_base/declare", "dojo/dom-class", // epi-addons
"epi-forms/ModuleSettings", "epi-forms/widget/_ChoiceItemWithExtendedWidget"], function ( // dojo
declare, domClass, // epi-addons
ModuleSettings, _ChoiceItemWithExtendedWidget) {
  // module:
  //      epi-forms/widget/ChoiceItemWithPreviewableText
  // summary:
  //
  // tags:
  //      public
  return declare([_ChoiceItemWithExtendedWidget], {
    _getExtendedWidgetControl: function _getExtendedWidgetControl() {
      // summary:
      //      By default, return the control inside the widget
      // tags:
      //      override
      return this._extendedWidget.control;
    },
    _getAllowPreviewableTextBoxItems: function _getAllowPreviewableTextBoxItems() {
      // summary:
      //     return a list from the module settings.
      // tags:
      //      override
      return ModuleSettings.allowedPreviewableTextBoxTypes;
    },
    _doSetupExtendedWidget: function _doSetupExtendedWidget(
    /*Object*/
    item,
    /*Object*/
    extendedWidget) {
      // summary:
      //      Remove ellipsis class
      // tags:
      //      override
      // Should not ellipsis 'epi-cms/contentediting/editors/PreviewableTextEditor' widget's label
      if (extendedWidget.labelNode) {
        domClass.remove(extendedWidget.labelNode, "dijitInline dojoxEllipsis");
      }
    }
  });
});