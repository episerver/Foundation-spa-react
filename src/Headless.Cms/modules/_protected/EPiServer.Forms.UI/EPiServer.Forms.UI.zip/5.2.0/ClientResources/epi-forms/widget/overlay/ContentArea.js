define("epi-forms/widget/overlay/ContentArea", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/topic", "dojo/when", "dojo/dom-class", "dojo/dom-attr", // epi
"epi-cms/core/ContentReference", "epi-cms/widget/overlay/ContentArea", "epi/shell/TypeDescriptorManager", "epi/dependency", // epi-addons
"epi-forms/ModuleSettings", "epi-forms/widget/_ContentAreaMixin", "epi-forms/widget/command/CreateContentFromSelector", "epi-forms/contentediting/ContentAreaViewModel", // resources
"epi/i18n!epi/cms/nls/episerver.forms.editview"], function ( // dojo
declare, lang, topic, when, domClass, domAttr, // epi
ContentReference, ContentArea, TypeDescriptorManager, dependency, // epi-addons
ModuleSettings, _ContentAreaMixin, CreateContentFromSelector, ContentAreaViewModel, // resources
resources) {
  // module:
  //      epi-forms/widget/overlay/ContentArea
  // summary:
  //
  // tags:
  //      public
  return declare([ContentArea, _ContentAreaMixin], {
    // =======================================================================
    // Overrided stubs
    // =======================================================================
    modelClass: ContentAreaViewModel,
    formElementStore: null,
    postMixInProperties: function postMixInProperties() {
      this.inherited(arguments);
      var registry = dependency.resolve("epi.storeregistry");
      this.formElementStore = registry.get("epi-forms.formselement");
    },
    executeAction: function executeAction(
    /*String*/
    actionName,
    /*Object*/
    itemData) {
      // summary:
      //
      // actionName: [String]
      //
      // itemData: [Object]
      //
      // tags:
      //      public, extensions
      var command = null;

      if (actionName === ModuleSettings.createNewFormsElementByDndActionName) {
        command = this._getCreateNewFormsBlockCommand(itemData);
      }

      if (actionName === ModuleSettings.createNewFormsElementActionName) {
        command = this._getCreateNewBlockCommand();
      }

      if (!command) {
        return;
      }

      command.set("model", {
        save: lang.hitch(this, function (block) {
          var value = lang.clone(this.model.get("value"), true) || [];
          value.push(block);
          this.onValueChange({
            propertyName: this._source.propertyName,
            value: value
          });
        })
      });
      command.execute();
    },
    _onDrop: function _onDrop(
    /*Array*/
    data,
    /*Object*/
    source,
    /*Array*/
    nodes,
    /*Boolean*/
    isCopy) {
      // summary:
      //      onDrop handler for the source.
      // data: [Array]
      //      Data extracted from the dragged items.
      // source: [Object]
      //      The source that the drag event originated from.
      // nodes: [Array]
      //      The nodes being dragged.
      // isCopy: [Boolean]
      //      Flag indicating whether the drag is a copy. False indicates a move.
      // tags:
      //      protected, extensions
      var self = this,
          itemData = data instanceof Array && data[0],
          targetAnchor = this._source.targetAnchor,
          before = this._source.before;

      if (itemData && itemData.options && itemData.options.createNew === true) {
        if (ModuleSettings.quickLayout) {
          when(self.model.getCurrentContent(), lang.hitch(this, function (contentData) {
            when(self.model._getMetadata(contentData.contentLink, itemData.options.contentTypeId), lang.hitch(this, function (metadata) {
              metadata = self.model._regroupProperties(metadata); // If the content has any required properties then go to CreateContent view

              if (self.model._hasRequiredProperties(metadata)) {
                topic.publish("/epi/shell/action/changeview", "epi-forms/contentediting/CreateContent", null, {
                  contentTypeId: itemData.options.contentTypeId,
                  requestedType: itemData.data.typeIdentifier,
                  parent: contentData,
                  addToDestination: {
                    save: function save(content) {
                      // summary:
                      //  execution after new content is created
                      // content: [Object]
                      //  new content
                      return self._dropContent(content, targetAnchor, before, source, nodes, isCopy);
                    }
                  },
                  createAsLocalAsset: true,
                  view: TypeDescriptorManager.getValue(itemData.data.typeIdentifier, "createView"),
                  autoPublish: true,
                  allowedTypes: self.allowedTypes,
                  restrictedTypes: self.restrictedTypes,
                  showAllProperties: false
                });
              } else {
                // If content has no required properties then create on the fly
                when(self._getElementByType(itemData.options.contentTypeId, this.contentModel.get("icontent_contentlink")), lang.hitch(this, function (contentLink) {
                  var contentWithoutVersion = new ContentReference(contentLink).createVersionUnspecificReference().toString();
                  when(self.contentDataStore.get(contentWithoutVersion), lang.hitch(this, function (content) {
                    return self._dropContent(content, targetAnchor, before, source, nodes, isCopy);
                  }));
                }));
              }
            }));
          }));
        } else {
          this.executeAction(ModuleSettings.createNewFormsElementByDndActionName, itemData);
        }

        return;
      }

      this.inherited(arguments);
    },
    // =======================================================================
    // Private stubs
    // =======================================================================
    _getCreateNewBlockCommand: function _getCreateNewBlockCommand() {
      // summary:
      //
      // returns: [Object]
      //
      // tags:
      //      private
      return new CreateContentFromSelector({
        allowedTypes: this.allowedTypes,
        createAsLocalAsset: true,
        creatingTypeIdentifier: ModuleSettings.formElementBaseContentType,
        restrictedTypes: this.restrictedTypes
      });
    },
    _getCreateNewFormsBlockCommand: function _getCreateNewFormsBlockCommand(
    /*Object*/
    itemData) {
      // summary:
      //
      // itemData: [Object]
      //
      // returns: [Object]
      //
      // tags:
      //      private
      return new CreateContentFromSelector({
        allowedTypes: this.allowedTypes,
        createAsLocalAsset: true,
        creatingTypeIdentifier: itemData.data.typeIdentifier,
        contentTypeId: itemData.options.contentTypeId,
        restrictedTypes: this.restrictedTypes
      });
    },
    _dropContent: function _dropContent(content, targetAnchor, before, source, nodes, isCopy) {
      // summary:
      //      Operation after new content is created.
      var newData = [{
        data: content,
        type: this._getDndTypes(content.typeIdentifier)
      }]; // Rebind source's properties:
      //      targetAnchor
      //      before

      if (!this._source.targetAnchor) {
        this._source.targetAnchor = targetAnchor;
        this._source.before = before;
      } // delegate operation to superclass


      ContentArea.prototype._onDrop.apply(this, [newData, source, nodes, isCopy]);
    },
    addChild: function addChild(
    /*dijit/_Widget*/
    widget,
    /*int?*/
    insertIndex) {
      // summary:
      //        after a form element block is added to content area
      //        if it is related to any dependency rules, then, a css class is added to its dom
      //        this helps editors to differentiate this kind of element (related to dependency) with the normal ones.
      this.inherited(arguments);
      var overlayItemInfo = widget.get("overlayItemInfo");

      if (!overlayItemInfo) {
        return;
      }

      var query = {
        id: new ContentReference(widget.viewModel.contentLink),
        query: "HasDependencySettings"
      };
      when(this.formElementStore.query(query), lang.hitch(this, function (result) {
        if (!result) {
          return;
        }

        domClass.add(overlayItemInfo.domNode, "epi-forms-overlay-field-dependency");
        domAttr.set(overlayItemInfo.domNode, "title", resources.elementdependant);
      }));
    }
  });
});