define("epi-forms/widget/TargetPageSelector", [// dojo
"dojo/_base/declare", // epi
"epi/shell/widget/dialog/Dialog", "epi-cms/widget/UrlSelector", // epi-addons
"epi-forms/widget/TargetPageEditor", // resources
"epi/i18n!epi/cms/nls/episerver.forms.editview"], function ( // dojo
declare, // epi
Dialog, UrlSelector, // epi-addons
TargetPageEditor, // resources
resources) {
  // module:
  //      epi-forms/widget/TargetPageSelector
  // tags:
  //      public
  return declare([UrlSelector], {
    _setupDialogSettings: function _setupDialogSettings() {
      // summary:
      //      Setup settings for dialog.
      // tags:
      //      protected virtual
      this.inherited(arguments);
      this.dialogSettings = Object.assign(this.dialogSettings, {
        title: this._getTitle(),
        dialogContentClass: TargetPageEditor,
        dialogClass: "epi-dialog-portrait",
        destroyOnHide: false,
        defaultActionsVisible: false
      });
    },
    _getTitle: function _getTitle() {
      // summary:
      //      Get title for the dialog.
      // tags:
      //      Override
      return resources.selectpage;
    }
  });
});