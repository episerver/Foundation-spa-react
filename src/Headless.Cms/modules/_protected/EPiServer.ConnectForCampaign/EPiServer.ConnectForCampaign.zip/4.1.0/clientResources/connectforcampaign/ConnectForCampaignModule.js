﻿define([
// Dojo
    "dojo",
    "dojo/_base/declare",
//CMS
    "epi/_Module",
    "epi/dependency",
    "epi/routes"
], function (
// Dojo
    dojo,
    declare,
//CMS
    _Module,
    dependency,
    routes
) {

    return declare([_Module], {
        initialize: function () {

            this.inherited(arguments);

            var registry = this.resolveDependency("epi.storeregistry");

            registry.create("connectforcampaign.campaigndatastore", this._getRestPath("campaigndatastore"));
        },

        _getRestPath: function (name) {
            return routes.getRestPath({
                moduleArea: 'EPiServer.ConnectForCampaign',
                storeName: name
            });
        }
    });
});