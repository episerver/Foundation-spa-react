﻿﻿define([
    // dojo
    'dojo/_base/declare',
    'dojo/_base/lang',
    // epi-addons
    'epi-forms/widget/ChoiceItemWithClearableSelection'
],
    function (
        // dojo
        declare,
        lang,
        // epi-addons
        ChoiceItemWithClearableSelection
    ) {

        // module:
        //      connectforcampaign/widget/CampaignChoiceItemWithSelection
        // summary:
        //      Extend Forms's ChoiceItemWithClearableSelection to support the extended widget type RecipientAndOptInSelector
        // tags:
        //      public

        return declare([ChoiceItemWithClearableSelection], {

            _getParams: function (item) {
                // summary:
                //      Override to add additional params if the item is Marketing Connectors
                // tags:
                //      Override

                var params = this.inherited(arguments);

                if (item.value.indexOf(this.marketingConnectorsId) == 0) {
                    lang.mixin(params, {
                        campaignDataStoreName: this.campaignDataStoreName,
                        campaignAdaptedConnectorId: this.campaignAdaptedConnectorId,
                        campaignDatasourceFormat: this.campaignDatasourceFormat
                    });
                }

                return params;
            },

            isValid: function () {
                // summary:
                //      Return the current value is valid or not depend on children widget.
                // tags:
                //      override
                var isValid = this.inherited(arguments);

                var checked = this._selector.get("checked");
                if (checked
                    && this._extendedWidget
                    && this._extendedWidget.isCampaignDatasourceSelected
                    && this._extendedWidget.isCampaignDatasourceSelected()
                    && this._extendedWidget.isValid) {

                    return this._extendedWidget.isValid() && isValid;
                }

                return isValid;
            }

        });

    });