﻿//TODO: sort dependencies

define([
    "dojo/_base/declare",
    "dojo/dom-class",
    "dojo/when",
    "dojo/dom-construct",
    "dojo/html",
    "dojo/dom-geometry",
    "dojo/topic",

    // djit
    "dijit/Viewport",
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

    // EPI
    "epi/shell/TypeDescriptorManager",
    "epi/shell/command/builder/ButtonBuilder",

    //"epi/shell/layout/PreserveRatioBorderContainer", // used in template
    "epi-cms/contentediting/EditToolbar",
    "dojo/text!./templates/childrenGridViewTemplate.html",

    "epi-cms/_ContentContextMixin",
    "epi/dependency",
    "epi/routes",
    "epi-cms/component/command/ViewTrash",

    "episerver-labs-grid-view/commands/moveUpCommand",
    "episerver-labs-grid-view/commands/showMainMenuCommand",

    "epi-cms/core/ContentReference",

    "episerver-labs-grid-view/childrenContentFilteredGrid",

    "xstyle/css!./styles.css"
], function(
    declare,
    domClass,
    when,
    domConstruct, //TODO: unused
    html,
    domGeometry,
    topic,

    // dijit
    Viewport,
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,

    // EPI
    TypeDescriptorManager,
    ButtonBuilder,

    //PreserveRatioBorderContainer,
    EditToolbar,
    template,
    _ContentContextMixin,
    dependency,
    routes,
    ViewTrashCommand,

    MoveUpCommand,
    ShowMainMenuCommand,

    ContentReference,

    ContentFilteredGrid
) {
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _ContentContextMixin], {
        templateString: template,

        _toolbarVisible: true,

        startup: function() {
            if (this._started) {
                return;
            }

            this.inherited(arguments);

            this.own(Viewport.on("resize", this.resize.bind(this)));

            domClass.add(this.toolbar.domNode, "epi-localToolbar epi-viewHeaderContainer");

            when(this.getCurrentContext()).then(function(context) {
                this.contextChanged(context);
            }.bind(this));
        },

        postMixInProperties: function() {
            this.inherited(arguments);

            var registry = dependency.resolve("epi.storeregistry");
            this._contentLightStore = registry.get("epi.cms.content.light");
            this._contentStore = registry.get("epi.cms.contentdata");

//TODO: own
            this._moveUpCommand = new MoveUpCommand();
            this._showMainMenuCommand = new ShowMainMenuCommand();

            this.own(
                this._moveUpCommand,
                this._showMainMenuCommand
            );
        },

        buildRendering: function () {
            this.inherited(arguments);

            this.own(
                this.filteredGrid.model.on("contentChangeRequest", function (item) {
                    topic.publish("/epi/shell/context/request", { uri: item.uri }, { sender: this, forceReload: true });
                })
            );

            var builder = new ButtonBuilder();
            builder.settings = this._moveUpCommand.settings;
            builder.create(this._moveUpCommand, this.moveUpCommandNode);

            this._showMainMenuCommand.set("contextMenuCommandProvider", this.filteredGrid.getContextMenuCommandProvider());
            builder.settings = this._showMainMenuCommand.settings;
            builder.create(this._showMainMenuCommand, this.menuCommandNode);

            var viewTrashCommand = new ViewTrashCommand();
            viewTrashCommand.settings = viewTrashCommand.settings || {};
            viewTrashCommand.settings.class = "epi-chromeless";
            viewTrashCommand.settings.iconClass = "epi-iconTrash";
            builder.settings = viewTrashCommand.settings;
            builder.create(viewTrashCommand, this.viewTrashNode);
        },

        updateView: function(callerData, ctx, additionalParams) {
            if (this._toolbarVisible) {
                this.toolbar.update({
                    currentContext: ctx,
                    viewConfigurations: {
                        availableViews: callerData.availableViews,
                        viewName: callerData.viewName
                    }
                });
            }

            var contentLink = ctx.id;
            this._currentParentContentLink = ctx.parentLink;
            when(this._contentStore.refresh(contentLink)).then(function(contentData) {
                if (!contentData) {
                    return;
                }
                var contentViewModel = this.filteredGrid.createContentViewModel(contentData, ctx);
                this.toolbar.set("contentViewModel", contentViewModel);
            }.bind(this));

            var contentLinkWithoutVersion =  (new ContentReference(contentLink)).createVersionUnspecificReference().toString();
            when(this._contentLightStore.refresh(contentLinkWithoutVersion)).then(function (contentData) {
                if (!contentData) {
                    return;
                }
                html.set(this.header, contentData.name);

                var contentViewModel = this.filteredGrid.createContentViewModel(contentData, ctx);

                this._moveUpCommand.set("model", contentViewModel);
                this._showMainMenuCommand.set("model", contentViewModel);

                var gridSettings = TypeDescriptorManager.getValue(contentData.typeIdentifier, "gridSettings");
                this.filteredGrid.changeDisplayedContext(ctx.id, contentData, gridSettings);
            }.bind(this));
        },

        contentContextChanged: function (context, callerData, request) {
            // when context changed grid automatically
            // refresh the data while it should be configured first
            // pauseFetchingData will prevent from fetching the data
            this.filteredGrid.contentQuery.pauseFetchingData();  //TODO: do I need it here?

            // save button and Edit Actions should be never displayed
            this.toolbar.setItemVisibility("autosave", false);
            this.toolbar.setItemVisibility("editactionpanel", false);
        },

        resize: function () {
            // set grid haight
            var cb = domGeometry.getMarginBox(this.domNode);
            var ocb = this._oldContentBox;

            if (cb && ocb) {
                if (cb.w === ocb.w && cb.h === ocb.h) {
                    return;
                }
            }
            this._oldContentBox = cb;

            var top = domGeometry.getMarginBox(this.header).h;
            if (this._toolbarVisible) {
                top += domGeometry.getMarginBox(this.toolbar.domNode).h;
            }

            this.filteredGrid.setGridSize(cb.w, cb.h - top);
        }
    });
});
