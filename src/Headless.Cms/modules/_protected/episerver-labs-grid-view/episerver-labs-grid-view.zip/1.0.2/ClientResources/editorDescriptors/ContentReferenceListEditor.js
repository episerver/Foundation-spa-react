define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
    "dojo/Deferred",
    "dojo/dom-construct",

    "epi/shell/_ContextMixin",

    "epi-cms/contentediting/editors/ContentReferenceListEditor",

    "episerver-labs-grid-view/editorDescriptors/withChildrenGridDialogMixin"
],
function (
    declare,
    lang,
    when,
    Deferred,
    domConstruct,

    _ContextMixin,

    ContentReferenceListEditor,

    withChildrenGridDialogMixin
) {
    return declare([ContentReferenceListEditor, withChildrenGridDialogMixin, _ContextMixin], {
        getTemplateString: function () {
            var result = this.inherited(arguments);

            return {
                templateString: result.templateString + "<br/>{selectcontent}",
                actions: lang.mixin(result.actions, { selectcontent: "Select content" })
            };
        },

        executeAction: function (actionName) {
            if (actionName === "selectcontent") {
                this._showDialog();
            } else {
                this.inherited(arguments);
            }
        },

        _showDialog: function () {
            var currentValue = this.getDefaultRoot();

            var dialog = this._getChildrenGridDialog();
            this.isShowingChildDialog = true;

            this.childrenGridView.setContext({ id: currentValue }, this.gridSettings);
            dialog.show();
        },

        _onChildrenGridDialogExecute: function () {
            var values = this.childrenGridView.get("selectedContentReferences");
            if (!values || values.length === 0) {
                return;
            }

            values.forEach(function (value) {
                this.model.addContentLink(value);
            }, this);
        },

        focusChildrenGridDialog: function () {

        }
    });
});
