﻿define([
    "dojo/_base/declare",
    "dojo/when",
    "dojo/topic",
    "epi/dependency",
    "epi/shell/widget/ContextMenu",
    "epi-cms/contentediting/command/_ContentCommandBase",
    "epi-cms/component/ContentContextMenuCommandProvider"
],

function (
    declare,
    when,
    topic,
    dependency,
    ContextMenu,
    _ContentCommandBase,
    ContentContextMenuCommandProvider
) {

    return declare([_ContentCommandBase], {
        name: "showMainMenu",
        label: null,
        tooltip: null,

        settings: {
            "class": "epi-chromeless",
            iconClass: "epi-iconContextMenu",
            showLabel: false
        },

        canExecute: true,

        constructor: function () {
            var registry = dependency.resolve("epi.storeregistry");
            this.store = registry.get("epi.cms.contentdata");
        },

        execute: function (evt) {
            if (!this.isAvailable || !this.canExecute) {
                return;
            }

            this._contextMenuCommandProvider.updateCommandModel(this.model.contentData);

            if (!this._contextMenu) {
                this._contextMenu = new ContextMenu({ leftClickToOpen: true, category: "context" });
                //connect.connect(this._contextMenu, "onClose", this, "_onContextMenuClose"),
                //connect.connect(this._contextMenu, "onOpen", this, "_onContextMenuOpen")
                this._contextMenu.addProvider(this._contextMenuCommandProvider);
                this._contextMenu.startup();
            }

            //Open the context menu
            this._contextMenu.scheduleOpen(evt.target, null, { x: evt.x, y: evt.y });
        },

        _contextMenuCommandProviderSetter: function (value) {
            this._contextMenuCommandProvider = value;
        },

        _onModelChange: function () {
            this.inherited(arguments);

            //var contentData = this.model.contentData;
            this.set("canExecute", true);
        }
    });

});
