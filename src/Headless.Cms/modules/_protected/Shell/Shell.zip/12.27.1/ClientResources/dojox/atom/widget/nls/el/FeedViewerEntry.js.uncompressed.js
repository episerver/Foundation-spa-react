define(
"dojox/atom/widget/nls/el/FeedViewerEntry", ({
	deleteButton: "[Διαγραφή]"
})
);
