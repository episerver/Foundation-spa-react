define(
"dojox/atom/widget/nls/hr/FeedEntryViewer", ({
	displayOptions: "[opcije prikaza]",
	title: "Naslov",
	authors: "Autori",
	contributors: "Doprinositelji",
	id: "ID",
	close: "[zatvori]",
	updated: "Ažurirano",
	summary: "Sažetak",
	content: "Sadržaj"
})
);
