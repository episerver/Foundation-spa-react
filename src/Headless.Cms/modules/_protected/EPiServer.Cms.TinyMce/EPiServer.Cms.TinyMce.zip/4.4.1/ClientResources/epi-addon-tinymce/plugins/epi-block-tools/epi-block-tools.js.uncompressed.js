define("epi-addon-tinymce/plugins/epi-block-tools/epi-block-tools", [
    "dojo/topic",
    "dojo/Deferred",
    "dojo/when",
    "epi",
    "epi-addon-tinymce/tinymce-loader",
    "epi-addon-tinymce/ContentService",
    "epi-cms/contentediting/command/BlockInlineEdit",
    "epi/i18n!epi/cms/nls/episerver.cms.tinymce.plugins.epiblocktools"
], function (topic, Deferred, when, epi, tinymce, ContentService, BlockInlineEdit, pluginResources) {

    tinymce.PluginManager.add("epi-block-tools", function (editor) {
        var self = this;
        var tooltipPlaceholder = "epi-gotoblock-button-tooltip-placeholder";

        function isBlock(el) {
            var selectorMatched = editor.dom.is(el, "div.epi-contentfragment:not([mceItem])");
            return selectorMatched;
        }

        function addToolbars() {
            editor.ui.registry.addContextToolbar("epi-gotoblock",
                {
                    predicate: function (node) {
                        return isBlock(node);
                    },
                    position: "node",
                    items: "epi-gotoblock"
                });
        }

        var contentService = new ContentService();
        var blockInlineEditCommand = new BlockInlineEdit({
            suppressOverlayAdjustments: self.isFullScreen
        });

        var currentContent = null;
        var updateButton = function (button, command) {
            var selectedElement = editor.selection.getNode();

            if (isBlock(selectedElement)) {
                var contentLink = selectedElement.dataset && selectedElement.dataset.contentlink;
                if (!contentLink) {
                    if (button) {
                        button.setEnabled(false);
                        button.settings.tooltip = pluginResources.error;
                    }
                    return false;
                }
                return contentService.getContent(contentLink)
                    .then(function (content) {
                        currentContent = content;
                        return contentService.getPathToContent(content);
                    })
                    .then(function (blockPath) {
                        if (button) {
                            button.setEnabled(true);
                            // HACK to get dom due to TinyMCE isn't expose api to do that now.
                            // Note: the button was rendered.
                            // See more: https://www.tiny.cloud/docs/tinymce/6/custom-basic-toolbar-button/#using-onsetup
                            // and TinyMCE API feature request equivalent to: https://github.com/tinymce/tinymce/issues/5966
                            var buttonRef = document.querySelector("button[title='" + tooltipPlaceholder + "'");
                            if (buttonRef) {
                                buttonRef.title = blockPath;
                                buttonRef.setAttribute("aria-label", blockPath);
                            }
                        }

                        if (currentContent.capabilities.isLocalContent) {
                            command.set("model", currentContent);
                            var watchDef = new Deferred();
                            var handle = command.watch("canExecute", function (name, oldValue, newValue) {
                                handle.remove();
                                handle = null;
                                if (button) {
                                    button.setEnabled(newValue);
                                }
                                watchDef.resolve(true);
                            });
                            return watchDef.promise;
                        }
                    })
                    .otherwise(function () {
                        if (button) {
                            button.setEnabled(false);
                        }
                        return false;
                    });
            }

            return false;
        };

        editor.on("FullscreenStateChanged", function (event) {
            self.isFullScreen = event.state;
        });

        var dblClickCommand = new BlockInlineEdit({
            suppressOverlayAdjustments: self.isFullScreen
        });
        function onDblClick(e) {
            when(updateButton(undefined, dblClickCommand)).then(function (result) {
                if (!result) {
                    return;
                }
                if (isBlock(e.srcElement)) {
                    if (dblClickCommand && dblClickCommand.get("canExecute")) {
                        // execution of the command has to be queued at the end
                        // after the mainCommand will be created
                        setTimeout(function () {
                            dblClickCommand.execute();
                        }, 0);
                    }
                }
            });
        }

        // Register buttons
        editor.ui.registry.addButton("epi-gotoblock", {
            text: epi.resources.action.edit,
            tooltip: tooltipPlaceholder,
            onAction: function () {
                editor.fire("contexttoolbar-hide", "epi-gotoblock");
                editor.fire("blur");
                if (!currentContent.capabilities.isLocalContent) {
                    topic.publish("/epi/shell/context/request", { uri: currentContent.uri }, { sender: this });
                    return;
                }

                if (blockInlineEditCommand && blockInlineEditCommand.get("canExecute")) {
                    blockInlineEditCommand.execute();
                }
            },
            onSetup: function (buttonApi) {
                //Set tooltip the first time tinymce starts after browser refresh
                updateButton(buttonApi, blockInlineEditCommand);
            }
        });

        editor.on("dblclick", onDblClick);

        addToolbars();

        return {
            getMetadata: function () {
                return {
                    name: "Block tools (epi)",
                    url: "https://www.optimizely.com"
                };
            }
        };
    });
});
