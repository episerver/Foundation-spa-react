﻿define("epi-find/servicehealth/ServiceHealthController", [
    "dojo/_base/declare",
    "../_ControllerBase",
    "./ServiceHealthModel",
    "../widget/ServiceHealth",
    "../widget/_ActionableMixin"
],
function(declare,
    _ControllerBase,
    ServiceHealthModel,
    ServiceHealth,
    _ActionableMixin
) {
    return declare([_ControllerBase, _ActionableMixin], {
        // summary:
        //      Controller for Service Health views.

        model: null,

        widget: null,

        startup: function() {
            if (this.isStarted()) {
                return;
            }
            this.inherited(arguments);

            this.model = new ServiceHealthModel();
            this.model.init();

            this.widget = new ServiceHealth({
                model: this.model
            });
            this.own(this.widget);
        },

        show: function() {
            this._setupView([this.widget]);
        }
    });
});
