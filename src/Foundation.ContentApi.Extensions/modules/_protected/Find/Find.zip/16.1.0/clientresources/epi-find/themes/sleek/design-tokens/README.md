<h1 align="center">Axiom Design Tokens Library</h1>

<div align="center">

Re-usable design tokens to be used within Optimizely themes.

[![npm version](https://badge.fury.io/js/%40optimizely%2Fdesign-tokens.svg)](https://www.npmjs.com/package/@optimizely/design-tokens)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

</div>

## Links

- [Style Guide](https://design.optimizely.com/style-guidelines)
- [Design Token Documentation](https://design.optimizely.com/style-guidelines/design-tokens)

## Installation

```bash
npm install @optimizely/design-tokens
```

```bash
yarn add @optimizely/design-tokens
```

For usage, see examples:

- [SASS](#sass)
- [LESS](#less)
- [CSS variables](#css)
- [Javascript](#javascript)

## Tokens

Tokens can be accessed from the package using the following url pattern:

```@optimizely/design-tokens/dist/<format>/<token-package>```

Currently supported formats:
- sass
- less
- css
- js
- json

Token packages currently available:

- colors (all)
- typography (all)
- typography-map (scss, less)

## Fonts

Axiom design system uses Inter. The font can be found locally in the fonts folder:

```@optimizely/design-tokens/dist/fonts/fonts.css```


To include it with webpack, add the following rule:

```javascript
{
    test: /\.(woff|woff2)$/,
    use: {
        loader: "file-loader",
        options: {
            context: path.resolve(__dirname, "../node_modules/@optimizely/design-tokens/dist/fonts")
        }
    }
}
```

When using Inter for numbers, it's recommended to make them monospaced. Inter supports this by setting the font feature setting to `tnum`: 

```css
{
    ...
    font-feature-settings: "tnum";
}
```

## Brand Assets

Some brand assets are included in the design tokens package in order to simplify distribution. These can be found in the `@optimizely/design-tokens/dist/brand-assets` folder.

To enable svg and png import with webpack, add the following rule:

```javascript
{
    test: /\.(svg|png)$/,
    use: {
        loader: "file-loader",
        options: {
            context: path.resolve(__dirname, "../node_modules/@optimizely/design-tokens/dist/brand-assets")
        }
    }
}
```

## Examples
### SASS
To use color tokens via sass:
```scss
@use "@optimizely/design-tokens/dist/scss/colors" as axiom-colors;

$your-primary-color: axiom-colors.$brand-primary-color;

```

> We strongly recommend using the [new module system](https://sass-lang.com/documentation/at-rules/use) whenever it's possible to avoid style conflicts and unexpected behavior.

To include the fonts via sass:

```scss
@import "@optimizely/design-tokens/dist/fonts/fonts.css";

```
Make sure it's included in a root file so it's available everywhere.

#### SASS with webpack

1. Install sass-loader, sass. `npm install sass-loader sass --save-dev`
2. Add a new rule to `webpack.config.js` for .scss files

```javascript
{
    test: /\.s[ac]ss$/i,
    use: [
        // Creates `style` nodes from JS strings
        "style-loader",
        // Translates CSS into CommonJS
        "css-loader",
        // Compiles Sass to CSS
        "sass-loader",
    ],
},
```

For more information see: https://webpack.js.org/loaders/sass-loader/

### LESS
To use color tokens via less:
```less
@import "@optimizely/design-tokens/dist/less/colors";

@your-primary-color: @axiom-brand-primary-color;

```

To include the font via less:
```less
@import (css) "@optimizely/design-tokens/dist/fonts/fonts";

```

#### LESS with webpack

See: https://webpack.js.org/loaders/less-loader/

#### LESS with gulp

1. Install gulp-less. `npm install --save-dev gulp-less`
2. Add a new task to `gulpfile.js` for .less files, or change an existing task.

```javascript
task("build-less", () => {
    return src(["**/*.less"]).pipe(
        less({
            paths: [path.join(__dirname, "node_modules")],
        })
    );
});
```

### CSS
To use color tokens via css variables in a stylesheet:
```css
@import "node_modules/@optimizely/design-tokens/dist/css/colors.css";

:root {
    --your-primary-color: var(--axiom-brand-primary-color);
}

/* Or use directly */

.some-class {
    background-color: var(--axiom-brand-primary-color);
}

```

To include the font:
```css
@import "node_modules/@optimizely/design-tokens/dist/fonts/fonts.css";

```

In html:

```html
<!DOCTYPE html>
<html>
    <head>
        ...
        <link rel="stylesheet" href="node_modules/@optimizely/design-tokens/dist/fonts/fonts.css">
        <link rel="stylesheet" href="node_modules/@optimizely/design-tokens/dist/css/colors.css">
    </head>
    <style>
        :root {
            --your-primary-color: var(--axiom-brand-primary-color);
        }

        /* Or use directly */

        .some-class {
            background-color: var(--axiom-brand-primary-color);
        }
    </style>
        ...
        ...
</html>

```

> Make sure the axiom design token css file is included last so any other css variable can be correctly overriden.

### Javascript
To use color tokens via ES6 JavaScript or inside a React component:
```jsx
import * as axiomColors from '@optimizely/design-tokens/dist/js/colors';

const primaryStyle = {
    backgroundColor: axiomColors.brandPrimaryColor
};

const StyledButton = <button style={primaryStyle}>Press me</button>

```

> The javascript provided in the module is by default ES6. If older javascript support is needed, we recommend transpiling the module using webpack or similar tool. Example using webpack can be found here: https://webpack.js.org/loaders/babel-loader/



