﻿define("epi-find/Configuration", [
    "dojo/_base/config",
    "epi-find/Intents!"
],
    function (config) {
        // module:
        //		epi-find/Configuration
        return {
            // summary:
            //      A plugin that initializes application configuration.
            load: function (id, require, callback) {
                if (!config.find) {
                    config.find = {};
                }

                // The URL where user can order upgraded version of the product to enable features
                config.find.orderFindUrl = "http://www.episerver.com/orderfind";
                config.find.defaultSearchProviders = [
                    { searchArea: "CMS/pages", id:"EPiServer.Find.Cms.SearchProviders.EnterprisePageSearchProvider"},
                    { searchArea: "CMS/files", id:"EPiServer.Find.Cms.SearchProviders.EnterpriseMediaSearchProvider"}
                ];

                config.find.defaultDescriptors = {
                        pages: {roots: ["1"]}
                    };
                callback();
            }
        };
    });