﻿define("epi-find/AccessRestrictions", [
    "./AccessModel"
],
    function (AccessModel) {
        // module:
        //		epi-find/AccessRestrictions
        return {
            // summary:
            //      A plugin that configures access restrictions.
            //  description:
            //      Access restriction are based on and have the same structure as intents.
            //      By default all intents are allowed and enabled. If you want to add a restriction,
            //      please do one of the following:
            //      In order to allow intent only for a certain setup or roles:
            //          AccessModel.access.view.synonyms.allowFor({admin:true}, ["Admin", "SearchAdmin"]);
            //      In order to enable intent only for a certain setup or roles:
            //          AccessModel.access.view.synonyms.enableFor({admin:true}, ["Admin", "SearchAdmin"]);
            load: function (id, require, callback) {

                AccessModel.access.view.synonyms.enableFor({admin: true});
                AccessModel.access.create.synonym.enableFor({admin: true});

                AccessModel.access.view.boosting.enableFor({admin: true});
                AccessModel.access.view.connectors.enableFor({connectors: true});

                callback();
            }
        };
    });