﻿define("epi-find/store/ResourceStore", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    "dojo/store/util/QueryResults",
    "epi/shell/store/JsonRest",
    "epi-saas-base/RetryableXhrWrapper"
],
function(declare,
         lang,
         Deferred,
         QueryResults,
         JsonRest,
         RetryableXhrWrapper) {
    return declare([JsonRest], {
        // listProperty: string
        //      The property to extract the list of items from.
        //      Treats the entire result as the results list if not set.
        listProperty: null,

        // itemProperty: string
        //      The property to extract the item.
        //      Treats the entire result as the item if not set.
        itemProperty: null,

        // returnUpdatedItemFromPut: Boolean
        //    Indicates that put method should return an updated object from the store
        //    by issuing a separate GET request
        returnUpdatedItemFromPut: false,

        // preventCache: Boolean
        //    Prevents browser caching by adding a parameter to requests URL that changes with every new request.
        //    The parameter addition is handled by the base store implementation, here we just overriding the default value.
        preventCache: true,

        constructor: function(options) {
            this.xhrHandler = new RetryableXhrWrapper(options ? options.handlerOptions : null);
            declare.safeMixin(this, options);
        },

        _getList: function(data, options) {
            //  summary:
            //      Extracts a items from a property specified in the listProperty
            //  tags: protected
            if (this.listProperty) {
                return data[this.listProperty];
            } else {
                return data;
            }
        },

        _getTotal: function(result) {
            //  summary:
            //      Returns a total amount of items
            //  tags: protected
            var self = this;

            return result.then(function(data) {
                if (data.total) {
                    return data.total;
                }
                var result = self._getList(data, null);
                if (result && result instanceof Array) {
                    return result.length;
                }
            });
        },

        query: function(query, options){
            var self = this, queryResult = new Deferred(), newQuery = lang.clone(query || {}),
                newOptions = lang.clone(options || {}), result;

            if (newOptions.count) {
                newQuery.size = newOptions.count;
            }
            if (newOptions.start) {
                newQuery.from = newOptions.start;
            }

            if(query && query.tags && query.tags.join) {
                newQuery.tags = query.tags.join();
            }

            if (newOptions.sort && !query.sort) {
                var sortValue = "";
                for(var i = 0; i<options.sort.length; i++){
                    var sort = options.sort[i];
                    sortValue += (i > 0 ? "," : "") + (sort.descending ? "-" : "") + encodeURIComponent(sort.attribute);
                }
                newQuery.sort = sortValue;
                newOptions.sort = null;
            }

            result = this.inherited(arguments, [newQuery, newOptions]);

            result.then(function(data) {
                    queryResult.resolve(self._getList(data, options));
                }, function(error) {
                    queryResult.reject(error);
                });

            queryResult.total = this._getTotal(result);
            return QueryResults(queryResult);
        },

        get: function() {
            var result = this.inherited(arguments),
                self = this;

            return result.then(function(data) {
                return self._getItem(data);
            });
        },

        _getItem: function(data) {
            //  summary:
            //      Extracts a items from a property specified in the itemProperty
            //  tags: protected

            if (this.itemProperty && typeof data[this.itemProperty] != "undefined") {
                return data[this.itemProperty];
            } else {
                return data;
            }

        },

        put: function(object, options) {
            // Summary:
            //      Assumes that the REST-endpoint does not modify the object, but simply informs of the new id.
            //      This function will add that id to the object and return the entire object.

            var result = this.inherited(arguments),
                self = this;

            return result.then(function(data) {
                var dataItem = self._getItem(data), id = self.getIdentity(dataItem || {});
                if (self.returnUpdatedItemFromPut) { // in case if an endpoint does modify the object
                    return self.get(id);
                }
                if (dataItem && id) {
                    object[self.idProperty] = id;
                }
                return object;
            });
        },

        remove: function(id, options) {
            var self = this, deferred = new Deferred(), result = this.inherited(arguments);

            result.then(function(data) {
                if (data && typeof data === "object") {
                    // a workaround for observable, remove should return plain ID instead of object
                    deferred.resolve(self.getIdentity(data));
                }
                else {
                    deferred.resolve(data);
                }
            }, function(error) {
                deferred.reject(error);
            });

            return deferred;
        }
    });
});
